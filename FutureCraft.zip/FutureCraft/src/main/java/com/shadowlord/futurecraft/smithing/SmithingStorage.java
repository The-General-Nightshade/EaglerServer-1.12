package com.shadowlord.futurecraft.smithing;

import com.shadowlord.futurecraft.FutureCraft;
import org.bukkit.configuration.file.FileConfiguration;

public final class SmithingStorage {
    private final FutureCraft plugin = FutureCraft.getInstance();
    private final FileConfiguration cfg = this.plugin != null ? this.plugin.getConfig() : null;

    public boolean getBoolean(String key, boolean def) {
        if (this.cfg == null) {
            return def;
        }
        return this.cfg.getBoolean("smithing." + key, def);
    }

    public void setBoolean(String key, boolean value) {
        if (this.cfg == null) {
            return;
        }
        this.cfg.set("smithing." + key, (Object)value);
        this.plugin.saveConfig();
    }

    public int getInt(String key, int def) {
        if (this.cfg == null) {
            return def;
        }
        return this.cfg.getInt("smithing." + key, def);
    }

    public void setInt(String key, int value) {
        if (this.cfg == null) {
            return;
        }
        this.cfg.set("smithing." + key, (Object)value);
        this.plugin.saveConfig();
    }

    public void clearAll() {
        if (this.cfg == null) {
            return;
        }
        this.cfg.set("smithing", null);
        this.plugin.saveConfig();
    }
}

