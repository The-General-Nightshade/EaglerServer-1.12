package com.shadowlord.futurecraft.recipes;

import com.shadowlord.futurecraft.FutureCraft;
import com.shadowlord.futurecraft.blastfurnace.BlastFurnaceRecipe;
import com.shadowlord.futurecraft.crossbows.CrossbowRecipe;
import com.shadowlord.futurecraft.recipes.NetheriteIngotRecipe;
import com.shadowlord.futurecraft.smithing.SmithingRecipe;
import org.bukkit.Bukkit;

public final class RecipeRegistrar {
    private RecipeRegistrar() {
    }

    public static void registerAll(FutureCraft plugin) {
        if (plugin == null) {
            return;
        }
        if (plugin.isModuleEnabled("nether")) {
            try {
                BlastFurnaceRecipe.register(plugin);
            } catch (Throwable t) {
                plugin.getLogger().warning(
                    "Failed to register BlastFurnaceRecipe: " + t.getMessage()
                );
            }
            try {
                SmithingRecipe.register(plugin);
            } catch (Throwable t) {
                plugin.getLogger().warning(
                    "Failed to register SmithingRecipe: " + t.getMessage()
                );
            }
            try {
                NetheriteIngotRecipe.register(plugin);
            } catch (Throwable t) {
                plugin.getLogger().warning(
                    "Failed to register NetheriteIngotRecipe: " + t.getMessage()
                );
            }
        }
        if (plugin.isModuleEnabled("crossbows")) {
            try {
                CrossbowRecipe.register(plugin);
            } catch (Throwable t) {
                plugin.getLogger().warning(
                    "Failed to register CrossbowRecipe: " + t.getMessage()
                );
            }
        }
        plugin.getLogger().info("RecipeRegistrar: enabled-module recipes registered.");
    }

    public static void removeAll(FutureCraft plugin) {
        if (plugin == null) {
            return;
        }
        Bukkit.getLogger().info("RecipeRegistrar: attempted to remove plugin recipes.");
    }
}

