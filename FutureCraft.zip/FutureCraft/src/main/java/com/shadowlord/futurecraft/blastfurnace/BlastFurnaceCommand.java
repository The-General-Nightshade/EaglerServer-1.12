package com.shadowlord.futurecraft.blastfurnace;

import com.shadowlord.futurecraft.blastfurnace.BlastFurnaceGUI;
import java.util.Collections;
import java.util.List;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

public class BlastFurnaceCommand
implements CommandExecutor,
TabCompleter {
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("Only players can open the blast furnace GUI.");
            return true;
        }
        Player p = (Player)sender;
        BlastFurnaceGUI.openGui(p);
        return true;
    }

    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        return Collections.emptyList();
    }
}

