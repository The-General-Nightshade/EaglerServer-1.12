package com.shadowlord.futurecraft.bastion;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.configuration.file.YamlConfiguration;

public final class BastionTemplate {
    private final String name;
    private final int width;
    private final int height;
    private final int length;
    private final List<BlockRecord> blocks;

    public BastionTemplate(String name, int width, int height, int length, List<BlockRecord> blocks) {
        this.name = name;
        this.width = width;
        this.height = height;
        this.length = length;
        this.blocks = new ArrayList<BlockRecord>(blocks);
    }

    public static BastionTemplate capture(String name, World world, Location first, Location second) {
        int minX = Math.min(first.getBlockX(), second.getBlockX());
        int minY = Math.min(first.getBlockY(), second.getBlockY());
        int minZ = Math.min(first.getBlockZ(), second.getBlockZ());
        int maxX = Math.max(first.getBlockX(), second.getBlockX());
        int maxY = Math.max(first.getBlockY(), second.getBlockY());
        int maxZ = Math.max(first.getBlockZ(), second.getBlockZ());
        List<BlockRecord> blocks = new ArrayList<BlockRecord>();
        for (int x = minX; x <= maxX; ++x) {
            for (int y = minY; y <= maxY; ++y) {
                for (int z = minZ; z <= maxZ; ++z) {
                    Block block = world.getBlockAt(x, y, z);
                    blocks.add(new BlockRecord(x - minX, y - minY, z - minZ, block.getTypeId(), block.getData()));
                }
            }
        }
        if (blocks.isEmpty()) {
            throw new IllegalArgumentException("The selected region contains no blocks.");
        }
        return new BastionTemplate(name, maxX - minX + 1, maxY - minY + 1, maxZ - minZ + 1, blocks);
    }

    public static BastionTemplate load(File file) throws IOException {
        YamlConfiguration config = YamlConfiguration.loadConfiguration(file);
        String fallbackName = file.getName().endsWith(".yml")
            ? file.getName().substring(0, file.getName().length() - 4)
            : file.getName();
        String name = config.getString("name", fallbackName);
        int width = config.getInt("width");
        int height = config.getInt("height");
        int length = config.getInt("length");
        List<BlockRecord> blocks = new ArrayList<BlockRecord>();
        for (Map<?, ?> raw : config.getMapList("blocks")) {
            blocks.add(BlockRecord.fromMap(raw));
        }
        if (width <= 0 || height <= 0 || length <= 0 || blocks.isEmpty()) {
            throw new IOException("Template has no valid dimensions or blocks.");
        }
        return new BastionTemplate(name, width, height, length, blocks);
    }

    public void save(File file) throws IOException {
        YamlConfiguration config = new YamlConfiguration();
        config.set("name", this.name);
        config.set("width", this.width);
        config.set("height", this.height);
        config.set("length", this.length);
        List<Map<String, Object>> serialized = new ArrayList<Map<String, Object>>();
        for (BlockRecord block : this.blocks) {
            serialized.add(block.toMap());
        }
        config.set("blocks", serialized);
        config.save(file);
    }

    public String getName() {
        return this.name;
    }

    public int getWidth() {
        return this.width;
    }

    public int getHeight() {
        return this.height;
    }

    public int getLength() {
        return this.length;
    }

    public List<BlockRecord> getBlocks() {
        return new ArrayList<BlockRecord>(this.blocks);
    }

    public static final class BlockRecord {
        private final int x;
        private final int y;
        private final int z;
        private final int typeId;
        private final byte data;

        public BlockRecord(int x, int y, int z, int typeId, byte data) {
            this.x = x;
            this.y = y;
            this.z = z;
            this.typeId = typeId;
            this.data = data;
        }

        public static BlockRecord fromMap(Map<?, ?> map) throws IOException {
            Object x = map.get("x");
            Object y = map.get("y");
            Object z = map.get("z");
            Object type = map.get("type");
            Object data = map.get("data");
            if (!(x instanceof Number) || !(y instanceof Number) || !(z instanceof Number)
                || !(type instanceof Number) || !(data instanceof Number)) {
                throw new IOException("Template block is missing coordinates or material data.");
            }
            return new BlockRecord(
                ((Number)x).intValue(),
                ((Number)y).intValue(),
                ((Number)z).intValue(),
                ((Number)type).intValue(),
                ((Number)data).byteValue()
            );
        }

        public Map<String, Object> toMap() {
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("x", this.x);
            map.put("y", this.y);
            map.put("z", this.z);
            map.put("type", this.typeId);
            map.put("data", (int)this.data);
            return map;
        }

        public int getX() {
            return this.x;
        }

        public int getY() {
            return this.y;
        }

        public int getZ() {
            return this.z;
        }

        public int getTypeId() {
            return this.typeId;
        }

        public byte getData() {
            return this.data;
        }

        public boolean isChest() {
            return this.typeId == Material.CHEST.getId() || this.typeId == Material.TRAPPED_CHEST.getId();
        }

        public boolean isAir() {
            return this.typeId == Material.AIR.getId();
        }
    }
}