package com.shadowlord.futurecraft.smithing;

import com.shadowlord.futurecraft.FutureCraft;
import com.shadowlord.futurecraft.items.ItemNBT;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;

public class FullSetListener
implements Listener {
    private static final String UPGRADED_MARKER = "futurecraft:netherite_upgraded";
    private static final double FIRE_DAMAGE_MULTIPLIER = 0.2D;
    private final FutureCraft plugin;

    public FullSetListener(FutureCraft plugin) {
        this.plugin = plugin;
    }

    public void start() {
        this.plugin.getServer().getPluginManager().registerEvents(this, (Plugin)this.plugin);
    }

    public void stop() {
    }

    @EventHandler(priority=EventPriority.HIGH, ignoreCancelled=true)
    public void onFireDamage(EntityDamageEvent event) {
        if (!(event.getEntity() instanceof Player)) {
            return;
        }
        EntityDamageEvent.DamageCause cause = event.getCause();
        if (cause != EntityDamageEvent.DamageCause.FIRE
            && cause != EntityDamageEvent.DamageCause.FIRE_TICK
            && cause != EntityDamageEvent.DamageCause.LAVA) {
            return;
        }
        if (this.hasFullNetheriteSet((Player)event.getEntity())) {
            event.setDamage(event.getDamage() * FIRE_DAMAGE_MULTIPLIER);
        }
    }

    private boolean hasFullNetheriteSet(Player p) {
        ItemStack[] armor = p.getInventory().getArmorContents();
        if (armor == null || armor.length < 4) {
            return false;
        }
        org.bukkit.Material[] expected = new org.bukkit.Material[]{
            org.bukkit.Material.DIAMOND_BOOTS,
            org.bukkit.Material.DIAMOND_LEGGINGS,
            org.bukkit.Material.DIAMOND_CHESTPLATE,
            org.bukkit.Material.DIAMOND_HELMET
        };
        for (int i = 0; i < expected.length; ++i) {
            ItemStack piece = armor[i];
            if (piece == null) {
                return false;
            }
            if (piece.getType() != expected[i] || !ItemNBT.hasMarker(piece, UPGRADED_MARKER)) {
                return false;
            }
        }
        return true;
    }
}

