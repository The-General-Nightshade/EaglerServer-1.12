package com.shadowlord.futurecraft.recipes;

import com.shadowlord.futurecraft.FutureCraft;
import com.shadowlord.futurecraft.items.NetheriteIngotItem;
import com.shadowlord.futurecraft.items.NetheriteScrapItem;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.CraftItemEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.Recipe;
import org.bukkit.inventory.ShapelessRecipe;
import org.bukkit.plugin.Plugin;

public final class NetheriteIngotRecipe {
    private NetheriteIngotRecipe() {
    }

    public static void register(FutureCraft plugin) {
        if (plugin == null) {
            return;
        }
        boolean enabled = plugin.getConfig().getBoolean("recipes.netherite_ingot.enabled", true);
        if (!enabled) {
            return;
        }
        final ItemStack result = NetheriteIngotItem.create();
        ShapelessRecipe r = new ShapelessRecipe(result);
        r.addIngredient(Material.GOLD_INGOT);
        r.addIngredient(Material.GOLD_INGOT);
        r.addIngredient(Material.GOLD_INGOT);
        r.addIngredient(Material.GOLD_INGOT);
        Material scrapMat = NetheriteScrapItem.createScrap(1).getType();
        r.addIngredient(scrapMat);
        r.addIngredient(scrapMat);
        r.addIngredient(scrapMat);
        r.addIngredient(scrapMat);
        Bukkit.addRecipe((Recipe)r);
        plugin.getLogger().info("Registered NetheriteIngotRecipe (4 Neth Scrap + 4 Gold Ingots -> Netherite Ingot).");
        FutureCraft pl = plugin;
        Bukkit.getPluginManager().registerEvents(new Listener(){

            @EventHandler
            public void onCraft(CraftItemEvent ev) {
                ItemStack res = ev.getInventory().getResult();
                if (res == null) {
                    return;
                }
                if (!res.isSimilar(result)) {
                    return;
                }
                int scrapCount = 0;
                int goldCount = 0;
                for (ItemStack it : ev.getInventory().getMatrix()) {
                    if (it == null) continue;
                    if (NetheriteScrapItem.isScrap(it)) {
                        scrapCount += it.getAmount();
                        continue;
                    }
                    if (it.getType() == Material.GOLD_INGOT) {
                        goldCount += it.getAmount();
                        continue;
                    }
                    ev.getInventory().setResult(null);
                    ev.setCancelled(true);
                    return;
                }
                if (scrapCount < 4 || goldCount < 4) {
                    ev.getInventory().setResult(null);
                    ev.setCancelled(true);
                }
            }
        }, (Plugin)pl);
    }
}

