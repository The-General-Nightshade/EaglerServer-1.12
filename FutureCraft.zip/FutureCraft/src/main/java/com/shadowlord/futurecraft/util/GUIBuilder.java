package com.shadowlord.futurecraft.util;

import java.util.List;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public final class GUIBuilder {
    private GUIBuilder() {
    }

    public static ItemStack namedItem(Material mat, int amount, String name, List<String> lore) {
        ItemStack it;
        ItemMeta meta;
        if (mat == null) {
            mat = Material.STONE;
        }
        if ((meta = (it = new ItemStack(mat, Math.max(1, amount))).getItemMeta()) != null) {
            if (name != null) {
                meta.setDisplayName(ChatColor.translateAlternateColorCodes((char)'&', (String)name));
            }
            if (lore != null && !lore.isEmpty()) {
                meta.setLore(lore);
            }
            it.setItemMeta(meta);
        }
        return it;
    }

    public static ItemStack pane(int colorData, String displayName) {
        Material paneMat = Material.STAINED_GLASS_PANE;
        ItemStack it = new ItemStack(paneMat, 1, (short)Math.max(0, Math.min(15, colorData)));
        ItemMeta meta = it.getItemMeta();
        if (meta != null) {
            if (displayName != null) {
                meta.setDisplayName(ChatColor.translateAlternateColorCodes((char)'&', (String)displayName));
            }
            it.setItemMeta(meta);
        }
        return it;
    }
}

