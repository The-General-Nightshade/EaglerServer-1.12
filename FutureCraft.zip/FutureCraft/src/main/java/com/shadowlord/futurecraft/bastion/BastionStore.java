package com.shadowlord.futurecraft.bastion;

import com.shadowlord.futurecraft.FutureCraft;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.inventory.ItemStack;

public final class BastionStore {
    private final FutureCraft plugin;
    private final File root;
    private final File templateDirectory;
    private final File lootFile;
    private final File stateFile;
    private final Map<String, BastionTemplate> templates = new LinkedHashMap<String, BastionTemplate>();
    private final List<LootEntry> lootEntries = new ArrayList<LootEntry>();
    private final Set<String> processedChunks = new HashSet<String>();
    private final List<PendingPlacement> pending = new ArrayList<PendingPlacement>();
    private final Map<String, BastionGenerated> generated = new LinkedHashMap<String, BastionGenerated>();

    public BastionStore(FutureCraft plugin) {
        this.plugin = plugin;
        this.root = new File(plugin.getDataFolder(), "bastions");
        this.templateDirectory = new File(this.root, "templates");
        this.lootFile = new File(this.root, "loot_table.yml");
        this.stateFile = new File(this.root, "state.yml");
        this.templateDirectory.mkdirs();
        this.loadTemplates();
        this.loadLoot();
        this.loadState();
    }

    public FutureCraft getPlugin() {
        return this.plugin;
    }

    private void loadTemplates() {
        this.templates.clear();
        File[] files = this.templateDirectory.listFiles();
        if (files == null) {
            return;
        }
        for (File file : files) {
            if (!file.isFile() || !file.getName().toLowerCase().endsWith(".yml")) {
                continue;
            }
            try {
                BastionTemplate template = BastionTemplate.load(file);
                this.templates.put(template.getName().toLowerCase(), template);
            }
            catch (Exception ex) {
                this.plugin.getLogger().warning("[FutureCraft] Could not load bastion template "
                    + file.getName() + ": " + ex.getMessage());
            }
        }
    }

    private void loadLoot() {
        this.lootEntries.clear();
        if (!this.lootFile.exists()) {
            return;
        }
        YamlConfiguration config = YamlConfiguration.loadConfiguration(this.lootFile);
        ConfigurationSection entries = config.getConfigurationSection("entries");
        if (entries == null) {
            return;
        }
        for (String key : entries.getKeys(false)) {
            ItemStack item = entries.getItemStack(key + ".item");
            double weight = entries.getDouble(key + ".weight", entries.getDouble(key + ".chance", 1.0D));
            if (item != null && item.getTypeId() != 0 && weight > 0.0D) {
                this.lootEntries.add(new LootEntry(item, weight));
            }
        }
    }

    private void loadState() {
        this.processedChunks.clear();
        this.pending.clear();
        this.generated.clear();
        if (!this.stateFile.exists()) {
            return;
        }
        YamlConfiguration config = YamlConfiguration.loadConfiguration(this.stateFile);
        this.processedChunks.addAll(config.getStringList("processed-chunks"));
        ConfigurationSection pendingSection = config.getConfigurationSection("pending");
        if (pendingSection != null) {
            for (String key : pendingSection.getKeys(false)) {
                ConfigurationSection section = pendingSection.getConfigurationSection(key);
                if (section != null) {
                    this.pending.add(PendingPlacement.load(section));
                }
            }
        }
        ConfigurationSection generatedSection = config.getConfigurationSection("generated");
        if (generatedSection != null) {
            for (String key : generatedSection.getKeys(false)) {
                ConfigurationSection section = generatedSection.getConfigurationSection(key);
                if (section != null) {
                    BastionGenerated instance = BastionGenerated.load(key, section);
                    this.generated.put(instance.getId(), instance);
                }
            }
        }
    }

    public synchronized void saveAll() {
        this.saveLoot();
        this.saveState();
    }

    private void saveLoot() {
        YamlConfiguration config = new YamlConfiguration();
        int index = 0;
        for (LootEntry entry : this.lootEntries) {
            String path = "entries." + index;
            config.set(path + ".item", entry.getItem());
            config.set(path + ".weight", entry.getWeight());
            ++index;
        }
        try {
            this.root.mkdirs();
            config.save(this.lootFile);
        }
        catch (IOException ex) {
            this.plugin.getLogger().warning("[FutureCraft] Failed to save bastion loot table: " + ex.getMessage());
        }
    }

    private void saveState() {
        YamlConfiguration config = new YamlConfiguration();
        config.set("processed-chunks", new ArrayList<String>(this.processedChunks));
        int pendingIndex = 0;
        for (PendingPlacement placement : this.pending) {
            ConfigurationSection section = config.createSection("pending." + pendingIndex);
            placement.save(section);
            ++pendingIndex;
        }
        for (BastionGenerated instance : this.generated.values()) {
            ConfigurationSection section = config.createSection("generated." + instance.getId());
            instance.save(section);
        }
        try {
            this.root.mkdirs();
            config.save(this.stateFile);
        }
        catch (IOException ex) {
            this.plugin.getLogger().warning("[FutureCraft] Failed to save bastion state: " + ex.getMessage());
        }
    }

    public synchronized void saveTemplate(BastionTemplate template) throws IOException {
        String fileName = template.getName().toLowerCase() + ".yml";
        template.save(new File(this.templateDirectory, fileName));
        this.templates.put(template.getName().toLowerCase(), template);
    }

    public synchronized boolean deleteTemplate(String name) {
        BastionTemplate removed = this.templates.remove(name.toLowerCase());
        File file = new File(this.templateDirectory, name.toLowerCase() + ".yml");
        if (file.exists()) {
            file.delete();
        }
        return removed != null;
    }

    public synchronized BastionTemplate getTemplate(String name) {
        return this.templates.get(name.toLowerCase());
    }

    public synchronized List<String> getTemplateNames() {
        List<String> names = new ArrayList<String>(this.templates.keySet());
        Collections.sort(names);
        return names;
    }

    public synchronized List<LootEntry> getLootEntries() {
        List<LootEntry> result = new ArrayList<LootEntry>();
        for (LootEntry entry : this.lootEntries) {
            result.add(new LootEntry(entry.getItem(), entry.getWeight()));
        }
        return result;
    }

    public synchronized void replaceLoot(List<ItemStack> items) {
        this.lootEntries.clear();
        for (ItemStack item : items) {
            if (item != null && item.getTypeId() != 0) {
                this.lootEntries.add(new LootEntry(item, 1.0D));
            }
        }
        this.saveLoot();
    }

    public synchronized boolean isChunkProcessed(String world, int chunkX, int chunkZ) {
        return this.processedChunks.contains(this.chunkKey(world, chunkX, chunkZ));
    }

    public synchronized void markChunkProcessed(String world, int chunkX, int chunkZ) {
        this.processedChunks.add(this.chunkKey(world, chunkX, chunkZ));
    }

    public synchronized void clearWorldGeneration(World world) {
        List<BastionGenerated> instances = new ArrayList<BastionGenerated>();
        for (BastionGenerated instance : this.generated.values()) {
            if (world.getName().equals(instance.getWorldName())) {
                instances.add(instance);
            }
        }
        for (BastionGenerated instance : instances) {
            instance.restore(world);
            this.generated.remove(instance.getId());
        }
        String prefix = world.getName() + "|";
        this.processedChunks.removeIf(key -> key.startsWith(prefix));
        for (int i = this.pending.size() - 1; i >= 0; --i) {
            if (world.getName().equals(this.pending.get(i).getWorldName())) {
                this.pending.remove(i);
            }
        }
        this.saveState();
    }

    public synchronized List<PendingPlacement> getPending() {
        return new ArrayList<PendingPlacement>(this.pending);
    }

    public synchronized void addPending(PendingPlacement placement) {
        this.pending.add(placement);
    }

    public synchronized void removePending(PendingPlacement placement) {
        this.pending.remove(placement);
    }

    public synchronized void addGenerated(BastionGenerated instance) {
        this.generated.put(instance.getId(), instance);
    }

    public synchronized boolean overlaps(String world, int x, int y, int z, int width, int height, int length) {
        for (BastionGenerated instance : this.generated.values()) {
            if (!world.equals(instance.getWorldName())) {
                continue;
            }
            if (x >= instance.getX() + instance.getWidth() || instance.getX() >= x + width
                || y >= instance.getY() + instance.getHeight() || instance.getY() >= y + height
                || z >= instance.getZ() + instance.getLength() || instance.getZ() >= z + length) {
                continue;
            }
            return true;
        }
        return false;
    }

    private String chunkKey(String world, int chunkX, int chunkZ) {
        return world + "|" + chunkX + "|" + chunkZ;
    }

    public static final class LootEntry {
        private final ItemStack item;
        private final double weight;

        public LootEntry(ItemStack item, double weight) {
            this.item = item.clone();
            this.weight = weight;
        }

        public ItemStack getItem() {
            return this.item.clone();
        }

        public double getWeight() {
            return this.weight;
        }
    }

    public static final class PendingPlacement {
        private final String worldName;
        private final String templateName;
        private final int x;
        private final int y;
        private final int z;
        private final long seed;

        public PendingPlacement(String worldName, String templateName, int x, int y, int z, long seed) {
            this.worldName = worldName;
            this.templateName = templateName;
            this.x = x;
            this.y = y;
            this.z = z;
            this.seed = seed;
        }

        private static PendingPlacement load(ConfigurationSection section) {
            return new PendingPlacement(
                section.getString("world"),
                section.getString("template"),
                section.getInt("x"),
                section.getInt("y"),
                section.getInt("z"),
                section.getLong("seed")
            );
        }

        private void save(ConfigurationSection section) {
            section.set("world", this.worldName);
            section.set("template", this.templateName);
            section.set("x", this.x);
            section.set("y", this.y);
            section.set("z", this.z);
            section.set("seed", this.seed);
        }

        public String getWorldName() {
            return this.worldName;
        }

        public String getTemplateName() {
            return this.templateName;
        }

        public int getX() {
            return this.x;
        }

        public int getY() {
            return this.y;
        }

        public int getZ() {
            return this.z;
        }

        public long getSeed() {
            return this.seed;
        }
    }
}