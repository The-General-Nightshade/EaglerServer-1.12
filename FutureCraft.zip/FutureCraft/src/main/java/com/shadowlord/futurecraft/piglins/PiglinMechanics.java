package com.shadowlord.futurecraft.piglins;

import com.shadowlord.futurecraft.FutureCraft;
import com.shadowlord.futurecraft.crossbows.CrossbowItem;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.UUID;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.entity.Creature;
import org.bukkit.entity.Entity;
import org.bukkit.entity.PigZombie;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityTargetEvent;
import org.bukkit.event.inventory.InventoryOpenEvent;
import org.bukkit.inventory.EntityEquipment;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.inventory.ItemStack;
import org.bukkit.entity.Item;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

public final class PiglinMechanics implements Listener {
    private static final String PIGLIN_NAME = ChatColor.GOLD + "Piglin";
    private static final String BRUTE_NAME = ChatColor.RED + "Piglin Brute";
    private static final String PIGLIN_TAG = "futurecraft_piglin";
    private static final String BRUTE_TAG = "futurecraft_piglin_brute";
    private static final long FACTION_ANGER_SUPPRESSION_MILLIS = 2000L;
    private static final List<String> DEFAULT_BARTER_LOOT = Arrays.asList(
        "GOLD_NUGGET:2:8:7",
        "QUARTZ:2:6:6",
        "GLOWSTONE_DUST:2:5:4",
        "MAGMA_CREAM:1:2:3",
        "SOUL_SAND:1:4:3",
        "OBSIDIAN:1:1:2",
        "FIREBALL:1:2:2",
        "ENDER_PEARL:1:1:1",
        "NETHER_BRICK:2:8:2"
    );

    private final FutureCraft plugin;
    private final Random random = new Random();
    private final Map<UUID, Aggression> provokedUntil = new HashMap<UUID, Aggression>();
    private final Map<UUID, RecentFactionHit> recentFactionHits =
        new HashMap<UUID, RecentFactionHit>();
    private final Map<UUID, BarterProcess> activeBarters = new HashMap<UUID, BarterProcess>();
    private BukkitTask aggressionTask;
    private BukkitTask behaviorTask;
    private long behaviorTicks;

    public PiglinMechanics(FutureCraft plugin) {
        this.plugin = plugin;
    }

    public void start() {
        this.aggressionTask = new BukkitRunnable() {
            public void run() {
                PiglinMechanics.this.updateNearbyAggression();
            }
        }.runTaskTimer(this.plugin, 20L, 20L);
        this.behaviorTask = new BukkitRunnable() {
            public void run() {
                PiglinMechanics.this.updatePiglinBehaviors();
            }
        }.runTaskTimer(this.plugin, 1L, 5L);
    }

    public void shutdown() {
        if (this.aggressionTask != null) {
            this.aggressionTask.cancel();
            this.aggressionTask = null;
        }
        if (this.behaviorTask != null) {
            this.behaviorTask.cancel();
            this.behaviorTask = null;
        }
        for (BarterProcess process : this.activeBarters.values()) {
            this.returnHeldGold(process);
        }
        this.activeBarters.clear();
        this.provokedUntil.clear();
        this.recentFactionHits.clear();
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onNaturalPigZombieSpawn(CreatureSpawnEvent event) {
        if (!(event.getEntity() instanceof PigZombie)) {
            return;
        }
        World world = event.getLocation().getWorld();
        if (world.getEnvironment() != World.Environment.NETHER) {
            return;
        }
        CreatureSpawnEvent.SpawnReason reason = event.getSpawnReason();
        if (reason != CreatureSpawnEvent.SpawnReason.NATURAL
            && reason != CreatureSpawnEvent.SpawnReason.CHUNK_GEN) {
            return;
        }

        double piglinChance = this.clampChance("piglins.spawning.piglin-chance", 0.6D);
        if (this.random.nextDouble() >= piglinChance) {
            return;
        }
        double bruteChance = this.clampChance("piglins.spawning.brute-chance", 0.12D);
        boolean brute = this.random.nextDouble() < bruteChance;
        this.configurePiglin((PigZombie)event.getEntity(), brute);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPiglinAttacked(EntityDamageByEntityEvent event) {
        if (!(event.getEntity() instanceof PigZombie)) {
            return;
        }
        Player attacker = this.getPlayerAttacker(event.getDamager());
        if (attacker == null) {
            return;
        }
        PigZombie piglin = (PigZombie)event.getEntity();
        this.recentFactionHits.put(attacker.getUniqueId(), new RecentFactionHit(
            PiglinMechanics.isPiglin(piglin),
            System.currentTimeMillis() + FACTION_ANGER_SUPPRESSION_MILLIS
        ));
        if (!PiglinMechanics.isPiglin(piglin)) {
            return;
        }
        this.provoke(piglin, attacker);
        double radius = this.plugin.getConfig().getDouble("piglins.aggression.ally-alert-radius", 12.0D);
        for (Entity nearby : piglin.getNearbyEntities(radius, radius, radius)) {
            if (nearby instanceof PigZombie && PiglinMechanics.isPiglin((PigZombie)nearby)) {
                this.provoke((PigZombie)nearby, attacker);
            }
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onTarget(EntityTargetEvent event) {
        if (!(event.getEntity() instanceof PigZombie)) {
            return;
        }
        PigZombie source = (PigZombie)event.getEntity();
        if (event.getTarget() instanceof PigZombie
            && PiglinMechanics.isPiglin(source)
                != PiglinMechanics.isPiglin((PigZombie)event.getTarget())) {
            event.setCancelled(true);
            ((Creature)source).setTarget(null);
            source.setAngry(false);
            source.setAnger(0);
            return;
        }
        if (!(event.getTarget() instanceof Player)) {
            return;
        }
        Player target = (Player)event.getTarget();
        if (this.wasRecentlyHitByOppositeFaction(source, target)) {
            event.setCancelled(true);
            ((Creature)source).setTarget(null);
            if (!PiglinMechanics.isPiglin(source)
                || !this.isProvokedAgainst(source, target)) {
                source.setAngry(false);
                source.setAnger(0);
            }
            return;
        }
        if (!PiglinMechanics.isPiglin(source)) {
            return;
        }
        if (PiglinMechanics.isNearZombiePigman(
            source,
            this.safeRange("piglins.flee-from-pigmen.range", 8.0D)
        )) {
            event.setCancelled(true);
            ((Creature)source).setTarget(null);
            return;
        }
        if (PiglinMechanics.isBrute(source)) {
            return;
        }
        if (PiglinMechanics.isWearingGold(target) && !this.isProvokedAgainst(source, target)) {
            event.setCancelled(true);
            ((Creature)source).setTarget(null);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onContainerOpen(InventoryOpenEvent event) {
        if (!(event.getPlayer() instanceof Player)) {
            return;
        }
        InventoryType type = event.getInventory().getType();
        if (type != InventoryType.CHEST && type != InventoryType.ENDER_CHEST
            && type != InventoryType.HOPPER && type != InventoryType.DISPENSER
            && type != InventoryType.DROPPER && type != InventoryType.FURNACE) {
            return;
        }
        Player player = (Player)event.getPlayer();
        this.angerNearbyPiglins(player);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onGoldBlockMined(BlockBreakEvent event) {
        Material type = event.getBlock().getType();
        if (type != Material.GOLD_ORE && type != Material.GOLD_BLOCK) {
            return;
        }
        this.angerNearbyPiglins(event.getPlayer());
    }

    private void configurePiglin(PigZombie piglin, boolean brute) {
        piglin.addScoreboardTag(PIGLIN_TAG);
        if (brute) {
            piglin.addScoreboardTag(BRUTE_TAG);
        }
        piglin.setCustomName(brute ? BRUTE_NAME : PIGLIN_NAME);
        piglin.setCustomNameVisible(true);
        piglin.setRemoveWhenFarAway(true);
        piglin.setCanPickupItems(false);
        piglin.setAngry(false);
        piglin.setAnger(0);

        double maxHealth = this.plugin.getConfig().getDouble(
            brute ? "piglins.brute.max-health" : "piglins.normal.max-health",
            brute ? 50.0D : 20.0D
        );
        double attackDamage = this.plugin.getConfig().getDouble(
            brute ? "piglins.brute.attack-damage" : "piglins.normal.attack-damage",
            brute ? 12.0D : 6.0D
        );
        maxHealth = Math.max(1.0D, Math.min(2048.0D, maxHealth));
        attackDamage = Math.max(0.0D, Math.min(2048.0D, attackDamage));
        AttributeInstance health = piglin.getAttribute(Attribute.GENERIC_MAX_HEALTH);
        if (health != null) {
            health.setBaseValue(maxHealth);
            piglin.setHealth(maxHealth);
        }
        AttributeInstance damage = piglin.getAttribute(Attribute.GENERIC_ATTACK_DAMAGE);
        if (damage != null) {
            damage.setBaseValue(attackDamage);
        }

        EntityEquipment equipment = piglin.getEquipment();
        boolean carriesCrossbow = !brute
            && this.plugin.isModuleEnabled("crossbows")
            && this.random.nextDouble() < this.clampChance(
            "piglins.spawning.crossbow-chance",
            0.15D
        );
        equipment.setItemInHand(brute
            ? new ItemStack(Material.GOLD_AXE)
            : (carriesCrossbow
                ? CrossbowItem.create()
                : new ItemStack(Material.GOLD_SWORD)));
        equipment.setItemInHandDropChance(0.0F);
        equipment.setItemInOffHandDropChance(0.0F);

        double armorChance = this.clampChance(
            "piglins.spawning.gold-armor-piece-chance",
            0.15D
        );
        this.maybeEquipGoldArmor(equipment, armorChance);
    }

    private void maybeEquipGoldArmor(EntityEquipment equipment, double chance) {
        if (this.random.nextDouble() < chance) {
            equipment.setHelmet(new ItemStack(Material.GOLD_HELMET));
            equipment.setHelmetDropChance(0.0F);
        }
        if (this.random.nextDouble() < chance) {
            equipment.setChestplate(new ItemStack(Material.GOLD_CHESTPLATE));
            equipment.setChestplateDropChance(0.0F);
        }
        if (this.random.nextDouble() < chance) {
            equipment.setLeggings(new ItemStack(Material.GOLD_LEGGINGS));
            equipment.setLeggingsDropChance(0.0F);
        }
        if (this.random.nextDouble() < chance) {
            equipment.setBoots(new ItemStack(Material.GOLD_BOOTS));
            equipment.setBootsDropChance(0.0F);
        }
    }

    private void updatePiglinBehaviors() {
        this.behaviorTicks += 5L;
        this.processActiveBarters();

        for (World world : this.plugin.getServer().getWorlds()) {
            if (world.getEnvironment() != World.Environment.NETHER) {
                continue;
            }
            for (Entity entity : world.getEntities()) {
                if (!(entity instanceof PigZombie)) {
                    continue;
                }
                PigZombie piglin = (PigZombie)entity;
                if (!PiglinMechanics.isPiglin(piglin)) {
                    continue;
                }
                if (this.runFromZombiePigmen(piglin)) {
                    continue;
                }
                if (PiglinMechanics.isBrute(piglin)
                    || this.activeBarters.containsKey(piglin.getUniqueId())) {
                    continue;
                }

                Item gold = this.findNearestGold(piglin);
                if (gold == null) {
                    continue;
                }
                if (piglin.getLocation().distanceSquared(gold.getLocation()) <= 2.25D) {
                    this.stopHorizontalMovement(piglin);
                    this.beginBarter(piglin, gold);
                } else {
                    this.moveTowardGold(piglin, gold);
                }
            }
        }
    }

    private void processActiveBarters() {
        Iterator<Map.Entry<UUID, BarterProcess>> iterator =
            this.activeBarters.entrySet().iterator();
        while (iterator.hasNext()) {
            BarterProcess process = iterator.next().getValue();
            PigZombie piglin = process.piglin;
            if (!piglin.isValid() || piglin.isDead()) {
                this.returnHeldGold(process);
                iterator.remove();
                continue;
            }
            if (this.behaviorTicks < process.finishAtTick) {
                continue;
            }

            ItemStack offhand = piglin.getEquipment().getItemInOffHand();
            if (offhand != null && offhand.getType() == Material.GOLD_INGOT
                && offhand.getAmount() > 0) {
                piglin.getEquipment().setItemInOffHand(new ItemStack(Material.AIR));
                piglin.getWorld().dropItemNaturally(
                    piglin.getLocation(),
                    this.rollBarterReward()
                );
            }
            iterator.remove();
        }
    }

    private void returnHeldGold(BarterProcess process) {
        PigZombie piglin = process.piglin;
        ItemStack offhand = piglin.getEquipment().getItemInOffHand();
        if (offhand == null || offhand.getType() != Material.GOLD_INGOT
            || offhand.getAmount() < 1) {
            return;
        }
        piglin.getEquipment().setItemInOffHand(new ItemStack(Material.AIR));
        piglin.getWorld().dropItemNaturally(
            piglin.getLocation(),
            new ItemStack(Material.GOLD_INGOT)
        );
    }

    private void beginBarter(PigZombie piglin, Item droppedGold) {
        if (!droppedGold.isValid() || this.activeBarters.containsKey(piglin.getUniqueId())) {
            return;
        }
        EntityEquipment equipment = piglin.getEquipment();
        ItemStack offhand = equipment.getItemInOffHand();
        if (offhand != null && offhand.getType() != Material.AIR) {
            return;
        }

        ItemStack stack = droppedGold.getItemStack().clone();
        if (stack.getType() != Material.GOLD_INGOT || stack.getAmount() < 1) {
            return;
        }
        if (stack.getAmount() == 1) {
            droppedGold.remove();
        } else {
            stack.setAmount(stack.getAmount() - 1);
            droppedGold.setItemStack(stack);
        }

        equipment.setItemInOffHand(new ItemStack(Material.GOLD_INGOT));
        equipment.setItemInOffHandDropChance(0.0F);
        int holdTicks = this.plugin.getConfig().getInt(
            "piglins.barter.offhand-hold-ticks",
            40
        );
        holdTicks = Math.max(5, Math.min(200, holdTicks));
        this.activeBarters.put(
            piglin.getUniqueId(),
            new BarterProcess(piglin, this.behaviorTicks + holdTicks)
        );
    }

    private Item findNearestGold(PigZombie piglin) {
        double range = this.safeRange("piglins.barter.seek-range", 12.0D);
        double nearestDistance = range * range;
        Item nearest = null;
        for (Entity entity : piglin.getNearbyEntities(range, range, range)) {
            if (!(entity instanceof Item) || !entity.isValid()) {
                continue;
            }
            Item item = (Item)entity;
            ItemStack stack = item.getItemStack();
            if (stack == null || stack.getType() != Material.GOLD_INGOT
                || stack.getAmount() < 1) {
                continue;
            }
            double distance = piglin.getLocation().distanceSquared(item.getLocation());
            if (distance < nearestDistance) {
                nearestDistance = distance;
                nearest = item;
            }
        }
        return nearest;
    }

    private void moveTowardGold(PigZombie piglin, Item gold) {
        Vector direction = gold.getLocation().toVector()
            .subtract(piglin.getLocation().toVector());
        direction.setY(0.0D);
        if (direction.lengthSquared() < 0.0001D) {
            return;
        }
        direction.normalize();
        double speed = this.safeSpeed("piglins.barter.seek-speed", 0.24D);
        Vector currentVelocity = piglin.getVelocity();
        Vector desiredVelocity = direction.clone().multiply(speed);
        Vector horizontalVelocity = new Vector(
            currentVelocity.getX(),
            0.0D,
            currentVelocity.getZ()
        ).multiply(0.65D).add(desiredVelocity.multiply(0.35D));
        if (horizontalVelocity.lengthSquared() > speed * speed) {
            horizontalVelocity.normalize().multiply(speed);
        }

        Location facing = piglin.getLocation();
        float targetYaw = (float)Math.toDegrees(
            Math.atan2(-direction.getX(), direction.getZ())
        );
        float yawChange = this.wrapDegrees(targetYaw - facing.getYaw());
        float turnStep = Math.max(-20.0F, Math.min(20.0F, yawChange));
        facing.setYaw(facing.getYaw() + turnStep);
        facing.setPitch(0.0F);
        // Spigot 1.12 has no entity rotation setter; preserve position and turn in small steps.
        piglin.teleport(facing);
        piglin.setVelocity(new Vector(
            horizontalVelocity.getX(),
            currentVelocity.getY(),
            horizontalVelocity.getZ()
        ));
    }

    private void stopHorizontalMovement(PigZombie piglin) {
        Vector velocity = piglin.getVelocity();
        velocity.setX(0.0D);
        velocity.setZ(0.0D);
        piglin.setVelocity(velocity);
    }

    private float wrapDegrees(float degrees) {
        while (degrees <= -180.0F) {
            degrees += 360.0F;
        }
        while (degrees > 180.0F) {
            degrees -= 360.0F;
        }
        return degrees;
    }

    private boolean runFromZombiePigmen(PigZombie piglin) {
        double range = this.safeRange("piglins.flee-from-pigmen.range", 8.0D);
        PigZombie threat = this.findNearestZombiePigman(piglin, range);
        if (threat == null) {
            return false;
        }
        if (piglin.getTarget() != null) {
            piglin.setTarget(null);
        }

        Vector direction = piglin.getLocation().toVector()
            .subtract(threat.getLocation().toVector());
        direction.setY(0.0D);
        if (direction.lengthSquared() < 0.0001D) {
            double angle = this.random.nextDouble() * Math.PI * 2.0D;
            direction = new Vector(Math.cos(angle), 0.0D, Math.sin(angle));
        }
        direction.normalize().multiply(this.safeSpeed("piglins.flee-from-pigmen.speed", 0.30D));
        direction.setY(piglin.getVelocity().getY());
        piglin.setVelocity(direction);
        return true;
    }

    public static boolean isNearZombiePigman(PigZombie piglin, double range) {
        return findNearestZombiePigman(piglin, range) != null;
    }

    private static PigZombie findNearestZombiePigman(PigZombie piglin, double range) {
        double nearestDistance = range * range;
        PigZombie nearest = null;
        for (Entity entity : piglin.getNearbyEntities(range, range, range)) {
            if (!(entity instanceof PigZombie) || entity == piglin) {
                continue;
            }
            PigZombie candidate = (PigZombie)entity;
            if (PiglinMechanics.isPiglin(candidate)) {
                continue;
            }
            double distance = piglin.getLocation().distanceSquared(candidate.getLocation());
            if (distance < nearestDistance) {
                nearestDistance = distance;
                nearest = candidate;
            }
        }
        return nearest;
    }

    private double safeRange(String path, double fallback) {
        double range = this.plugin.getConfig().getDouble(path, fallback);
        if (Double.isNaN(range) || Double.isInfinite(range)) {
            range = fallback;
        }
        return Math.max(1.0D, Math.min(64.0D, range));
    }

    private double safeSpeed(String path, double fallback) {
        double speed = this.plugin.getConfig().getDouble(path, fallback);
        if (Double.isNaN(speed) || Double.isInfinite(speed)) {
            speed = fallback;
        }
        return Math.max(0.05D, Math.min(0.8D, speed));
    }

    private void updateNearbyAggression() {
        double radius = this.safeAggressionRadius("piglins.aggression.range", 16.0D);
        long now = System.currentTimeMillis();
        for (Player player : this.plugin.getServer().getOnlinePlayers()) {
            if (player.getWorld().getEnvironment() != World.Environment.NETHER) {
                continue;
            }
            for (Entity entity : player.getNearbyEntities(radius, radius, radius)) {
                if (!(entity instanceof PigZombie)) {
                    continue;
                }
                PigZombie piglin = (PigZombie)entity;
                if (!PiglinMechanics.isPiglin(piglin)) {
                    continue;
                }
                if (PiglinMechanics.isBrute(piglin)) {
                    this.provoke(piglin, player);
                } else if (!PiglinMechanics.isWearingGold(player)) {
                    this.provoke(piglin, player);
                } else if (!this.isProvokedAgainst(piglin, player) && piglin.getTarget() == player) {
                    ((Creature)piglin).setTarget(null);
                    piglin.setAngry(false);
                    piglin.setAnger(0);
                }
            }
        }
        this.provokedUntil.entrySet().removeIf(entry -> entry.getValue().expiresAt <= now);
        this.recentFactionHits.entrySet()
            .removeIf(entry -> entry.getValue().expiresAt <= now);
    }

    private void angerNearbyPiglins(Player player) {
        if (player.getWorld().getEnvironment() != World.Environment.NETHER) {
            return;
        }
        double radius = this.safeAggressionRadius("piglins.aggression.range", 16.0D);
        for (Entity entity : player.getNearbyEntities(radius, radius, radius)) {
            if (entity instanceof PigZombie && PiglinMechanics.isPiglin((PigZombie)entity)) {
                this.provoke((PigZombie)entity, player);
            }
        }
    }

    private void provoke(PigZombie piglin, Player player) {
        long duration = Math.max(1L, Math.min(3600L,
            this.plugin.getConfig().getLong("piglins.aggression.anger-seconds", 30L)));
        this.provokedUntil.put(piglin.getUniqueId(), new Aggression(
            player.getUniqueId(),
            System.currentTimeMillis() + duration * 1000L
        ));
        piglin.setAngry(true);
        piglin.setAnger((int)(duration * 20L));
        if (piglin instanceof Creature && piglin.getTarget() != player) {
            ((Creature)piglin).setTarget(player);
        }
    }

    private double safeAggressionRadius(String path, double fallback) {
        double radius = this.plugin.getConfig().getDouble(path, fallback);
        if (Double.isNaN(radius) || Double.isInfinite(radius)) {
            radius = fallback;
        }
        return Math.max(1.0D, Math.min(64.0D, radius));
    }

    private boolean isProvokedAgainst(PigZombie piglin, Player player) {
        Aggression aggression = this.provokedUntil.get(piglin.getUniqueId());
        return aggression != null
            && aggression.expiresAt > System.currentTimeMillis()
            && aggression.target.equals(player.getUniqueId());
    }

    private boolean wasRecentlyHitByOppositeFaction(PigZombie source, Player target) {
        UUID playerId = target.getUniqueId();
        RecentFactionHit hit = this.recentFactionHits.get(playerId);
        if (hit == null) {
            return false;
        }
        if (hit.expiresAt <= System.currentTimeMillis()) {
            this.recentFactionHits.remove(playerId);
            return false;
        }
        return hit.piglinFaction != PiglinMechanics.isPiglin(source);
    }

    private ItemStack rollBarterReward() {
        List<String> entries = this.plugin.getConfig().getStringList(
            "piglins.barter.exchange-items"
        );
        if (entries == null || entries.isEmpty()) {
            entries = this.plugin.getConfig().getStringList("piglins.barter.loot");
        }
        if (entries == null || entries.isEmpty()) {
            entries = DEFAULT_BARTER_LOOT;
        }
        List<BarterEntry> parsed = new ArrayList<BarterEntry>();
        int totalWeight = 0;
        for (String line : entries) {
            BarterEntry entry = BarterEntry.parse(line);
            if (entry != null) {
                parsed.add(entry);
                totalWeight += entry.weight;
            }
        }
        if (parsed.isEmpty()) {
            return new ItemStack(Material.GOLD_NUGGET, 4);
        }
        int roll = this.random.nextInt(totalWeight);
        for (BarterEntry entry : parsed) {
            roll -= entry.weight;
            if (roll < 0) {
                return new ItemStack(entry.material, entry.minAmount
                    + this.random.nextInt(entry.maxAmount - entry.minAmount + 1));
            }
        }
        return new ItemStack(Material.GOLD_NUGGET, 4);
    }

    private double clampChance(String path, double fallback) {
        return Math.max(0.0D, Math.min(1.0D, this.plugin.getConfig().getDouble(path, fallback)));
    }

    public static boolean isPiglin(PigZombie piglin) {
        return piglin.getScoreboardTags().contains(PIGLIN_TAG)
            || PIGLIN_NAME.equals(piglin.getCustomName())
            || BRUTE_NAME.equals(piglin.getCustomName());
    }

    public static boolean isBrute(PigZombie piglin) {
        return piglin.getScoreboardTags().contains(BRUTE_TAG)
            || BRUTE_NAME.equals(piglin.getCustomName());
    }

    public static boolean isWearingGold(Player player) {
        return PiglinMechanics.isGoldenArmorPiece(
                player.getInventory().getHelmet(), Material.GOLD_HELMET)
            || PiglinMechanics.isGoldenArmorPiece(
                player.getInventory().getChestplate(), Material.GOLD_CHESTPLATE)
            || PiglinMechanics.isGoldenArmorPiece(
                player.getInventory().getLeggings(), Material.GOLD_LEGGINGS)
            || PiglinMechanics.isGoldenArmorPiece(
                player.getInventory().getBoots(), Material.GOLD_BOOTS);
    }

    private static boolean isGoldenArmorPiece(ItemStack item, Material expected) {
        return item != null && item.getType() == expected;
    }

    private Player getPlayerAttacker(Entity damager) {
        if (damager instanceof Player) {
            return (Player)damager;
        }
        if (damager instanceof Projectile) {
            Object shooter = ((Projectile)damager).getShooter();
            if (shooter instanceof Player) {
                return (Player)shooter;
            }
        }
        return null;
    }

    private static final class Aggression {
        private final UUID target;
        private final long expiresAt;

        private Aggression(UUID target, long expiresAt) {
            this.target = target;
            this.expiresAt = expiresAt;
        }
    }

    private static final class BarterProcess {
        private final PigZombie piglin;
        private final long finishAtTick;

        private BarterProcess(PigZombie piglin, long finishAtTick) {
            this.piglin = piglin;
            this.finishAtTick = finishAtTick;
        }
    }

    private static final class RecentFactionHit {
        private final boolean piglinFaction;
        private final long expiresAt;

        private RecentFactionHit(boolean piglinFaction, long expiresAt) {
            this.piglinFaction = piglinFaction;
            this.expiresAt = expiresAt;
        }
    }

    private static final class BarterEntry {
        private final Material material;
        private final int minAmount;
        private final int maxAmount;
        private final int weight;

        private BarterEntry(Material material, int minAmount, int maxAmount, int weight) {
            this.material = material;
            this.minAmount = minAmount;
            this.maxAmount = maxAmount;
            this.weight = weight;
        }

        private static BarterEntry parse(String line) {
            try {
                String[] fields = line.split(":");
                if (fields.length != 4) {
                    return null;
                }
                Material material = Material.valueOf(fields[0].trim().toUpperCase());
                int min = Integer.parseInt(fields[1].trim());
                int max = Integer.parseInt(fields[2].trim());
                int weight = Integer.parseInt(fields[3].trim());
                if (material == Material.AIR || min < 1 || max < min || weight < 1
                    || weight > 1000000 || max > material.getMaxStackSize()) {
                    return null;
                }
                return new BarterEntry(material, min, max, weight);
            } catch (Exception ignored) {
                return null;
            }
        }
    }
}
