package com.shadowlord.futurecraft.items;

import com.shadowlord.futurecraft.debris.DebrisItem;
import com.shadowlord.futurecraft.util.NBTUtil;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Item;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityCombustEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.util.Vector;

public final class NetheriteItemProtection
implements Listener {
    private static final String UPGRADED_MARKER = "futurecraft:netherite_upgraded";

    @EventHandler(priority=EventPriority.HIGHEST, ignoreCancelled=false)
    public void onItemCombust(EntityCombustEvent event) {
        Entity entity = event.getEntity();
        if (entity instanceof Item && NetheriteItemProtection.isNetheriteItem(((Item)entity).getItemStack())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority=EventPriority.HIGHEST, ignoreCancelled=false)
    public void onItemDamage(EntityDamageEvent event) {
        if (!(event.getEntity() instanceof Item)) {
            return;
        }
        EntityDamageEvent.DamageCause cause = event.getCause();
        if (cause != EntityDamageEvent.DamageCause.FIRE
            && cause != EntityDamageEvent.DamageCause.FIRE_TICK
            && cause != EntityDamageEvent.DamageCause.LAVA) {
            return;
        }
        Item item = (Item)event.getEntity();
        if (!NetheriteItemProtection.isNetheriteItem(item.getItemStack())) {
            return;
        }
        event.setCancelled(true);
        if (cause == EntityDamageEvent.DamageCause.LAVA) {
            Vector velocity = item.getVelocity();
            item.setVelocity(new Vector(velocity.getX(), Math.max(velocity.getY(), 0.08D), velocity.getZ()));
        }
    }

    private static boolean isNetheriteItem(ItemStack item) {
        return item != null
            && (NetheriteIngotItem.isIngot(item)
                || NetheriteScrapItem.isScrap(item)
                || DebrisItem.isDebris(item)
                || NBTUtil.hasTag(item, UPGRADED_MARKER));
    }
}