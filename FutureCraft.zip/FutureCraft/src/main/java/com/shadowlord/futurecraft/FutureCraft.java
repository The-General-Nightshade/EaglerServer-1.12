package com.shadowlord.futurecraft;

import com.shadowlord.futurecraft.blastfurnace.BlastFurnaceCommand;
import com.shadowlord.futurecraft.blastfurnace.BlastFurnaceGUI;
import com.shadowlord.futurecraft.blastfurnace.BlastFurnaceListener;
import com.shadowlord.futurecraft.bastion.BastionGenerator;
import com.shadowlord.futurecraft.bastion.BastionLootGUI;
import com.shadowlord.futurecraft.bastion.BastionSelectionListener;
import com.shadowlord.futurecraft.bubbleelevators.BubbleElevatorsModule;
import com.shadowlord.futurecraft.bastion.BastionStore;
import com.shadowlord.futurecraft.macewind.MaceWindModule;
import com.shadowlord.futurecraft.commands.CommandBastion;
import com.shadowlord.futurecraft.commands.CommandCrossbowBook;
import com.shadowlord.futurecraft.commands.CommandGiveDebris;
import com.shadowlord.futurecraft.commands.CommandGiveSmithingTable;
import com.shadowlord.futurecraft.commands.CommandGiveTemplate;
import com.shadowlord.futurecraft.commands.CommandRegenDebris;
import com.shadowlord.futurecraft.crossbows.CrossbowMechanics;
import com.shadowlord.futurecraft.debris.DebrisGenerator;
import com.shadowlord.futurecraft.debris.DebrisListener;
import com.shadowlord.futurecraft.debris.DebrisTracker;
import com.shadowlord.futurecraft.items.NetheriteItemProtection;
import com.shadowlord.futurecraft.piglins.PiglinMechanics;
import com.shadowlord.futurecraft.recipes.RecipeRegistrar;
import com.shadowlord.futurecraft.smithing.FullSetListener;
import com.shadowlord.futurecraft.smithing.SmithingGUI;
import com.shadowlord.futurecraft.smithing.SmithingTableBlock;
import com.shadowlord.futurecraft.util.NBTUtil;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.Arrays;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.PluginCommand;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.event.Listener;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;

public class FutureCraft
extends JavaPlugin {
    private static FutureCraft instance;
    private PrintWriter debugLog;
    private BastionStore bastionStore;
    private BastionGenerator bastionGenerator;
    private BastionSelectionListener bastionSelection;
    private PiglinMechanics piglinMechanics;
    private CrossbowMechanics crossbowMechanics;
    private BubbleElevatorsModule bubbleElevators;
    private MaceWindModule maceWind;
    private File moduleConfigFile;
    private File netherConfigFile;
    private FileConfiguration moduleConfig;
    private FileConfiguration netherConfig;

    private void log(String msg) {
        if (this.debugLog != null) {
            this.debugLog.println(msg);
            this.debugLog.flush();
        }
        this.getLogger().info("[DEBUG] " + msg);
    }

    private void logError(String step, Throwable t) {
        if (this.debugLog != null) {
            this.debugLog.println("FAILED at: " + step);
            t.printStackTrace(this.debugLog);
            this.debugLog.flush();
        }
        this.getLogger().severe("[DEBUG] FAILED at: " + step);
        t.printStackTrace();
    }

    public void onEnable() {
        instance = this;
        try {
            this.getDataFolder().mkdirs();
            File logFile = new File(this.getDataFolder(), "debug-load.txt");
            this.debugLog = new PrintWriter(new FileWriter(logFile, false));
            this.log("=== FutureCraft Debug Load ===");
        }
        catch (Exception ex) {
            this.getLogger().severe("Could not create debug log file!");
            ex.printStackTrace();
        }
        try {
            this.log("Step 1: load module and Nether configs");
            this.loadPluginConfigs();
            this.log("Step 1: OK");
        }
        catch (Throwable t) {
            this.logError("Step 1: load module and Nether configs", t);
            throw new RuntimeException(t);
        }
        if (this.isModuleEnabled("nether")) {
        try {
            this.log("Step 3: BlastFurnaceListener");
            this.getServer().getPluginManager().registerEvents((Listener)new BlastFurnaceListener(this), (Plugin)this);
            this.log("Step 3: OK");
        }
        catch (Throwable t) {
            this.logError("Step 3: BlastFurnaceListener", t);
            throw new RuntimeException(t);
        }
        try {
            this.log("Step 4: BlastFurnaceGUI");
            this.getServer().getPluginManager().registerEvents((Listener)new BlastFurnaceGUI(this), (Plugin)this);
            this.log("Step 4: OK");
        }
        catch (Throwable t) {
            this.logError("Step 4: BlastFurnaceGUI", t);
            throw new RuntimeException(t);
        }
        try {
            this.log("Step 5: DebrisTracker");
            for (World w : Bukkit.getWorlds()) {
                if (w.getEnvironment() != World.Environment.NETHER) continue;
                DebrisTracker.loadWorld(this, w.getName());
            }
            this.log("Step 5: OK");
        }
        catch (Throwable t) {
            this.logError("Step 5: DebrisTracker", t);
            throw new RuntimeException(t);
        }
        try {
            this.log("Step 5.5: DebrisListener");
            this.getServer().getPluginManager().registerEvents((Listener)new DebrisListener(), (Plugin)this);
            this.log("Step 5.5: OK");
        }
        catch (Throwable t) {
            this.logError("Step 5.5: DebrisListener", t);
            throw new RuntimeException(t);
        }
        try {
            this.log("Step 5.6: DebrisGenerator");
            this.getServer().getPluginManager().registerEvents((Listener)new DebrisGenerator(this), (Plugin)this);
            this.log("Step 5.6: OK");
        }
        catch (Throwable t) {
            this.logError("Step 5.6: DebrisGenerator", t);
            throw new RuntimeException(t);
        }
        try {
            this.log("Step 5.7: NetheriteItemProtection");
            this.getServer().getPluginManager().registerEvents((Listener)new NetheriteItemProtection(), (Plugin)this);
            this.log("Step 5.7: OK");
        }
        catch (Throwable t) {
            this.logError("Step 5.7: NetheriteItemProtection", t);
            throw new RuntimeException(t);
        }
        try {
            this.log("Step 5.8: Bastion system");
            this.bastionStore = new BastionStore(this);
            this.bastionGenerator = new BastionGenerator(this, this.bastionStore);
            this.bastionSelection = new BastionSelectionListener();
            this.getServer().getPluginManager().registerEvents((Listener)this.bastionGenerator, (Plugin)this);
            this.getServer().getPluginManager().registerEvents((Listener)this.bastionSelection, (Plugin)this);
            this.getServer().getPluginManager().registerEvents((Listener)new BastionLootGUI(this.bastionStore), (Plugin)this);
            this.log("Step 5.8: OK");
        }
        catch (Throwable t) {
            this.logError("Step 5.8: Bastion system", t);
            throw new RuntimeException(t);
        }
        } else {
            this.log("Nether feature module disabled by config.yml.");
        }
        if (this.isModuleEnabled("piglins")) {
        try {
            this.log("Step 5.9: Piglin mechanics");
            this.piglinMechanics = new PiglinMechanics(this);
            this.getServer().getPluginManager().registerEvents((Listener)this.piglinMechanics, (Plugin)this);
            this.piglinMechanics.start();
            this.log("Step 5.9: OK");
        }
        catch (Throwable t) {
            this.logError("Step 5.9: Piglin mechanics", t);
            throw new RuntimeException(t);
        }
        } else {
            this.log("Piglin module disabled by config.yml.");
        }
        if (this.isModuleEnabled("crossbows")) {
        try {
            this.log("Step 5.95: Crossbow mechanics");
            this.crossbowMechanics = new CrossbowMechanics(this);
            this.getServer().getPluginManager().registerEvents(
                (Listener)this.crossbowMechanics,
                (Plugin)this
            );
            this.crossbowMechanics.start();
            this.log("Step 5.95: OK");
        }
        catch (Throwable t) {
            this.logError("Step 5.95: Crossbow mechanics", t);
            throw new RuntimeException(t);
        }
        } else {
            this.log("Crossbow module disabled by config.yml.");
        }
        if (this.isModuleEnabled("bubbleelevators")) {
        try {
            this.log("Step 5.96: BubbleElevators");
            this.bubbleElevators = new BubbleElevatorsModule(this);
            this.bubbleElevators.enable();
            this.log("Step 5.96: OK");
        }
        catch (Throwable t) {
            this.logError("Step 5.96: BubbleElevators", t);
            throw new RuntimeException(t);
        }
        } else {
            this.log("BubbleElevators module disabled by config.yml.");
        }
        if (this.isModuleEnabled("macewind")) {
        try {
            this.log("Step 5.97: MaceWind");
            this.maceWind = new MaceWindModule(this);
            this.maceWind.enable();
            this.log("Step 5.97: OK");
        }
        catch (Throwable t) {
            this.logError("Step 5.97: MaceWind", t);
            throw new RuntimeException(t);
        }
        } else {
            this.log("MaceWind module disabled by config.yml.");
        }
        if (this.isModuleEnabled("nether")) {
        try {
            this.log("Step 6: SmithingGUI");
            this.getServer().getPluginManager().registerEvents((Listener)new SmithingGUI(), (Plugin)this);
            this.log("Step 6: OK");
        }
        catch (Throwable t) {
            this.log("Step 6: SmithingGUI skipped: " + t.getMessage());
        }
        try {
            this.log("Step 6.5: SmithingTableBlock");
            this.getServer().getPluginManager().registerEvents((Listener)new SmithingTableBlock(this), (Plugin)this);
            this.log("Step 6.5: OK");
        }
        catch (Throwable t) {
            this.log("Step 6.5: SmithingTableBlock skipped: " + t.getMessage());
        }
        try {
            this.log("Step 7: FullSetListener");
            FullSetListener fullSet = new FullSetListener(this);
            fullSet.start();
            this.log("Step 7: OK");
        }
        catch (Throwable t) {
            this.log("Step 7: FullSetListener skipped: " + t.getMessage());
        }
        }
        if (this.isModuleEnabled("nether")) {
        try {
            this.log("Step 8: cmd blastfurnace");
            this.getCommand("blastfurnace").setExecutor((CommandExecutor)new BlastFurnaceCommand());
            this.getCommand("blastfurnace").setTabCompleter((TabCompleter)new BlastFurnaceCommand());
            this.log("Step 8: OK");
        }
        catch (Throwable t) {
            this.logError("Step 8: cmd blastfurnace", t);
            throw new RuntimeException(t);
        }
        try {
            this.log("Step 9: cmd givetemplate");
            this.getCommand("givetemplate").setExecutor((CommandExecutor)new CommandGiveTemplate());
            this.getCommand("givetemplate").setTabCompleter((TabCompleter)new CommandGiveTemplate());
            this.log("Step 9: OK");
        }
        catch (Throwable t) {
            this.logError("Step 9: cmd givetemplate", t);
            throw new RuntimeException(t);
        }
        }
        if (this.isModuleEnabled("crossbows")) {
        try {
            this.log("Step 9.5: cmd crossbowbook");
            CommandCrossbowBook crossbowBookCommand = new CommandCrossbowBook();
            this.getCommand("crossbowbook").setExecutor((CommandExecutor)crossbowBookCommand);
            this.getCommand("crossbowbook").setTabCompleter(crossbowBookCommand);
            this.log("Step 9.5: OK");
        }
        catch (Throwable t) {
            this.logError("Step 9.5: cmd crossbowbook", t);
            throw new RuntimeException(t);
        }
        }
        if (this.isModuleEnabled("nether")) {
        try {
            this.log("Step 10: cmd givedebris");
            this.getCommand("givedebris").setExecutor((CommandExecutor)new CommandGiveDebris());
            this.getCommand("givedebris").setTabCompleter((TabCompleter)new CommandGiveDebris());
            this.log("Step 10: OK");
        }
        catch (Throwable t) {
            this.logError("Step 10: cmd givedebris", t);
            throw new RuntimeException(t);
        }
        try {
            this.log("Step 11: cmd regendebris");
            this.getCommand("regendebris").setExecutor((CommandExecutor)new CommandRegenDebris());
            this.getCommand("regendebris").setTabCompleter((TabCompleter)new CommandRegenDebris());
            this.log("Step 11: OK");
        }
        catch (Throwable t) {
            this.logError("Step 11: cmd regendebris", t);
            throw new RuntimeException(t);
        }
        }
        try {
            this.log("Step 12: RecipeRegistrar");
            RecipeRegistrar.registerAll(this);
            this.log("Step 12: OK");
        }
        catch (Throwable t) {
            this.log("Step 12: RecipeRegistrar skipped: " + t.getMessage());
        }
        if (this.isModuleEnabled("nether")) {
        try {
            this.log("Step 13: cmd givesmithingtable");
            this.getCommand("givesmithingtable").setExecutor((CommandExecutor)new CommandGiveSmithingTable());
            this.getCommand("givesmithingtable").setTabCompleter((TabCompleter)new CommandGiveSmithingTable());
            this.log("Step 13: OK");
        }
        catch (Throwable t) {
            this.logError("Step 13: cmd givesmithingtable", t);
            throw new RuntimeException(t);
        }
        try {
            this.log("Step 14: cmd bastion");
            CommandBastion bastionCommand = new CommandBastion(this.bastionStore, this.bastionGenerator, this.bastionSelection);
            this.getCommand("bastion").setExecutor((CommandExecutor)bastionCommand);
            this.getCommand("bastion").setTabCompleter((TabCompleter)bastionCommand);
            this.log("Step 14: OK");
        }
        catch (Throwable t) {
            this.logError("Step 14: cmd bastion", t);
            throw new RuntimeException(t);
        }
        }
        if (!this.isModuleEnabled("nether")) {
            this.disableCommand("blastfurnace", "nether");
            this.disableCommand("givetemplate", "nether");
            this.disableCommand("givedebris", "nether");
            this.disableCommand("regendebris", "nether");
            this.disableCommand("givesmithingtable", "nether");
            this.disableCommand("bastion", "nether");
        }
        if (!this.isModuleEnabled("crossbows")) {
            this.disableCommand("crossbowbook", "crossbows");
        }
        if (!this.isModuleEnabled("bubbleelevators")) {
            this.disableCommand("bubbles", "bubbleelevators");
        }
        if (!this.isModuleEnabled("macewind")) {
            this.disableCommand("macewind", "macewind");
        }
        this.log("=== All steps completed. FutureCraft enabled. ===");
        if (this.debugLog != null) {
            this.debugLog.close();
        }
        this.getLogger().info("FutureCraft enabled.");
    }

    public void onDisable() {
        if (this.isModuleEnabled("nether")) {
            DebrisTracker.saveAll(this);
        }
        if (this.bastionGenerator != null) {
            this.bastionGenerator.shutdown();
        }
        if (this.bastionStore != null) {
            this.bastionStore.saveAll();
        }
        if (this.piglinMechanics != null) {
            this.piglinMechanics.shutdown();
        }
        if (this.crossbowMechanics != null) {
            this.crossbowMechanics.shutdown();
        }
        if (this.bubbleElevators != null) {
            this.bubbleElevators.shutdown();
        }
        if (this.maceWind != null) {
            this.maceWind.shutdown();
        }
        this.getLogger().info("FutureCraft disabled.");
        instance = null;
    }

    public static FutureCraft getInstance() {
        return instance;
    }

    @Override
    public FileConfiguration getConfig() {
        return this.netherConfig == null ? super.getConfig() : this.netherConfig;
    }

    @Override
    public void reloadConfig() {
        if (this.netherConfigFile != null && this.netherConfigFile.isFile()) {
            this.netherConfig = YamlConfiguration.loadConfiguration(this.netherConfigFile);
        } else {
            super.reloadConfig();
        }
    }

    @Override
    public void saveConfig() {
        if (this.netherConfig != null && this.netherConfigFile != null) {
            try {
                this.netherConfig.save(this.netherConfigFile);
            } catch (IOException exception) {
                this.getLogger().severe("Could not save nether.yml: " + exception.getMessage());
            }
        } else {
            super.saveConfig();
        }
    }

    public FileConfiguration getModuleConfig() {
        return this.moduleConfig;
    }

    public boolean isModuleEnabled(String moduleName) {
        if (this.moduleConfig == null) {
            return true;
        }
        if ("piglins".equals(moduleName) || "crossbows".equals(moduleName)) {
            return this.moduleConfig.getBoolean("modules.nether", true)
                && this.moduleConfig.getBoolean("modules." + moduleName, true);
        }
        return this.moduleConfig.getBoolean("modules." + moduleName, true);
    }

    public void reloadModuleConfig() {
        if (this.moduleConfigFile != null && this.moduleConfigFile.isFile()) {
            this.moduleConfig = YamlConfiguration.loadConfiguration(this.moduleConfigFile);
        }
    }

    private void loadPluginConfigs() throws IOException {
        File dataFolder = this.getDataFolder();
        if (!dataFolder.exists() && !dataFolder.mkdirs()) {
            throw new IOException("Could not create FutureCraft data folder.");
        }
        this.moduleConfigFile = new File(dataFolder, "config.yml");
        this.netherConfigFile = new File(dataFolder, "nether.yml");

        boolean hasModuleSwitches = false;
        if (this.moduleConfigFile.isFile()) {
            FileConfiguration existing = YamlConfiguration.loadConfiguration(this.moduleConfigFile);
            hasModuleSwitches = existing.getConfigurationSection("modules") != null;
            if (!hasModuleSwitches && !this.netherConfigFile.exists()) {
                Files.copy(this.moduleConfigFile.toPath(), this.netherConfigFile.toPath());
                this.getLogger().info(
                    "Preserved the previous config.yml settings as nether.yml."
                );
            }
        }

        if (!hasModuleSwitches) {
            this.copyBundledResource("config.yml", this.moduleConfigFile);
        }
        if (!this.netherConfigFile.isFile()) {
            this.copyBundledResource("nether.yml", this.netherConfigFile);
        }
        this.moduleConfig = YamlConfiguration.loadConfiguration(this.moduleConfigFile);
        this.netherConfig = YamlConfiguration.loadConfiguration(this.netherConfigFile);
    }

    private void copyBundledResource(String resourceName, File destination) throws IOException {
        InputStream resource = this.getResource(resourceName);
        if (resource == null) {
            throw new IOException("Missing bundled resource: " + resourceName);
        }
        try (InputStream input = resource) {
            Files.copy(input, destination.toPath(), StandardCopyOption.REPLACE_EXISTING);
        }
    }

    private void disableCommand(String commandName, final String moduleName) {
        PluginCommand command = this.getCommand(commandName);
        if (command != null) {
            command.setExecutor((sender, ignoredCommand, label, args) -> {
                sender.sendMessage(
                    ChatColor.RED + "FutureCraft module '" + moduleName
                        + "' is disabled in config.yml."
                );
                return true;
            });
        }
    }

    public ItemStack getExampleBlastResult() {
        ItemStack it = new ItemStack(Material.NETHER_BRICK_ITEM, 1);
        ItemMeta meta = it.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(ChatColor.DARK_PURPLE + "Neth Scrap");
            meta.setLore(Arrays.asList(ChatColor.GRAY + "Refined ancient material"));
            it.setItemMeta(meta);
        }
        try {
            NBTUtil.setStringTag(it, "futurecraft:neth_scrap", "1");
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        return it;
    }
}

