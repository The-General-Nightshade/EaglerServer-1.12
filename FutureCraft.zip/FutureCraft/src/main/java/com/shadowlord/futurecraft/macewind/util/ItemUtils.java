package com.shadowlord.futurecraft.macewind.util;

import java.lang.reflect.Method;
import java.util.Locale;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public final class ItemUtils {
    private static final String TAG_MACE = "shadowlord_mace";
    private static final String TAG_WIND = "shadowlord_windcharge";

    private ItemUtils() {
    }

    public static ItemStack ensureMaceTag(ItemStack item) {
        return applyBooleanTag(item, TAG_MACE, Material.DIAMOND_AXE);
    }

    public static ItemStack ensureWindTag(ItemStack item) {
        return applyBooleanTag(item, TAG_WIND, windChargeMaterial());
    }

    public static boolean isMace(ItemStack item) {
        return item != null
            && item.getType() == Material.DIAMOND_AXE
            && hasBooleanTag(item, TAG_MACE);
    }

    public static boolean isWindCharge(ItemStack item) {
        return item != null
            && isWindChargeMaterial(item.getType())
            && hasBooleanTag(item, TAG_WIND);
    }

    public static ItemStack makeMace() {
        ItemStack item = new ItemStack(Material.DIAMOND_AXE, 1);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(ChatColor.RESET + "Mace");
            item.setItemMeta(meta);
        }
        return ensureMaceTag(item);
    }

    public static ItemStack makeWindCharge() {
        Material material = windChargeMaterial();
        if (material == null) {
            return null;
        }
        ItemStack item = new ItemStack(material, 1);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(ChatColor.RESET + "Wind Charge");
            item.setItemMeta(meta);
        }
        return ensureWindTag(item);
    }

    private static ItemStack applyBooleanTag(ItemStack item, String key, Material expected) {
        if (item == null || expected == null || item.getType() != expected) {
            return item;
        }
        try {
            Object nmsItem = toNmsItem(item);
            if (nmsItem == null) {
                return item;
            }

            // The tag must be created on the same NMS copy that is returned to Bukkit.
            Object tag = getOrCreateTag(nmsItem);
            if (tag == null) {
                return item;
            }
            Method setBoolean = tag.getClass().getMethod(
                "setBoolean",
                String.class,
                Boolean.TYPE
            );
            setBoolean.invoke(tag, key, true);
            Class<?> tagClass = Class.forName(
                nmsItem.getClass().getPackage().getName() + ".NBTTagCompound"
            );
            nmsItem.getClass().getMethod("setTag", tagClass).invoke(nmsItem, tag);
            ItemStack tagged = toBukkitItem(nmsItem);
            return tagged == null ? item : tagged;
        } catch (Exception exception) {
            return item;
        }
    }

    private static boolean hasBooleanTag(ItemStack item, String key) {
        try {
            Object nmsItem = toNmsItem(item);
            if (nmsItem == null) {
                return false;
            }
            Method hasTag = nmsItem.getClass().getMethod("hasTag");
            if (!Boolean.TRUE.equals(hasTag.invoke(nmsItem))) {
                return false;
            }
            Object tag = nmsItem.getClass().getMethod("getTag").invoke(nmsItem);
            if (tag == null) {
                return false;
            }
            Method hasKey = tag.getClass().getMethod("hasKey", String.class);
            Method getBoolean = tag.getClass().getMethod("getBoolean", String.class);
            return Boolean.TRUE.equals(hasKey.invoke(tag, key))
                && Boolean.TRUE.equals(getBoolean.invoke(tag, key));
        } catch (Exception exception) {
            return false;
        }
    }

    private static Object getOrCreateTag(Object nmsItem) throws Exception {
        Class<?> tagClass = Class.forName(
            nmsItem.getClass().getPackage().getName() + ".NBTTagCompound"
        );
        Method hasTag = nmsItem.getClass().getMethod("hasTag");
        if (Boolean.TRUE.equals(hasTag.invoke(nmsItem))) {
            return nmsItem.getClass().getMethod("getTag").invoke(nmsItem);
        }
        Object tag = tagClass.getDeclaredConstructor().newInstance();
        nmsItem.getClass().getMethod("setTag", tagClass).invoke(nmsItem, tag);
        return tag;
    }

    private static Object toNmsItem(ItemStack item) throws Exception {
        String packageName = Bukkit.getServer().getClass().getPackage().getName();
        String version = packageName.substring(packageName.lastIndexOf('.') + 1);
        Class<?> craftItemStack = Class.forName(
            "org.bukkit.craftbukkit." + version + ".inventory.CraftItemStack"
        );
        return craftItemStack.getMethod("asNMSCopy", ItemStack.class).invoke(null, item);
    }

    private static ItemStack toBukkitItem(Object nmsItem) throws Exception {
        String packageName = Bukkit.getServer().getClass().getPackage().getName();
        String version = packageName.substring(packageName.lastIndexOf('.') + 1);
        Class<?> craftItemStack = Class.forName(
            "org.bukkit.craftbukkit." + version + ".inventory.CraftItemStack"
        );
        Object item = craftItemStack.getMethod("asBukkitCopy", nmsItem.getClass())
            .invoke(null, nmsItem);
        return item instanceof ItemStack ? (ItemStack)item : null;
    }

    private static Material windChargeMaterial() {
        Material modern = Material.getMaterial("FIRE_CHARGE");
        return modern != null ? modern : Material.getMaterial("FIREBALL");
    }

    private static boolean isWindChargeMaterial(Material material) {
        Material modern = Material.getMaterial("FIRE_CHARGE");
        Material legacy = Material.getMaterial("FIREBALL");
        return material != null && (material == modern || material == legacy);
    }
}
