package com.shadowlord.futurecraft.blastfurnace;

import com.shadowlord.futurecraft.FutureCraft;
import java.util.Arrays;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.Recipe;
import org.bukkit.inventory.ShapedRecipe;
import org.bukkit.inventory.meta.ItemMeta;

public final class BlastFurnaceRecipe {
    private BlastFurnaceRecipe() {
    }

    public static void register(FutureCraft plugin) {
        if (plugin == null) {
            return;
        }
        ItemStack result = BlastFurnaceRecipe.createBlastFurnaceItem();
        ShapedRecipe recipe = new ShapedRecipe(result);
        recipe.shape(new String[]{"III", "IFI", "III"});
        recipe.setIngredient('I', Material.IRON_INGOT);
        recipe.setIngredient('F', Material.FURNACE);
        Bukkit.addRecipe((Recipe)recipe);
    }

    public static ItemStack createBlastFurnaceItem() {
        ItemStack it = new ItemStack(Material.FURNACE, 1);
        ItemMeta meta = it.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(ChatColor.DARK_RED + "Blast Furnace");
            meta.setLore(Arrays.asList(ChatColor.GRAY + "Right-click to open"));
            it.setItemMeta(meta);
        }
        return it;
    }
}

