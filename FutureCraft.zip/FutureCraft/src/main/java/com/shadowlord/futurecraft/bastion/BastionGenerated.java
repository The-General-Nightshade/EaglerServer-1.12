package com.shadowlord.futurecraft.bastion;

import java.util.ArrayList;
import java.util.List;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.Chest;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.inventory.ItemStack;

public final class BastionGenerated {
    private final String id;
    private final String worldName;
    private final String templateName;
    private final int x;
    private final int y;
    private final int z;
    private final int width;
    private final int height;
    private final int length;
    private final List<BlockSnapshot> snapshots;

    public BastionGenerated(String id, String worldName, String templateName, int x, int y, int z,
                            int width, int height, int length, List<BlockSnapshot> snapshots) {
        this.id = id;
        this.worldName = worldName;
        this.templateName = templateName;
        this.x = x;
        this.y = y;
        this.z = z;
        this.width = width;
        this.height = height;
        this.length = length;
        this.snapshots = new ArrayList<BlockSnapshot>(snapshots);
    }

    public void restore(World world) {
        for (BlockSnapshot snapshot : this.snapshots) {
            Block block = world.getBlockAt(this.x + snapshot.getX(), this.y + snapshot.getY(), this.z + snapshot.getZ());
            block.setTypeIdAndData(snapshot.getTypeId(), snapshot.getData(), false);
            if (snapshot.getInventory() != null && block.getState() instanceof Chest) {
                Chest chest = (Chest)block.getState();
                chest.getBlockInventory().clear();
                ItemStack[] contents = snapshot.getInventory();
                for (int slot = 0; slot < contents.length; ++slot) {
                    if (contents[slot] != null) {
                        chest.getBlockInventory().setItem(slot, contents[slot].clone());
                    }
                }
                chest.update(true, false);
            }
        }
    }

    public void save(ConfigurationSection section) {
        section.set("world", this.worldName);
        section.set("template", this.templateName);
        section.set("x", this.x);
        section.set("y", this.y);
        section.set("z", this.z);
        section.set("width", this.width);
        section.set("height", this.height);
        section.set("length", this.length);
        int index = 0;
        for (BlockSnapshot snapshot : this.snapshots) {
            ConfigurationSection child = section.createSection("snapshots." + index);
            snapshot.save(child);
            ++index;
        }
    }

    public static BastionGenerated load(String id, ConfigurationSection section) {
        List<BlockSnapshot> snapshots = new ArrayList<BlockSnapshot>();
        ConfigurationSection snapshotSection = section.getConfigurationSection("snapshots");
        if (snapshotSection != null) {
            for (String key : snapshotSection.getKeys(false)) {
                ConfigurationSection child = snapshotSection.getConfigurationSection(key);
                if (child != null) {
                    snapshots.add(BlockSnapshot.load(child));
                }
            }
        }
        return new BastionGenerated(
            id,
            section.getString("world"),
            section.getString("template", "unknown"),
            section.getInt("x"),
            section.getInt("y"),
            section.getInt("z"),
            section.getInt("width"),
            section.getInt("height"),
            section.getInt("length"),
            snapshots
        );
    }

    public String getId() {
        return this.id;
    }

    public String getWorldName() {
        return this.worldName;
    }

    public String getTemplateName() {
        return this.templateName;
    }

    public int getX() {
        return this.x;
    }

    public int getY() {
        return this.y;
    }

    public int getZ() {
        return this.z;
    }

    public int getWidth() {
        return this.width;
    }

    public int getHeight() {
        return this.height;
    }

    public int getLength() {
        return this.length;
    }

    public static final class BlockSnapshot {
        private final int x;
        private final int y;
        private final int z;
        private final int typeId;
        private final byte data;
        private final ItemStack[] inventory;

        private BlockSnapshot(int x, int y, int z, int typeId, byte data, ItemStack[] inventory) {
            this.x = x;
            this.y = y;
            this.z = z;
            this.typeId = typeId;
            this.data = data;
            this.inventory = inventory;
        }

        public static BlockSnapshot capture(Block block, int relativeX, int relativeY, int relativeZ) {
            ItemStack[] inventory = null;
            if (block.getState() instanceof Chest) {
                Chest chest = (Chest)block.getState();
                ItemStack[] contents = chest.getBlockInventory().getContents();
                inventory = new ItemStack[contents.length];
                for (int slot = 0; slot < contents.length; ++slot) {
                    if (contents[slot] != null) {
                        inventory[slot] = contents[slot].clone();
                    }
                }
            }
            return new BlockSnapshot(relativeX, relativeY, relativeZ, block.getTypeId(), block.getData(), inventory);
        }

        private static BlockSnapshot load(ConfigurationSection section) {
            ItemStack[] inventory = null;
            ConfigurationSection inventorySection = section.getConfigurationSection("inventory");
            if (inventorySection != null) {
                int size = section.getInt("inventory-size", 27);
                inventory = new ItemStack[size];
                for (int slot = 0; slot < size; ++slot) {
                    inventory[slot] = inventorySection.getItemStack(String.valueOf(slot));
                }
            }
            return new BlockSnapshot(
                section.getInt("x"),
                section.getInt("y"),
                section.getInt("z"),
                section.getInt("type"),
                (byte)section.getInt("data"),
                inventory
            );
        }

        private void save(ConfigurationSection section) {
            section.set("x", this.x);
            section.set("y", this.y);
            section.set("z", this.z);
            section.set("type", this.typeId);
            section.set("data", (int)this.data);
            if (this.inventory != null) {
                section.set("inventory-size", this.inventory.length);
                ConfigurationSection inventorySection = section.createSection("inventory");
                for (int slot = 0; slot < this.inventory.length; ++slot) {
                    if (this.inventory[slot] != null) {
                        inventorySection.set(String.valueOf(slot), this.inventory[slot]);
                    }
                }
            }
        }

        public int getX() {
            return this.x;
        }

        public int getY() {
            return this.y;
        }

        public int getZ() {
            return this.z;
        }

        public int getTypeId() {
            return this.typeId;
        }

        public byte getData() {
            return this.data;
        }

        public ItemStack[] getInventory() {
            return this.inventory;
        }
    }
}