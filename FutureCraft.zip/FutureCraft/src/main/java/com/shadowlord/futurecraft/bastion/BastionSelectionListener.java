package com.shadowlord.futurecraft.bastion;

import com.shadowlord.futurecraft.util.ItemNBT;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public final class BastionSelectionListener
implements Listener {
    private static final String WAND_MARKER = "futurecraft:bastion_wand";
    private final Map<UUID, Selection> selections = new HashMap<UUID, Selection>();

    public static ItemStack createWand() {
        ItemStack wand = new ItemStack(Material.STICK, 1);
        ItemMeta meta = wand.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(ChatColor.GOLD + "Bastion Selection Wand");
            meta.setLore(java.util.Arrays.asList(
                ChatColor.GRAY + "Left-click: select first corner",
                ChatColor.GRAY + "Right-click: select second corner"
            ));
            wand.setItemMeta(meta);
        }
        ItemNBT.setStringTag(wand, WAND_MARKER, "1");
        return wand;
    }

    public static boolean isWand(ItemStack item) {
        return item != null && item.getType() == Material.STICK && ItemNBT.hasMarker(item, WAND_MARKER);
    }

    @EventHandler(priority=EventPriority.HIGH, ignoreCancelled=true)
    public void onInteract(PlayerInteractEvent event) {
        if (event.getHand() != null && event.getHand() != EquipmentSlot.HAND) {
            return;
        }
        Action action = event.getAction();
        if (action != Action.LEFT_CLICK_BLOCK && action != Action.RIGHT_CLICK_BLOCK) {
            return;
        }
        if (!BastionSelectionListener.isWand(event.getItem())) {
            return;
        }
        Block block = event.getClickedBlock();
        if (block == null) {
            return;
        }
        event.setCancelled(true);
        Player player = event.getPlayer();
        Selection selection = this.selections.get(player.getUniqueId());
        if (selection == null) {
            selection = new Selection();
            this.selections.put(player.getUniqueId(), selection);
        }
        if (action == Action.LEFT_CLICK_BLOCK) {
            selection.setFirst(block);
            player.sendMessage(ChatColor.GREEN + "Bastion corner 1 set to "
                + block.getX() + ", " + block.getY() + ", " + block.getZ() + ".");
        } else {
            selection.setSecond(block);
            player.sendMessage(ChatColor.GREEN + "Bastion corner 2 set to "
                + block.getX() + ", " + block.getY() + ", " + block.getZ() + ".");
        }
        if (selection.isComplete()) {
            player.sendMessage(ChatColor.YELLOW + "Selection volume: " + selection.getVolume() + " blocks.");
        }
    }

    public Selection getSelection(Player player) {
        return this.selections.get(player.getUniqueId());
    }

    public static final class Selection {
        private String worldName;
        private int firstX;
        private int firstY;
        private int firstZ;
        private int secondX;
        private int secondY;
        private int secondZ;
        private boolean hasFirst;
        private boolean hasSecond;

        private void setFirst(Block block) {
            this.worldName = block.getWorld().getName();
            this.firstX = block.getX();
            this.firstY = block.getY();
            this.firstZ = block.getZ();
            this.hasFirst = true;
        }

        private void setSecond(Block block) {
            if (this.worldName != null && !this.worldName.equals(block.getWorld().getName())) {
                this.hasFirst = false;
            }
            this.worldName = block.getWorld().getName();
            this.secondX = block.getX();
            this.secondY = block.getY();
            this.secondZ = block.getZ();
            this.hasSecond = true;
        }

        public boolean isComplete() {
            return this.hasFirst && this.hasSecond && this.worldName != null;
        }

        public long getVolume() {
            if (!this.isComplete()) {
                return 0L;
            }
            return (long)(Math.abs(this.firstX - this.secondX) + 1)
                * (long)(Math.abs(this.firstY - this.secondY) + 1)
                * (long)(Math.abs(this.firstZ - this.secondZ) + 1);
        }

        public String getWorldName() {
            return this.worldName;
        }

        public int getMinX() {
            return Math.min(this.firstX, this.secondX);
        }

        public int getMinY() {
            return Math.min(this.firstY, this.secondY);
        }

        public int getMinZ() {
            return Math.min(this.firstZ, this.secondZ);
        }

        public int getMaxX() {
            return Math.max(this.firstX, this.secondX);
        }

        public int getMaxY() {
            return Math.max(this.firstY, this.secondY);
        }

        public int getMaxZ() {
            return Math.max(this.firstZ, this.secondZ);
        }
    }
}