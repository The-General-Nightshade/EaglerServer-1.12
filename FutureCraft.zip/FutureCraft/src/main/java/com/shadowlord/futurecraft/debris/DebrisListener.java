package com.shadowlord.futurecraft.debris;

import com.shadowlord.futurecraft.FutureCraft;
import com.shadowlord.futurecraft.debris.DebrisItem;
import com.shadowlord.futurecraft.debris.DebrisTracker;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;

public class DebrisListener
implements Listener {
    @EventHandler(priority=EventPriority.HIGH, ignoreCancelled=true)
    public void onBlockBreak(BlockBreakEvent e) {
        int z;
        int y;
        int x;
        Block block = e.getBlock();
        if (block.getWorld().getEnvironment() != World.Environment.NETHER) {
            return;
        }
        if (block.getType() != Material.OBSIDIAN) {
            return;
        }
        String worldName = block.getWorld().getName();
        if (!DebrisTracker.isDebrisBlock(worldName, x = block.getX(), y = block.getY(), z = block.getZ())) {
            return;
        }
        Player p = e.getPlayer();
        if (p.getItemInHand() == null || p.getItemInHand().getType() != Material.DIAMOND_PICKAXE) {
            p.sendMessage(ChatColor.YELLOW + "You need a diamond pickaxe to mine Ancient Debris.");
            e.setCancelled(true);
            return;
        }
        e.setCancelled(true);
        block.setType(Material.AIR);
        block.getWorld().dropItemNaturally(block.getLocation().add(0.5, 0.5, 0.5), DebrisItem.createDebris(1));
        DebrisTracker.removeBlock(worldName, x, y, z);
        DebrisTracker.saveWorld(FutureCraft.getInstance(), worldName);
    }
}

