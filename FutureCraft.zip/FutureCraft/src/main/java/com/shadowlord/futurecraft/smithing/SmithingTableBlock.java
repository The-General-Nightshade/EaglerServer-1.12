package com.shadowlord.futurecraft.smithing;

import com.shadowlord.futurecraft.FutureCraft;
import com.shadowlord.futurecraft.smithing.SmithingGUI;
import com.shadowlord.futurecraft.smithing.SmithingTableItem;
import java.util.HashSet;
import java.util.Set;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;

public class SmithingTableBlock
implements Listener {
    private static final Set<Location> smithingLocations = new HashSet<Location>();
    private final FutureCraft plugin;

    public SmithingTableBlock(FutureCraft plugin) {
        this.plugin = plugin;
    }

    public SmithingTableBlock() {
        this.plugin = null;
    }

    @EventHandler(priority=EventPriority.MONITOR, ignoreCancelled=true)
    public void onPlace(BlockPlaceEvent e) {
        ItemStack inHand = e.getItemInHand();
        if (inHand == null) {
            return;
        }
        if (!SmithingTableItem.isSmithingTable(inHand)) {
            return;
        }
        smithingLocations.add(e.getBlock().getLocation());
        e.getPlayer().sendMessage(ChatColor.GREEN + "Smithing Table placed!");
    }

    @EventHandler(priority=EventPriority.HIGH)
    public void onInteract(PlayerInteractEvent e) {
        if (e.getAction() != Action.RIGHT_CLICK_BLOCK) {
            return;
        }
        Block block = e.getClickedBlock();
        if (block == null || block.getType() != Material.WORKBENCH) {
            return;
        }
        Location loc = block.getLocation();
        if (!smithingLocations.contains(loc)) {
            return;
        }
        e.setCancelled(true);
        SmithingGUI.openGui(e.getPlayer());
    }

    @EventHandler(priority=EventPriority.HIGH, ignoreCancelled=true)
    public void onBreak(BlockBreakEvent e) {
        Block block = e.getBlock();
        if (block == null || block.getType() != Material.WORKBENCH) {
            return;
        }
        Location loc = block.getLocation();
        if (!smithingLocations.remove(loc)) {
            return;
        }
        e.setCancelled(true);
        block.setType(Material.AIR);
        block.getWorld().dropItemNaturally(loc.clone().add(0.5, 0.5, 0.5), SmithingTableItem.create());
    }

    public static boolean isSmithingTable(Block b) {
        if (b == null) {
            return false;
        }
        return b.getType() == Material.WORKBENCH && smithingLocations.contains(b.getLocation());
    }

    public static boolean isSmithingTable(Location loc) {
        return loc != null && smithingLocations.contains(loc);
    }

    public static void register(Location loc) {
        if (loc != null) {
            smithingLocations.add(loc);
        }
    }

    public static void unregister(Location loc) {
        if (loc != null) {
            smithingLocations.remove(loc);
        }
    }

    public static void clearAll() {
        smithingLocations.clear();
    }
}

