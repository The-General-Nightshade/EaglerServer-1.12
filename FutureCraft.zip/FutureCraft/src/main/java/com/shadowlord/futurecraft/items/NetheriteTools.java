package com.shadowlord.futurecraft.items;

import com.shadowlord.futurecraft.util.Compat;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class NetheriteTools {
    public static void applyToolStats(ItemStack item) {
        if (item == null) {
            return;
        }
        ItemMeta meta = item.getItemMeta();
        if (meta == null) {
            return;
        }
        Compat.addAttributeOrFallback(meta, null, null, Object.class, Object.class);
        item.setItemMeta(meta);
    }
}

