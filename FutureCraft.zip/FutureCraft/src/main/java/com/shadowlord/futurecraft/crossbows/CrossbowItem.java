package com.shadowlord.futurecraft.crossbows;

import com.shadowlord.futurecraft.util.NBTUtil;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public final class CrossbowItem {
    public static final String QUICK_CHARGE = "quick_charge";
    public static final String MULTISHOT = "multishot";
    public static final String PIERCING = "piercing";

    private static final String CROSSBOW_TAG = "futurecraft_crossbow";
    private static final String LOADED_AT_TAG = "futurecraft_crossbow_loaded_at";
    private static final String BOOK_ENCHANT_TAG = "futurecraft_crossbow_book_enchant";
    private static final String BOOK_LEVEL_TAG = "futurecraft_crossbow_book_level";
    private static final String LOADED_LORE_PREFIX = ChatColor.DARK_GRAY + "FC_LoadedAt:";
    private static final String SIGNATURE = ChatColor.DARK_GRAY + "FutureCraft Crossbow";

    private CrossbowItem() {
    }

    public static ItemStack create() {
        ItemStack crossbow = new ItemStack(Material.BOW);
        ItemMeta meta = crossbow.getItemMeta();
        meta.setDisplayName(ChatColor.GOLD + "Crossbow");
        meta.setLore(Arrays.asList(
            ChatColor.GRAY + "Draw to load, then tap right-click to fire.",
            SIGNATURE
        ));
        crossbow.setItemMeta(meta);
        NBTUtil.setStringTag(crossbow, CROSSBOW_TAG, "1");
        return crossbow;
    }

    public static boolean isCrossbow(ItemStack item) {
        if (item == null || item.getType() != Material.BOW) {
            return false;
        }
        if (NBTUtil.hasTag(item, CROSSBOW_TAG)) {
            return true;
        }
        ItemMeta meta = item.getItemMeta();
        return meta != null && meta.hasLore() && meta.getLore().contains(SIGNATURE);
    }

    public static long getLoadedAt(ItemStack item) {
        try {
            String value = NBTUtil.getStringTag(item, LOADED_AT_TAG);
            if (value != null) {
                return Math.max(0L, Long.parseLong(value));
            }
        } catch (NumberFormatException ignored) {
            // Fall through to the lore representation for servers where NBT is unavailable.
        }
        ItemMeta meta = item == null ? null : item.getItemMeta();
        if (meta == null || !meta.hasLore()) {
            return 0L;
        }
        for (String line : meta.getLore()) {
            if (line != null && line.startsWith(LOADED_LORE_PREFIX)) {
                try {
                    return Math.max(0L,
                        Long.parseLong(line.substring(LOADED_LORE_PREFIX.length())));
                } catch (NumberFormatException ignored) {
                    return 0L;
                }
            }
        }
        return 0L;
    }

    public static void setLoadedAt(ItemStack item, long timeMillis) {
        long loadedAt = Math.max(0L, timeMillis);
        NBTUtil.setStringTag(item, LOADED_AT_TAG, Long.toString(loadedAt));
        updateLore(item, null, -1, loadedAt);
    }

    public static int getEnchantLevel(ItemStack item, String enchantment) {
        if (!isEnchantment(enchantment) || item == null) {
            return 0;
        }
        try {
            String value = NBTUtil.getStringTag(item, enchantmentTag(enchantment));
            if (value != null) {
                return Math.max(0, Integer.parseInt(value));
            }
        } catch (NumberFormatException ignored) {
            // Fall through to the readable lore representation.
        }
        ItemMeta meta = item.getItemMeta();
        if (meta == null || !meta.hasLore()) {
            return 0;
        }
        String prefix = enchantmentName(enchantment) + " ";
        for (String line : meta.getLore()) {
            String plain = ChatColor.stripColor(line);
            if (plain != null && plain.startsWith(prefix)) {
                return parseRoman(plain.substring(prefix.length()));
            }
        }
        return 0;
    }

    public static ItemStack withEnchantment(ItemStack item, String enchantment, int level) {
        if (!isCrossbow(item) || !isEnchantment(enchantment)) {
            return item == null ? null : item.clone();
        }
        int boundedLevel = Math.max(0, Math.min(maxLevel(enchantment), level));
        ItemStack result = item.clone();
        NBTUtil.setStringTag(result, enchantmentTag(enchantment), Integer.toString(boundedLevel));
        updateLore(result, enchantment, boundedLevel, -1L);
        return result;
    }

    public static ItemStack createEnchantmentBook(String enchantment, int level) {
        if (!isEnchantment(enchantment)) {
            return null;
        }
        int boundedLevel = Math.max(1, Math.min(maxLevel(enchantment), level));
        ItemStack book = new ItemStack(Material.ENCHANTED_BOOK);
        ItemMeta meta = book.getItemMeta();
        meta.setDisplayName(ChatColor.LIGHT_PURPLE + enchantmentName(enchantment) + " "
            + roman(boundedLevel) + " Book");
        meta.setLore(Arrays.asList(
            ChatColor.GRAY + "Apply in an anvil to a FutureCraft Crossbow."
        ));
        book.setItemMeta(meta);
        NBTUtil.setStringTag(book, BOOK_ENCHANT_TAG, enchantment);
        NBTUtil.setStringTag(book, BOOK_LEVEL_TAG, Integer.toString(boundedLevel));
        return book;
    }

    public static String getBookEnchantment(ItemStack book) {
        if (book == null || book.getType() != Material.ENCHANTED_BOOK) {
            return null;
        }
        String tagged = NBTUtil.getStringTag(book, BOOK_ENCHANT_TAG);
        if (isEnchantment(tagged)) {
            return tagged;
        }
        ItemMeta meta = book.getItemMeta();
        if (meta == null || !meta.hasDisplayName()) {
            return null;
        }
        String name = ChatColor.stripColor(meta.getDisplayName());
        for (String enchantment : enchantments()) {
            if (name != null && name.startsWith(enchantmentName(enchantment) + " ")
                && name.endsWith(" Book")) {
                return enchantment;
            }
        }
        return null;
    }

    public static int getBookLevel(ItemStack book) {
        try {
            String tagged = NBTUtil.getStringTag(book, BOOK_LEVEL_TAG);
            if (tagged != null) {
                return Integer.parseInt(tagged);
            }
        } catch (NumberFormatException ignored) {
            // The display name below also carries the level.
        }
        String enchantment = getBookEnchantment(book);
        if (enchantment == null) {
            return 0;
        }
        String name = ChatColor.stripColor(book.getItemMeta().getDisplayName());
        String prefix = enchantmentName(enchantment) + " ";
        if (name == null) {
            return 0;
        }
        int end = name.length() - " Book".length();
        if (end <= prefix.length()) {
            return 0;
        }
        return parseRoman(name.substring(prefix.length(), end));
    }

    public static boolean isCompatible(String enchantment, ItemStack item) {
        if (!isEnchantment(enchantment)) {
            return false;
        }
        if (QUICK_CHARGE.equals(enchantment)) {
            return true;
        }
        String incompatible = MULTISHOT.equals(enchantment) ? PIERCING : MULTISHOT;
        return getEnchantLevel(item, incompatible) == 0;
    }

    public static String normalizeEnchantment(String value) {
        if (value == null) {
            return null;
        }
        String normalized = value.trim().toLowerCase(Locale.ROOT)
            .replace('-', '_').replace(' ', '_');
        if ("quick".equals(normalized) || "quickcharge".equals(normalized)) {
            normalized = QUICK_CHARGE;
        }
        return isEnchantment(normalized) ? normalized : null;
    }

    public static boolean isEnchantment(String enchantment) {
        return QUICK_CHARGE.equals(enchantment)
            || MULTISHOT.equals(enchantment)
            || PIERCING.equals(enchantment);
    }

    public static int maxLevel(String enchantment) {
        if (QUICK_CHARGE.equals(enchantment)) {
            return 3;
        }
        if (PIERCING.equals(enchantment)) {
            return 4;
        }
        return 1;
    }

    public static List<String> enchantments() {
        return Arrays.asList(QUICK_CHARGE, MULTISHOT, PIERCING);
    }

    public static String enchantmentName(String enchantment) {
        if (QUICK_CHARGE.equals(enchantment)) {
            return "Quick Charge";
        }
        if (MULTISHOT.equals(enchantment)) {
            return "Multishot";
        }
        if (PIERCING.equals(enchantment)) {
            return "Piercing";
        }
        return "Unknown";
    }

    private static String enchantmentTag(String enchantment) {
        return "futurecraft_crossbow_enchant_" + enchantment;
    }

    private static void updateLore(ItemStack item) {
        updateLore(item, null, -1, -1L);
    }

    private static void updateLore(
        ItemStack item,
        String overriddenEnchantment,
        int overriddenLevel,
        long overriddenLoadedAt
    ) {
        List<String> lore = new ArrayList<String>();
        lore.add(ChatColor.GRAY + "Draw to load, then tap right-click to fire.");
        for (String enchantment : enchantments()) {
            int level = enchantment.equals(overriddenEnchantment)
                ? overriddenLevel : getEnchantLevel(item, enchantment);
            if (level > 0) {
                lore.add(ChatColor.BLUE + enchantmentName(enchantment) + " " + roman(level));
            }
        }
        long loadedAt = overriddenLoadedAt >= 0L ? overriddenLoadedAt : getLoadedAt(item);
        if (loadedAt > 0L) {
            lore.add(LOADED_LORE_PREFIX + loadedAt);
        }
        lore.add(SIGNATURE);
        ItemMeta meta = item.getItemMeta();
        meta.setLore(lore);
        item.setItemMeta(meta);
    }

    private static String roman(int level) {
        switch (level) {
            case 1: return "I";
            case 2: return "II";
            case 3: return "III";
            case 4: return "IV";
            default: return Integer.toString(level);
        }
    }

    private static int parseRoman(String value) {
        if ("I".equals(value)) return 1;
        if ("II".equals(value)) return 2;
        if ("III".equals(value)) return 3;
        if ("IV".equals(value)) return 4;
        return 0;
    }
}
