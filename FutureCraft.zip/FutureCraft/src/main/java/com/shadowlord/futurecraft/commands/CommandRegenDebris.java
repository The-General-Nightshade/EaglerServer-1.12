package com.shadowlord.futurecraft.commands;

import com.shadowlord.futurecraft.FutureCraft;
import com.shadowlord.futurecraft.debris.DebrisGenerator;
import com.shadowlord.futurecraft.debris.DebrisItem;
import com.shadowlord.futurecraft.debris.DebrisTracker;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Chunk;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public class CommandRegenDebris
implements CommandExecutor,
TabCompleter {
    private static final String PERM = "futurecraft.regendebris";

    /*
     * WARNING - void declaration
     */
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission(PERM) && !sender.isOp()) {
            sender.sendMessage(ChatColor.RED + "You don't have permission to run this command.");
            return true;
        }
        String worldName = args.length >= 1 ? args[0] : "world_nether";
        World w = Bukkit.getWorld((String)worldName);
        if (w == null) {
            sender.sendMessage(ChatColor.RED + "World not found: " + worldName);
            return true;
        }
        FutureCraft plugin = FutureCraft.getInstance();
        if (plugin == null) {
            sender.sendMessage(ChatColor.RED + "Plugin instance not available.");
            return true;
        }
        int removedBlocks = 0;
        Set<String> blocks = DebrisTracker.getBlocks(worldName);
        for (String string : blocks) {
            String[] parts = string.split(",");
            if (parts.length != 3) continue;
            try {
                int z;
                int y;
                int x = Integer.parseInt(parts[0].trim());
                Block b = w.getBlockAt(x, y = Integer.parseInt(parts[1].trim()), z = Integer.parseInt(parts[2].trim()));
                if (b.getType() != Material.OBSIDIAN) continue;
                b.setType(Material.NETHERRACK);
                ++removedBlocks;
            }
            catch (NumberFormatException x) {}
        }
        int removedEntities = 0;
        for (org.bukkit.entity.Entity ent : w.getEntities()) {
            ItemStack stack;
            if (!(ent instanceof Item) || !DebrisItem.isDebris(stack = ((Item)ent).getItemStack())) continue;
            ent.remove();
            ++removedEntities;
        }
        int removedFromPlayers = 0;
        for (Player p : Bukkit.getOnlinePlayers()) {
            for (int i = 0; i < p.getInventory().getSize(); ++i) {
                ItemStack s = p.getInventory().getItem(i);
                if (!DebrisItem.isDebris(s)) continue;
                p.getInventory().setItem(i, null);
                ++removedFromPlayers;
            }
        }
        DebrisTracker.clearWorld(worldName);
        DebrisTracker.deleteFiles(plugin, worldName);
        DebrisGenerator gen = new DebrisGenerator(plugin);
        int regenCount = 0;
        for (Chunk chunk : w.getLoadedChunks()) {
            gen.generateForChunkAt(w, chunk.getX(), chunk.getZ());
            ++regenCount;
        }
        DebrisTracker.saveWorld(plugin, worldName);
        sender.sendMessage(ChatColor.GREEN + "Regenerated debris in " + w.getName() + ". Cleared " + removedBlocks + " blocks, " + removedEntities + " dropped items, " + removedFromPlayers + " from players. Regenerated in " + regenCount + " loaded chunks.");
        return true;
    }

    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            ArrayList<String> names = new ArrayList<String>();
            for (World w : Bukkit.getWorlds()) {
                if (w.getEnvironment() != World.Environment.NETHER) continue;
                names.add(w.getName());
            }
            return names;
        }
        return Collections.emptyList();
    }
}

