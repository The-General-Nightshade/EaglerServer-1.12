package com.shadowlord.futurecraft.smithing;

import com.shadowlord.futurecraft.items.NetheriteIngotItem;
import com.shadowlord.futurecraft.items.TemplateDefaults;
import com.shadowlord.futurecraft.items.UpgradeTemplateItem;
import com.shadowlord.futurecraft.util.NBTUtil;
import java.util.HashMap;
import java.util.Map;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class SmithingManager {
    private static final String UPGRADED_MARKER = "futurecraft:netherite_upgraded";
    private static final Map<Material, String> NETHERITE_NAMES = new HashMap<Material, String>();

    public static ItemStack[] identifyRoles(ItemStack a, ItemStack b, ItemStack c) {
        ItemStack[] items = new ItemStack[]{a, b, c};
        ItemStack template = null;
        ItemStack base = null;
        ItemStack addition = null;
        for (ItemStack item : items) {
            if (item == null || item.getType() == Material.AIR) continue;
            if (template == null && UpgradeTemplateItem.isTemplate(item)) {
                template = item;
                continue;
            }
            if (addition == null && NetheriteIngotItem.isIngot(item)) {
                addition = item;
                continue;
            }
            if (base != null) continue;
            base = item;
        }
        return new ItemStack[]{template, base, addition};
    }

    public static boolean canUpgrade(ItemStack template, ItemStack base, ItemStack addition) {
        if (template == null || base == null || addition == null) {
            return false;
        }
        if (!UpgradeTemplateItem.isTemplate(template)) {
            return false;
        }
        if (!NetheriteIngotItem.isIngot(addition)) {
            return false;
        }
        return !NBTUtil.hasTag(base, UPGRADED_MARKER);
    }

    public static ItemStack preview(ItemStack a, ItemStack b, ItemStack c) {
        ItemMeta meta;
        String[] attrs;
        String key;
        Map<String, String> map;
        String spec;
        ItemStack addition;
        ItemStack base;
        ItemStack[] roles = SmithingManager.identifyRoles(a, b, c);
        ItemStack template = roles[0];
        if (!SmithingManager.canUpgrade(template, base = roles[1], addition = roles[2])) {
            return null;
        }
        String mapping = UpgradeTemplateItem.getMapping(template);
        if (mapping == null || mapping.isEmpty()) {
            mapping = TemplateDefaults.defaultNetheriteMapping();
        }
        if ((spec = (map = SmithingManager.parseMapping(mapping)).get(key = base.getType().name())) == null && key.equals("DIAMOND_SPADE")) {
            spec = map.get("DIAMOND_SHOVEL");
        }
        if (spec == null && key.equals("DIAMOND_SHOVEL")) {
            spec = map.get("DIAMOND_SPADE");
        }
        if (spec == null && SmithingManager.isDiamondTool(base.getType())) {
            spec = map.get("DIAMOND_TOOL");
        }
        if (spec == null && SmithingManager.isDiamondArmor(base.getType())) {
            spec = map.get("DIAMOND_ARMOR");
        }
        if (spec == null) {
            return null;
        }
        ItemStack result = base.clone();
        for (String attr : attrs = spec.split(",")) {
            double amount;
            String[] parts;
            if ((attr = attr.trim()).isEmpty() || (parts = attr.split(":")).length < 2) continue;
            String attrName = parts[0];
            try {
                amount = Double.parseDouble(parts[1]);
            }
            catch (Exception ex) {
                continue;
            }
            int op = 0;
            if (parts.length >= 3) {
                try {
                    op = Integer.parseInt(parts[2]);
                }
                catch (Exception exception) {
                    // empty catch block
                }
            }
            NBTUtil.addAttributeModifier(result, attrName, amount, op, null);
        }
        String netheriteName = NETHERITE_NAMES.get(base.getType());
        if (netheriteName != null && (meta = result.getItemMeta()) != null) {
            meta.setDisplayName(ChatColor.DARK_AQUA + netheriteName);
            result.setItemMeta(meta);
        }
        NBTUtil.setStringTag(result, UPGRADED_MARKER, "1");
        return result;
    }

    public static boolean upgradeAndConsume(Inventory inv, Player player) {
        ItemStack c;
        ItemStack b;
        if (inv == null || player == null) {
            return false;
        }
        ItemStack a = inv.getItem(10);
        ItemStack result = SmithingManager.preview(a, b = inv.getItem(11), c = inv.getItem(12));
        if (result == null) {
            return false;
        }
        if (inv.getItem(16) == null) {
            inv.setItem(16, result);
        } else {
            player.getInventory().addItem(new ItemStack[]{result});
        }
        SmithingManager.consumeOne(inv, 10);
        SmithingManager.consumeOne(inv, 11);
        SmithingManager.consumeOne(inv, 12);
        return true;
    }

    private static void consumeOne(Inventory inv, int slot) {
        ItemStack it = inv.getItem(slot);
        if (it == null) {
            return;
        }
        int amt = it.getAmount() - 1;
        if (amt <= 0) {
            inv.setItem(slot, null);
        } else {
            it.setAmount(amt);
            inv.setItem(slot, it);
        }
    }

    private static Map<String, String> parseMapping(String mapping) {
        String[] entries;
        HashMap<String, String> out = new HashMap<String, String>();
        for (String e : entries = mapping.split("\\|")) {
            String[] kv = e.split("=", 2);
            if (kv.length != 2) continue;
            out.put(kv[0].trim(), kv[1].trim());
        }
        return out;
    }

    private static boolean isDiamondTool(Material m) {
        if (m == null) {
            return false;
        }
        return m == Material.DIAMOND_SWORD || m == Material.DIAMOND_PICKAXE || m == Material.DIAMOND_AXE || m == Material.DIAMOND_SPADE || m == Material.DIAMOND_HOE;
    }

    private static boolean isDiamondArmor(Material m) {
        if (m == null) {
            return false;
        }
        return m == Material.DIAMOND_HELMET || m == Material.DIAMOND_CHESTPLATE || m == Material.DIAMOND_LEGGINGS || m == Material.DIAMOND_BOOTS;
    }

    static {
        NETHERITE_NAMES.put(Material.DIAMOND_SWORD, "Netherite Sword");
        NETHERITE_NAMES.put(Material.DIAMOND_PICKAXE, "Netherite Pickaxe");
        NETHERITE_NAMES.put(Material.DIAMOND_AXE, "Netherite Axe");
        NETHERITE_NAMES.put(Material.DIAMOND_SPADE, "Netherite Shovel");
        NETHERITE_NAMES.put(Material.DIAMOND_HOE, "Netherite Hoe");
        NETHERITE_NAMES.put(Material.DIAMOND_HELMET, "Netherite Helmet");
        NETHERITE_NAMES.put(Material.DIAMOND_CHESTPLATE, "Netherite Chestplate");
        NETHERITE_NAMES.put(Material.DIAMOND_LEGGINGS, "Netherite Leggings");
        NETHERITE_NAMES.put(Material.DIAMOND_BOOTS, "Netherite Boots");
    }
}

