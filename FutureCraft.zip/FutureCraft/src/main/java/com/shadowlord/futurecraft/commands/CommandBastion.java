package com.shadowlord.futurecraft.commands;

import com.shadowlord.futurecraft.bastion.BastionGenerator;
import com.shadowlord.futurecraft.bastion.BastionLootGUI;
import com.shadowlord.futurecraft.bastion.BastionSelectionListener;
import com.shadowlord.futurecraft.bastion.BastionStore;
import com.shadowlord.futurecraft.bastion.BastionTemplate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

public final class CommandBastion
implements CommandExecutor,
TabCompleter {
    private static final String PERMISSION = "futurecraft.bastion";
    private final FutureCraftBridge bridge;

    public CommandBastion(BastionStore store, BastionGenerator generator, BastionSelectionListener selection) {
        this.bridge = new FutureCraftBridge(store, generator, selection);
    }

    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!this.hasPermission(sender)) {
            sender.sendMessage(ChatColor.RED + "You don't have permission to manage bastions.");
            return true;
        }
        if (args.length == 0) {
            this.sendHelp(sender);
            return true;
        }
        String subcommand = args[0].toLowerCase();
        if ("wand".equals(subcommand)) {
            return this.giveWand(sender);
        }
        if ("save".equals(subcommand)) {
            return this.saveTemplate(sender, args);
        }
        if ("list".equals(subcommand)) {
            sender.sendMessage(ChatColor.YELLOW + "Bastion templates: "
                + (this.bridge.store.getTemplateNames().isEmpty()
                    ? "(none)"
                    : String.join(", ", this.bridge.store.getTemplateNames())));
            return true;
        }
        if ("delete".equals(subcommand)) {
            if (args.length < 2) {
                sender.sendMessage(ChatColor.RED + "Usage: /bastion delete <template>");
                return true;
            }
            sender.sendMessage(this.bridge.store.deleteTemplate(args[1])
                ? ChatColor.GREEN + "Deleted bastion template " + args[1] + "."
                : ChatColor.RED + "Template not found: " + args[1]);
            return true;
        }
        if ("loot".equals(subcommand)) {
            if (!(sender instanceof Player)) {
                sender.sendMessage(ChatColor.RED + "Only players can open the loot editor.");
                return true;
            }
            this.bridge.lootGui.open((Player)sender);
            return true;
        }
        if ("regenerate".equals(subcommand)) {
            return this.regenerate(sender, args);
        }
        this.sendHelp(sender);
        return true;
    }

    private boolean giveWand(CommandSender sender) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + "Only players can use the bastion selection wand.");
            return true;
        }
        ((Player)sender).getInventory().addItem(BastionSelectionListener.createWand());
        sender.sendMessage(ChatColor.GREEN + "Bastion selection wand received.");
        return true;
    }

    private boolean saveTemplate(CommandSender sender, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + "Only players can save a bastion selection.");
            return true;
        }
        if (args.length < 2) {
            sender.sendMessage(ChatColor.RED + "Usage: /bastion save <name>");
            return true;
        }
        String name = args[1].toLowerCase();
        if (!name.matches("[a-z0-9_-]{1,32}")) {
            sender.sendMessage(ChatColor.RED + "Template names may contain only letters, numbers, underscores, and hyphens.");
            return true;
        }
        Player player = (Player)sender;
        BastionSelectionListener.Selection selection = this.bridge.selection.getSelection(player);
        if (selection == null || !selection.isComplete()) {
            sender.sendMessage(ChatColor.RED + "Select two corners first with /bastion wand.");
            return true;
        }
        World world = Bukkit.getWorld(selection.getWorldName());
        if (world == null || !world.getName().equals(player.getWorld().getName())) {
            sender.sendMessage(ChatColor.RED + "Your selection world is no longer loaded.");
            return true;
        }
        long maxVolume = this.bridge.store.getPlugin().getConfig().getLong("bastions.capture.max-volume", 100000L);
        if (selection.getVolume() > maxVolume) {
            sender.sendMessage(ChatColor.RED + "Selection is too large. Maximum volume is " + maxVolume + " blocks.");
            return true;
        }
        try {
            BastionTemplate template = BastionTemplate.capture(
                name,
                world,
                new Location(world, selection.getMinX(), selection.getMinY(), selection.getMinZ()),
                new Location(world, selection.getMaxX(), selection.getMaxY(), selection.getMaxZ())
            );
            this.bridge.store.saveTemplate(template);
            sender.sendMessage(ChatColor.GREEN + "Saved bastion template " + name + " with "
                + template.getBlocks().size() + " captured blocks.");
        }
        catch (Exception ex) {
            sender.sendMessage(ChatColor.RED + "Could not save template: " + ex.getMessage());
        }
        return true;
    }

    private boolean regenerate(CommandSender sender, String[] args) {
        World world = null;
        if (args.length >= 2) {
            world = Bukkit.getWorld(args[1]);
        } else if (sender instanceof Player && ((Player)sender).getWorld().getEnvironment() == World.Environment.NETHER) {
            world = ((Player)sender).getWorld();
        } else {
            for (World candidate : Bukkit.getWorlds()) {
                if (candidate.getEnvironment() == World.Environment.NETHER) {
                    world = candidate;
                    break;
                }
            }
        }
        if (world == null || world.getEnvironment() != World.Environment.NETHER) {
            sender.sendMessage(ChatColor.RED + "Specify a loaded Nether world: /bastion regenerate <world>");
            return true;
        }
        this.bridge.generator.regenerate(world);
        sender.sendMessage(ChatColor.YELLOW + "Existing generated bastions are being restored and removed in "
            + world.getName() + ". Replacement generation is queued across loaded chunks.");
        return true;
    }

    private boolean hasPermission(CommandSender sender) {
        return sender.isOp() || sender.hasPermission(PERMISSION);
    }

    private void sendHelp(CommandSender sender) {
        sender.sendMessage(ChatColor.GOLD + "FutureCraft Bastions");
        sender.sendMessage(ChatColor.YELLOW + "/bastion wand" + ChatColor.GRAY + " - get the region selection wand");
        sender.sendMessage(ChatColor.YELLOW + "/bastion save <name>" + ChatColor.GRAY + " - save the selected template");
        sender.sendMessage(ChatColor.YELLOW + "/bastion list" + ChatColor.GRAY + " - list saved templates");
        sender.sendMessage(ChatColor.YELLOW + "/bastion delete <name>" + ChatColor.GRAY + " - delete a template");
        sender.sendMessage(ChatColor.YELLOW + "/bastion loot" + ChatColor.GRAY + " - edit the loot table");
        sender.sendMessage(ChatColor.YELLOW + "/bastion regenerate [world]" + ChatColor.GRAY + " - replace generated bastions");
    }

    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            return this.prefix(Arrays.asList("wand", "save", "list", "delete", "loot", "regenerate"), args[0]);
        }
        if (args.length == 2 && ("delete".equalsIgnoreCase(args[0]))) {
            return this.prefix(this.bridge.store.getTemplateNames(), args[1]);
        }
        if (args.length == 2 && "regenerate".equalsIgnoreCase(args[0])) {
            List<String> worlds = new ArrayList<String>();
            for (World world : Bukkit.getWorlds()) {
                if (world.getEnvironment() == World.Environment.NETHER) {
                    worlds.add(world.getName());
                }
            }
            return this.prefix(worlds, args[1]);
        }
        return new ArrayList<String>();
    }

    private List<String> prefix(List<String> values, String prefix) {
        List<String> result = new ArrayList<String>();
        String lower = prefix.toLowerCase();
        for (String value : values) {
            if (value.toLowerCase().startsWith(lower)) {
                result.add(value);
            }
        }
        return result;
    }

    private static final class FutureCraftBridge {
        private final BastionStore store;
        private final BastionGenerator generator;
        private final BastionSelectionListener selection;
        private final BastionLootGUI lootGui;

        private FutureCraftBridge(BastionStore store, BastionGenerator generator, BastionSelectionListener selection) {
            this.store = store;
            this.generator = generator;
            this.selection = selection;
            this.lootGui = new BastionLootGUI(store);
        }
    }
}