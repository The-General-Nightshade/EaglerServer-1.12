package com.shadowlord.futurecraft.bubbleelevators.listeners;

import com.shadowlord.futurecraft.bubbleelevators.BubbleElevatorsModule;
import org.bukkit.entity.EnderPearl;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.ProjectileLaunchEvent;
import org.bukkit.metadata.FixedMetadataValue;

public final class EnderPearlProtectionListener implements Listener {
    private final BubbleElevatorsModule module;

    public EnderPearlProtectionListener(BubbleElevatorsModule module) {
        this.module = module;
    }

    @EventHandler
    public void onProjectileLaunch(ProjectileLaunchEvent event) {
        if (!(event.getEntity() instanceof EnderPearl)) {
            return;
        }
        EnderPearl pearl = (EnderPearl)event.getEntity();
        String tagName = this.module.getConfig().getString(
            "pearl-tag-name",
            "§bStasisPearl"
        );
        String metadataKey = this.module.getConfig().getString(
            "pearl-metadata-key",
            "bubbleelevators_stasis"
        );
        pearl.setCustomName(tagName);
        pearl.setCustomNameVisible(false);
        pearl.setMetadata(metadataKey, new FixedMetadataValue(this.module.getHost(), true));
    }
}
