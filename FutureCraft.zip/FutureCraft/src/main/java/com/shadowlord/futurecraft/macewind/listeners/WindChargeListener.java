package com.shadowlord.futurecraft.macewind.listeners;

import com.shadowlord.futurecraft.macewind.MaceWindModule;
import com.shadowlord.futurecraft.macewind.util.ItemUtils;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;
import org.bukkit.Effect;
import org.bukkit.Location;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.BlockState;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.entity.SmallFireball;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.material.Button;
import org.bukkit.material.Lever;
import org.bukkit.material.MaterialData;
import org.bukkit.material.Openable;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.metadata.MetadataValue;
import org.bukkit.projectiles.ProjectileSource;
import org.bukkit.util.Vector;

public final class WindChargeListener implements Listener {
    private static final String WIND_META = "MaceWind_WindCharge";
    private static final long LAUNCH_DATA_EXPIRY_MS = 30000L;
    private final MaceWindModule module;
    private final Map<UUID, Long> cooldowns = new HashMap<UUID, Long>();
    private final Map<UUID, double[]> launchData = new HashMap<UUID, double[]>();

    public WindChargeListener(MaceWindModule module) {
        this.module = module;
    }

    public void clear() {
        this.cooldowns.clear();
        this.launchData.clear();
    }

    @EventHandler
    public void onPlayerUse(PlayerInteractEvent event) {
        EquipmentSlot hand = event.getHand();
        if ((hand != EquipmentSlot.HAND && hand != EquipmentSlot.OFF_HAND)
            || event.getAction() == null
            || !event.getAction().name().contains("RIGHT")) {
            return;
        }
        Player player = event.getPlayer();
        ItemStack held = hand == EquipmentSlot.HAND
            ? player.getInventory().getItemInMainHand()
            : player.getInventory().getItemInOffHand();
        if (!ItemUtils.isWindCharge(held)) {
            return;
        }

        long cooldownMs = this.module.getConfig().getLong(
            "windcharge.cooldown-ms",
            this.module.getConfig().getLong("windcharge.cooldown-ticks", 10L) * 50L
        );
        long now = System.currentTimeMillis();
        Long lastUse = this.cooldowns.get(player.getUniqueId());
        if (lastUse != null && now - lastUse < Math.max(0L, cooldownMs)) {
            event.setCancelled(true);
            return;
        }

        Location eye = player.getEyeLocation();
        Vector direction = eye.getDirection().normalize();
        Location spawnLocation = eye.clone().add(direction.clone().multiply(1.0D));
        SmallFireball fireball;
        try {
            fireball = player.getWorld().spawn(spawnLocation, SmallFireball.class);
            fireball.setShooter((ProjectileSource)player);
            fireball.setYield(this.module.getConfig().getBoolean(
                "windcharge.prevent-block-damage", true
            ) ? 0.0F : 0.5F);
            fireball.setIsIncendiary(!this.module.getConfig().getBoolean(
                "windcharge.prevent-block-damage", true
            ));
            fireball.setVelocity(
                direction.multiply(this.module.getConfig().getDouble(
                    "windcharge.projectile-speed", 1.5D
                ))
            );
            fireball.setMetadata(
                WIND_META,
                new FixedMetadataValue(this.module.getHost(), Boolean.TRUE)
            );
        } catch (RuntimeException exception) {
            event.setCancelled(true);
            this.module.getLogger().warning(
                "Could not launch a tagged Wind Charge: " + exception.getMessage()
            );
            return;
        }

        this.cooldowns.put(player.getUniqueId(), now);
        if (player.getGameMode() != org.bukkit.GameMode.CREATIVE) {
            consumeOne(player, held, hand);
        }
        playSound(
            player.getWorld(),
            player.getLocation(),
            "windcharge.feedback.throw-sound",
            "ENTITY_SNOWBALL_THROW",
            1.0F,
            1.2F
        );
        event.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onWindProjectileDamage(EntityDamageByEntityEvent event) {
        if (event.getDamager() instanceof Projectile
            && isWindProjectile((Projectile)event.getDamager())) {
            // The burst handler applies the configured direct damage itself.
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onProjectileHit(ProjectileHitEvent event) {
        Projectile projectile = event.getEntity();
        if (!isWindProjectile(projectile)) {
            return;
        }
        Location center = projectile.getLocation();
        World world = center.getWorld();
        Player shooter = projectile.getShooter() instanceof Player
            ? (Player)projectile.getShooter()
            : null;
        spawnWindBurst(world, center);
        playSound(
            world,
            center,
            "windcharge.feedback.impact-sound",
            "ENTITY_ENDERDRAGON_FLAP",
            1.0F,
            1.5F
        );
        if (this.module.getConfig().getBoolean("windcharge.block-interactions", true)) {
            toggleNearbyBlocks(center);
        }

        double radius = Math.max(0.1D, this.module.getConfig().getDouble(
            "windcharge.radius", 2.5D
        ));
        double areaKnockback = this.module.getConfig().getDouble(
            "windcharge.area-knockback",
            this.module.getConfig().getDouble("windcharge.knockback-strength", 0.35D)
        );
        double directKnockback = this.module.getConfig().getDouble(
            "windcharge.direct-hit-knockback", 0.5D
        );
        double upwardBase = this.module.getConfig().getDouble(
            "windcharge.upward-base", 0.5D
        );
        double directDamage = this.module.getConfig().getDouble(
            "windcharge.direct-hit-damage",
            this.module.getConfig().getDouble("windcharge.direct-damage", 1.0D)
        );
        double selfBoost = this.module.getConfig().getDouble(
            "windcharge.self-boost-velocity",
            this.module.getConfig().getDouble("windcharge.self-upward-boost", 1.2D)
        );
        double maxUpwardVelocity = this.module.getConfig().getDouble(
            "windcharge.max-upward-velocity", 1.2D
        );
        boolean selfKnockback = this.module.getConfig().getBoolean(
            "windcharge.self-knockback", true
        );
        Collection<Entity> nearby = world.getNearbyEntities(center, radius, radius, radius);
        for (Entity entity : nearby) {
            if (entity.equals(projectile) || !(entity instanceof LivingEntity)) {
                continue;
            }
            double distance = entity.getLocation().distance(center);
            if (distance > radius) {
                continue;
            }
            boolean self = shooter != null && entity.equals(shooter);
            if (self && !selfKnockback) {
                continue;
            }
            double falloff = Math.max(0.0D, (radius - distance) / radius);
            if (self) {
                double y = Math.min(
                    maxUpwardVelocity,
                    shooter.getVelocity().getY() + selfBoost * Math.max(falloff, 0.4D)
                );
                shooter.setVelocity(new Vector(0.0D, y, 0.0D));
                this.launchData.put(
                    shooter.getUniqueId(),
                    new double[] {shooter.getLocation().getY(), System.currentTimeMillis()}
                );
            } else {
                Vector knockback = entity.getLocation().toVector().subtract(center.toVector());
                if (knockback.lengthSquared() < 0.01D) {
                    knockback = new Vector(0.0D, 1.0D, 0.0D);
                } else {
                    knockback.normalize();
                }
                knockback.setY(knockback.getY() + upwardBase);
                double strength = distance < 1.5D ? directKnockback : areaKnockback;
                knockback.normalize().multiply(strength * falloff);
                entity.setVelocity(knockback);
                if (distance < 1.5D) {
                    if (shooter == null) {
                        ((LivingEntity)entity).damage(directDamage);
                    } else {
                        ((LivingEntity)entity).damage(directDamage, shooter);
                    }
                }
            }
            ((LivingEntity)entity).setFireTicks(0);
        }
        projectile.remove();
        removeExpiredLaunchData(System.currentTimeMillis());
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onFallDamage(EntityDamageEvent event) {
        if (event.getCause() != EntityDamageEvent.DamageCause.FALL
            || !(event.getEntity() instanceof Player)) {
            return;
        }
        Player player = (Player)event.getEntity();
        double[] data = this.launchData.remove(player.getUniqueId());
        if (data == null || System.currentTimeMillis() - (long)data[1] > LAUNCH_DATA_EXPIRY_MS) {
            return;
        }
        double fallDistance = data[0] - player.getLocation().getY();
        if (fallDistance <= 0.5D) {
            event.setCancelled(true);
        } else {
            double reducedDamage = Math.max(0.0D, fallDistance - 3.0D);
            if (reducedDamage <= 0.0D) {
                event.setCancelled(true);
            } else {
                event.setDamage(reducedDamage);
            }
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        UUID id = event.getPlayer().getUniqueId();
        this.cooldowns.remove(id);
        this.launchData.remove(id);
    }

    private void consumeOne(Player player, ItemStack stack, EquipmentSlot hand) {
        if (stack.getAmount() <= 1) {
            setHand(player, hand, null);
            return;
        }
        stack.setAmount(stack.getAmount() - 1);
        setHand(player, hand, ItemUtils.ensureWindTag(stack));
    }

    private void setHand(Player player, EquipmentSlot hand, ItemStack item) {
        if (hand == EquipmentSlot.HAND) {
            player.getInventory().setItemInMainHand(item);
        } else {
            player.getInventory().setItemInOffHand(item);
        }
    }

    private boolean isWindProjectile(Projectile projectile) {
        if (projectile == null || !projectile.hasMetadata(WIND_META)) {
            return false;
        }
        for (MetadataValue value : projectile.getMetadata(WIND_META)) {
            if (value.getOwningPlugin() == this.module.getHost() && value.asBoolean()) {
                return true;
            }
        }
        return false;
    }

    private void toggleNearbyBlocks(Location center) {
        double configuredRadius = this.module.getConfig().getDouble(
            "windcharge.block-interact-radius", 1.5D
        );
        int radius = (int)Math.ceil(Math.max(0.0D, Math.min(8.0D, configuredRadius)));
        for (int dx = -radius; dx <= radius; dx++) {
            for (int dy = -radius; dy <= radius; dy++) {
                for (int dz = -radius; dz <= radius; dz++) {
                    Block block = center.getWorld().getBlockAt(
                        center.getBlockX() + dx,
                        center.getBlockY() + dy,
                        center.getBlockZ() + dz
                    );
                    String type = block.getType().name();
                    try {
                        BlockState state = block.getState();
                        if ((type.contains("DOOR") || type.contains("GATE"))
                            && state.getData() instanceof Openable) {
                            Openable openable = (Openable)state.getData();
                            openable.setOpen(!openable.isOpen());
                            state.setData((MaterialData)openable);
                            state.update(true, true);
                        } else if ("LEVER".equals(type)
                            && state.getData() instanceof Lever) {
                            Lever lever = (Lever)state.getData();
                            lever.setPowered(!lever.isPowered());
                            state.setData((MaterialData)lever);
                            state.update(true, true);
                        } else if (type.contains("BUTTON")
                            && state.getData() instanceof Button) {
                            Button button = (Button)state.getData();
                            button.setPowered(true);
                            state.setData((MaterialData)button);
                            state.update(true, true);
                            final Block pressed = block;
                            long delay = type.contains("WOOD") ? 30L : 20L;
                            this.module.getHost().getServer().getScheduler().runTaskLater(
                                this.module.getHost(),
                                () -> releaseButton(pressed),
                                delay
                            );
                        }
                    } catch (RuntimeException ignored) {
                        // A changed or protected block should not stop the rest of the burst.
                    }
                }
            }
        }
    }

    private void releaseButton(Block block) {
        try {
            BlockState state = block.getState();
            if (state.getData() instanceof Button) {
                Button button = (Button)state.getData();
                button.setPowered(false);
                state.setData((MaterialData)button);
                state.update(true, true);
            }
        } catch (RuntimeException ignored) {
            // The block may have changed while the button timer was running.
        }
    }

    private void spawnWindBurst(World world, Location center) {
        if (!this.module.getConfig().getBoolean("windcharge.feedback.enable-effect", true)) {
            return;
        }
        Effect effect;
        try {
            effect = Effect.valueOf(this.module.getConfig().getString(
                "windcharge.feedback.effect", "SMOKE"
            ));
        } catch (IllegalArgumentException exception) {
            effect = Effect.SMOKE;
        }
        int data = this.module.getConfig().getInt("windcharge.feedback.effect-data", 4);
        for (int i = 0; i < 4; i++) {
            world.playEffect(center.clone().add(0.0D, 0.25D * i, 0.0D), effect, data);
        }
        for (int i = 0; i < 8; i++) {
            double angle = Math.PI * 2.0D * i / 8.0D;
            world.playEffect(
                center.clone().add(Math.cos(angle), 0.15D, Math.sin(angle)),
                effect,
                data
            );
        }
    }

    private void playSound(
        World world,
        Location location,
        String configPath,
        String fallback,
        float volume,
        float pitch
    ) {
        if (!this.module.getConfig().getBoolean("windcharge.feedback.enable-sound", true)) {
            return;
        }
        try {
            world.playSound(
                location,
                Sound.valueOf(this.module.getConfig().getString(configPath, fallback)),
                volume,
                pitch
            );
        } catch (IllegalArgumentException exception) {
            world.playSound(location, Sound.valueOf(fallback), volume, pitch);
        }
    }

    private void removeExpiredLaunchData(long now) {
        Iterator<Map.Entry<UUID, double[]>> iterator = this.launchData.entrySet().iterator();
        while (iterator.hasNext()) {
            double[] data = iterator.next().getValue();
            if (now - (long)data[1] > LAUNCH_DATA_EXPIRY_MS) {
                iterator.remove();
            }
        }
    }
}
