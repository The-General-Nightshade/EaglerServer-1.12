package com.shadowlord.futurecraft.util;

import com.shadowlord.futurecraft.util.NBTUtil;
import org.bukkit.inventory.ItemStack;

public final class ItemNBT {
    private ItemNBT() {
    }

    public static void setStringTag(ItemStack item, String key, String value) {
        NBTUtil.setStringTag(item, key, value);
    }

    public static String getStringTag(ItemStack item, String key) {
        return NBTUtil.getStringTag(item, key);
    }

    public static boolean hasTag(ItemStack item, String key) {
        return NBTUtil.hasTag(item, key);
    }

    public static void addAttributeModifier(ItemStack item, String name, double amount, int operation, String uuid) {
        NBTUtil.addAttributeModifier(item, name, amount, operation, uuid);
    }

    public static boolean hasMarker(ItemStack item, String marker) {
        if (item == null || marker == null) {
            return false;
        }
        return NBTUtil.hasTag(item, marker);
    }

    public static void addMarker(ItemStack item, String marker) {
        if (item == null || marker == null) {
            return;
        }
        NBTUtil.setStringTag(item, marker, "1");
    }
}

