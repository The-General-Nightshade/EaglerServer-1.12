package com.shadowlord.futurecraft.bubbleelevators.commands;

import com.shadowlord.futurecraft.bubbleelevators.BubbleElevatorsModule;
import com.shadowlord.futurecraft.bubbleelevators.managers.BubbleManager;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Chunk;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import java.util.Locale;

public final class BubblesCommand implements CommandExecutor {
    private final BubbleElevatorsModule module;

    public BubblesCommand(BubbleElevatorsModule module) {
        this.module = module;
    }

    @Override
    public boolean onCommand(
        CommandSender sender,
        Command command,
        String label,
        String[] args
    ) {
        if (!sender.hasPermission("bubbleelevators.admin")) {
            sender.sendMessage(ChatColor.RED + "You do not have permission.");
            return true;
        }
        if (args.length == 0) {
            sender.sendMessage(ChatColor.GREEN + "BubbleElevators in FutureCraft v"
                + this.module.getDescription().getVersion());
            sender.sendMessage(ChatColor.YELLOW + "/bubbles reload " + ChatColor.GRAY
                + "- reload settings");
            sender.sendMessage(ChatColor.YELLOW + "/bubbles debug " + ChatColor.GRAY
                + "- toggle debug logging");
            sender.sendMessage(ChatColor.YELLOW + "/bubbles status " + ChatColor.GRAY
                + "- show active columns");
            sender.sendMessage(ChatColor.YELLOW + "/bubbles scan <world|all> " + ChatColor.GRAY
                + "- queue scans of loaded chunks");
            return true;
        }

        String subcommand = args[0].toLowerCase(Locale.ROOT);
        if (subcommand.equals("reload")) {
            this.module.reloadConfig();
            this.module.getBubbleManager().reloadExcludes();
            sender.sendMessage(ChatColor.GREEN + "BubbleElevators settings reloaded.");
            return true;
        }
        if (subcommand.equals("debug")) {
            boolean debug = this.module.getConfig().getBoolean("debug", false);
            this.module.getConfig().set("debug", !debug);
            this.module.saveConfig();
            sender.sendMessage(ChatColor.GREEN + "Debug set to " + ChatColor.YELLOW + !debug);
            return true;
        }
        if (subcommand.equals("status")) {
            BubbleManager manager = this.module.getBubbleManager();
            for (World world : Bukkit.getWorlds()) {
                sender.sendMessage(ChatColor.YELLOW + "World: " + ChatColor.GREEN
                    + world.getName() + ChatColor.GRAY
                    + " Up: " + manager.getUpwardCount(world)
                    + " Down: " + manager.getDownwardCount(world));
            }
            return true;
        }
        if (subcommand.equals("scan")) {
            if (args.length < 2) {
                sender.sendMessage(ChatColor.RED + "Usage: /bubbles scan <world|all>");
                return true;
            }
            if (args[1].equalsIgnoreCase("all")) {
                int queued = this.module.queueLoadedChunkScans();
                sender.sendMessage(ChatColor.GREEN + "Queued " + queued
                    + " loaded chunks for gradual scanning.");
                return true;
            }
            World world = Bukkit.getWorld(args[1]);
            if (world == null) {
                sender.sendMessage(ChatColor.RED + "World not found: " + args[1]);
                return true;
            }
            for (Chunk chunk : world.getLoadedChunks()) {
                this.module.queueChunkScan(chunk);
            }
            sender.sendMessage(ChatColor.GREEN + "Queued loaded chunks in " + world.getName()
                + " for gradual scanning.");
            return true;
        }

        sender.sendMessage(ChatColor.RED + "Unknown subcommand.");
        return true;
    }
}
