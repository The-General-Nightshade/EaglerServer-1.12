package com.shadowlord.futurecraft.blastfurnace;

import com.shadowlord.futurecraft.FutureCraft;
import com.shadowlord.futurecraft.blastfurnace.BlastFurnaceGUI;
import com.shadowlord.futurecraft.blastfurnace.BlastFurnaceManager;
import com.shadowlord.futurecraft.blastfurnace.BlastFurnaceRecipe;
import com.shadowlord.futurecraft.util.ItemNBT;
import java.util.HashSet;
import java.util.Set;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;

public class BlastFurnaceListener
implements Listener {
    private static final Set<Location> placedFurnaces = new HashSet<Location>();
    private final FutureCraft plugin;

    public BlastFurnaceListener(FutureCraft plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onPlayerInteract(PlayerInteractEvent e) {
        Location loc;
        if (e.getPlayer() == null) {
            return;
        }
        if (!e.getAction().name().contains("RIGHT_CLICK")) {
            return;
        }
        Player p = e.getPlayer();
        Block clicked = e.getClickedBlock();
        if (clicked != null && clicked.getType() == Material.FURNACE && placedFurnaces.contains(loc = clicked.getLocation())) {
            e.setCancelled(true);
            BlastFurnaceGUI.openGui(p, loc);
            return;
        }
        ItemStack hand = p.getItemInHand();
        if (hand != null && this.isBlastFurnaceItem(hand) && e.getAction().name().equals("RIGHT_CLICK_AIR")) {
            BlastFurnaceGUI.openGui(p);
            e.setCancelled(true);
        }
    }

    @EventHandler
    public void onBlockPlace(BlockPlaceEvent e) {
        ItemStack placed = e.getItemInHand();
        if (placed == null) {
            return;
        }
        if (placed.getType() != Material.FURNACE) {
            return;
        }
        if (!this.isBlastFurnaceItem(placed)) {
            return;
        }
        Location loc = e.getBlock().getLocation();
        placedFurnaces.add(loc);
        BlastFurnaceManager.startIfNeeded(loc);
    }

    @EventHandler
    public void onBlockBreak(BlockBreakEvent e) {
        Location loc = e.getBlock().getLocation();
        if (placedFurnaces.remove(loc)) {
            BlastFurnaceManager.destroyFurnace(loc);
            e.setCancelled(true);
            e.getBlock().setType(Material.AIR);
            e.getBlock().getWorld().dropItemNaturally(loc, BlastFurnaceRecipe.createBlastFurnaceItem());
        }
    }

    private boolean isBlastFurnaceItem(ItemStack item) {
        if (item == null) {
            return false;
        }
        try {
            String tag = ItemNBT.getStringTag(item, "futurecraft:blast_furnace");
            if (tag != null && !tag.isEmpty()) {
                return true;
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        if (item.hasItemMeta() && item.getItemMeta().hasDisplayName()) {
            return item.getItemMeta().getDisplayName().contains("Blast Furnace");
        }
        return false;
    }

    public static boolean isBlastFurnace(Location loc) {
        return placedFurnaces.contains(loc);
    }
}

