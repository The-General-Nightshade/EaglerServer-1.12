package com.shadowlord.futurecraft.commands;

import com.shadowlord.futurecraft.debris.DebrisManager;
import java.util.Collections;
import java.util.List;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

public class CommandGiveDebris
implements CommandExecutor,
TabCompleter {
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        Player target = null;
        int amount = 1;
        if (args.length >= 1) {
            try {
                amount = Integer.parseInt(args[args.length - 1]);
                if (amount < 1) {
                    amount = 1;
                }
            }
            catch (NumberFormatException ignored) {
                amount = 1;
            }
        }
        if (args.length >= 2) {
            target = Bukkit.getPlayer((String)args[0]);
            if (target == null) {
                sender.sendMessage(ChatColor.RED + "Player not found: " + args[0]);
                return true;
            }
        } else if (sender instanceof Player) {
            target = (Player)sender;
        } else {
            sender.sendMessage(ChatColor.RED + "Console must specify a player.");
            return true;
        }
        DebrisManager.giveDebrisTo(target, amount);
        sender.sendMessage(ChatColor.GREEN + "Gave " + amount + " debris to " + target.getName());
        return true;
    }

    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        return Collections.emptyList();
    }
}

