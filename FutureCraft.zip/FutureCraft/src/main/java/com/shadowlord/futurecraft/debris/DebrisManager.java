package com.shadowlord.futurecraft.debris;

import com.shadowlord.futurecraft.debris.DebrisItem;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public final class DebrisManager {
    private DebrisManager() {
    }

    public static void giveDebrisTo(Player p, int amount) {
        if (p == null || amount <= 0) {
            return;
        }
        ItemStack debris = DebrisItem.createDebris(amount);
        p.getInventory().addItem(new ItemStack[]{debris});
    }

    public static ItemStack consumeDebris(ItemStack stack, int amount) {
        int take;
        if (stack == null || amount <= 0) {
            return stack;
        }
        if (!DebrisItem.isDebris(stack)) {
            return stack;
        }
        int cur = stack.getAmount();
        if ((cur -= (take = Math.min(cur, amount))) <= 0) {
            return null;
        }
        stack.setAmount(cur);
        return stack;
    }
}

