package com.shadowlord.futurecraft.debris;

import com.shadowlord.futurecraft.FutureCraft;
import com.shadowlord.futurecraft.debris.DebrisTracker;
import java.util.Random;
import org.bukkit.Chunk;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.world.ChunkLoadEvent;

public class DebrisGenerator
implements Listener {
    private static final double DEFAULT_GENERATION_MULTIPLIER = 0.9;
    private final FutureCraft plugin;
    private final Random rnd = new Random();

    public DebrisGenerator(FutureCraft plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onChunkLoad(ChunkLoadEvent e) {
        int cz;
        int cx;
        Chunk chunk = e.getChunk();
        World world = chunk.getWorld();
        if (world.getEnvironment() != World.Environment.NETHER) {
            return;
        }
        String worldName = world.getName();
        if (DebrisTracker.isChunkProcessed(worldName, cx = chunk.getX(), cz = chunk.getZ())) {
            return;
        }
        this.generateForChunk(world, chunk);
        DebrisTracker.markChunkProcessed(worldName, cx, cz);
        DebrisTracker.saveWorld(this.plugin, worldName);
    }

    public void generateForChunk(World world, Chunk chunk) {
        String worldName = world.getName();
        int baseX = chunk.getX() << 4;
        int baseZ = chunk.getZ() << 4;
        double multiplier = this.plugin.getConfig().getDouble("debris.generation.multiplier", DEFAULT_GENERATION_MULTIPLIER);
        if (multiplier < 0.0 || multiplier > 1.0) {
            multiplier = DEFAULT_GENERATION_MULTIPLIER;
        }
        int totalTarget = Math.max(1, (int)Math.round((double)(this.rnd.nextInt(9) + 3) * multiplier));
        int placed = 0;
        int maxAttempts = totalTarget * 10;
        int attempts = 0;
        while (placed < totalTarget && attempts < maxAttempts) {
            ++attempts;
            int centerX = baseX + this.rnd.nextInt(16);
            int centerZ = baseZ + this.rnd.nextInt(16);
            int centerY = this.pickY();
            int clusterSize = this.rnd.nextInt(4);
            for (int i = 0; i < clusterSize && placed < totalTarget; ++i) {
                Block block;
                int bx = centerX + this.rnd.nextInt(3) - 1;
                int by = centerY + this.rnd.nextInt(3) - 1;
                int bz = centerZ + this.rnd.nextInt(3) - 1;
                if (by < 5 || by > 27 || (block = world.getBlockAt(bx, by, bz)).getType() != Material.NETHERRACK) continue;
                block.setType(Material.OBSIDIAN);
                DebrisTracker.addBlock(worldName, bx, by, bz);
                ++placed;
            }
        }
    }

    public void generateForChunkAt(World world, int cx, int cz) {
        Chunk chunk = world.getChunkAt(cx, cz);
        this.generateForChunk(world, chunk);
        DebrisTracker.markChunkProcessed(world.getName(), cx, cz);
    }

    private int pickY() {
        if (this.rnd.nextDouble() < 0.6) {
            return this.rnd.nextInt(5) + 13;
        }
        return this.rnd.nextInt(23) + 5;
    }
}

