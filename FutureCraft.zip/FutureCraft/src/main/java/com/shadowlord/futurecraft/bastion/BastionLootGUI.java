package com.shadowlord.futurecraft.bastion;

import java.util.List;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

public final class BastionLootGUI
implements Listener {
    private static final String TITLE = ChatColor.DARK_PURPLE + "Bastion Loot Table";
    private final BastionStore store;

    public BastionLootGUI(BastionStore store) {
        this.store = store;
    }

    public void open(Player player) {
        Inventory inventory = Bukkit.createInventory(null, 54, TITLE);
        List<BastionStore.LootEntry> entries = this.store.getLootEntries();
        for (int slot = 0; slot < entries.size() && slot < inventory.getSize(); ++slot) {
            inventory.setItem(slot, entries.get(slot).getItem());
        }
        player.openInventory(inventory);
        player.sendMessage(ChatColor.GRAY + "Place items in the GUI to add them. Remove items to delete them.");
        player.sendMessage(ChatColor.GRAY + "New GUI entries start with weight 1. Edit loot_table.yml for custom weights.");
    }

    @EventHandler
    public void onInventoryClose(InventoryCloseEvent event) {
        Inventory inventory = event.getInventory();
        if (inventory == null || !TITLE.equals(inventory.getTitle())) {
            return;
        }
        this.store.replaceLoot(java.util.Arrays.asList(inventory.getContents()));
        if (event.getPlayer() instanceof Player) {
            event.getPlayer().sendMessage(ChatColor.GREEN + "Bastion loot table saved.");
        }
    }
}