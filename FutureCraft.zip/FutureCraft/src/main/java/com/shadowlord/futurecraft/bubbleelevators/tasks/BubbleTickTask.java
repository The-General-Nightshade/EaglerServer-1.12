package com.shadowlord.futurecraft.bubbleelevators.tasks;

import com.shadowlord.futurecraft.bubbleelevators.BubbleElevatorsModule;
import com.shadowlord.futurecraft.bubbleelevators.managers.BubbleManager;
import org.bukkit.scheduler.BukkitRunnable;

public final class BubbleTickTask extends BukkitRunnable {
    private final BubbleElevatorsModule module;
    private final BubbleManager manager;

    public BubbleTickTask(BubbleElevatorsModule module, BubbleManager manager) {
        this.module = module;
        this.manager = manager;
    }

    @Override
    public void run() {
        try {
            this.manager.tick();
        } catch (RuntimeException exception) {
            this.module.getLogger().severe(
                "BubbleElevators update failed: " + exception.getMessage()
            );
            exception.printStackTrace();
        }
    }
}
