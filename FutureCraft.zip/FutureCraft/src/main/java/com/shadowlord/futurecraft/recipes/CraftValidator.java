package com.shadowlord.futurecraft.recipes;

import com.shadowlord.futurecraft.FutureCraft;
import com.shadowlord.futurecraft.util.Compat;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

public class CraftValidator {
    private final FutureCraft plugin;

    public CraftValidator(FutureCraft plugin) {
        this.plugin = plugin;
    }

    public CraftValidator() {
        this.plugin = null;
    }

    public boolean matchesExpected(Inventory inv, ItemStack[] expected) {
        if (inv == null) {
            return false;
        }
        ItemStack[] matrix = Compat.getMatrixSafe(inv);
        if (matrix.length != expected.length) {
            return false;
        }
        for (int i = 0; i < matrix.length; ++i) {
            ItemStack a = matrix[i];
            ItemStack b = expected[i];
            if (b == null) {
                if (a == null) continue;
                return false;
            }
            if (a == null) {
                return false;
            }
            if (a.isSimilar(b)) continue;
            return false;
        }
        return true;
    }
}

