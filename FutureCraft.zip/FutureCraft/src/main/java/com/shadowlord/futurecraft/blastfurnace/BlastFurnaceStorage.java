package com.shadowlord.futurecraft.blastfurnace;

import com.shadowlord.futurecraft.FutureCraft;
import java.util.HashSet;
import org.bukkit.Location;
import org.bukkit.configuration.file.FileConfiguration;

public final class BlastFurnaceStorage {
    private final FutureCraft plugin = FutureCraft.getInstance();
    private final FileConfiguration cfg = this.plugin != null ? this.plugin.getConfig() : null;

    public boolean getBoolean(String key, boolean def) {
        if (this.cfg == null) {
            return def;
        }
        return this.cfg.getBoolean("blastfurnace." + key, def);
    }

    public void setBoolean(String key, boolean value) {
        if (this.cfg == null) {
            return;
        }
        this.cfg.set("blastfurnace." + key, (Object)value);
        this.plugin.saveConfig();
    }

    public void clearAll() {
        if (this.cfg == null) {
            return;
        }
        this.cfg.set("blastfurnace", null);
        this.plugin.saveConfig();
    }

    private String locKey(Location loc) {
        return loc.getWorld().getName() + ":" + loc.getBlockX() + ":" + loc.getBlockY() + ":" + loc.getBlockZ();
    }

    public void mark(Location loc) {
        if (this.cfg == null || loc == null) {
            return;
        }
        HashSet set = new HashSet();
        if (this.cfg.isConfigurationSection("blastfurnace.marked")) {
            set.addAll(this.cfg.getConfigurationSection("blastfurnace.marked").getKeys(false));
        }
        String key = this.locKey(loc);
        this.cfg.set("blastfurnace.marked." + key, (Object)true);
        this.plugin.saveConfig();
    }

    public void unmark(Location loc) {
        if (this.cfg == null || loc == null) {
            return;
        }
        String key = this.locKey(loc);
        this.cfg.set("blastfurnace.marked." + key, null);
        this.plugin.saveConfig();
    }

    public boolean isBlastFurnace(Location loc) {
        if (this.cfg == null || loc == null) {
            return false;
        }
        String key = this.locKey(loc);
        return this.cfg.getBoolean("blastfurnace.marked." + key, false);
    }
}

