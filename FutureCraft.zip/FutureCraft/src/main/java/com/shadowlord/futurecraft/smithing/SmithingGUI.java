package com.shadowlord.futurecraft.smithing;

import com.shadowlord.futurecraft.smithing.SmithingManager;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class SmithingGUI
implements Listener {
    private static final String TITLE = ChatColor.DARK_GRAY + "Smithing Table";
    private static final int SIZE = 27;
    private static final int SLOT_IN_1 = 10;
    private static final int SLOT_IN_2 = 11;
    private static final int SLOT_IN_3 = 12;
    private static final int SLOT_INFO = 14;
    private static final int SLOT_OUT = 16;
    private static final Set<Integer> INPUT_SLOTS = new HashSet<Integer>(Arrays.asList(10, 11, 12));
    private static final Set<Integer> FRAME_SLOTS = new HashSet<Integer>();

    public static Inventory createGui() {
        Inventory inv = Bukkit.createInventory(null, (int)27, (String)TITLE);
        ItemStack pane = new ItemStack(Material.STAINED_GLASS_PANE, 1, (short)7);
        ItemMeta paneMeta = pane.getItemMeta();
        if (paneMeta != null) {
            paneMeta.setDisplayName(ChatColor.GRAY + " ");
            pane.setItemMeta(paneMeta);
        }
        for (int i = 0; i < 27; ++i) {
            inv.setItem(i, pane.clone());
        }
        inv.setItem(10, null);
        inv.setItem(11, null);
        inv.setItem(12, null);
        ItemStack info = new ItemStack(Material.PAPER, 1);
        ItemMeta infoMeta = info.getItemMeta();
        if (infoMeta != null) {
            infoMeta.setDisplayName(ChatColor.YELLOW + "How to Upgrade");
            infoMeta.setLore(Arrays.asList(ChatColor.GRAY + "Place in any order:", ChatColor.WHITE + "1. " + ChatColor.GOLD + "Upgrade Template", ChatColor.WHITE + "2. " + ChatColor.AQUA + "Diamond tool/armor", ChatColor.WHITE + "3. " + ChatColor.DARK_PURPLE + "Neth Ingot", "", ChatColor.GRAY + "Result appears on the right."));
            info.setItemMeta(infoMeta);
        }
        inv.setItem(14, info);
        inv.setItem(16, null);
        return inv;
    }

    public static void openGui(Player p) {
        p.openInventory(SmithingGUI.createGui());
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent e) {
        Inventory inv = e.getInventory();
        if (inv == null || !TITLE.equals(inv.getTitle())) {
            return;
        }
        int rawSlot = e.getRawSlot();
        HumanEntity clicker = e.getWhoClicked();
        if (rawSlot >= 27) {
            if (e.isShiftClick()) {
                e.setCancelled(true);
                return;
            }
            return;
        }
        e.setCancelled(true);
        if (FRAME_SLOTS.contains(rawSlot) || rawSlot == 14) {
            return;
        }
        if (rawSlot == 16) {
            ItemStack result = inv.getItem(16);
            if (result == null || result.getType() == Material.AIR) {
                return;
            }
            clicker.getInventory().addItem(new ItemStack[]{result.clone()});
            inv.setItem(16, null);
            SmithingGUI.consumeOne(inv, 10);
            SmithingGUI.consumeOne(inv, 11);
            SmithingGUI.consumeOne(inv, 12);
            this.refreshPreview(inv);
            if (clicker instanceof Player) {
                ((Player)clicker).updateInventory();
            }
            return;
        }
        if (INPUT_SLOTS.contains(rawSlot)) {
            boolean hasSlot;
            ItemStack cursor = e.getCursor();
            ItemStack slotItem = inv.getItem(rawSlot);
            boolean hasCursor = cursor != null && cursor.getType() != Material.AIR;
            boolean bl = hasSlot = slotItem != null && slotItem.getType() != Material.AIR;
            if (hasCursor && !hasSlot) {
                inv.setItem(rawSlot, cursor.clone());
                clicker.setItemOnCursor(null);
            } else if (!hasCursor && hasSlot) {
                clicker.setItemOnCursor(slotItem.clone());
                inv.setItem(rawSlot, null);
            } else if (hasCursor && hasSlot) {
                clicker.setItemOnCursor(slotItem.clone());
                inv.setItem(rawSlot, cursor.clone());
            }
            this.refreshPreview(inv);
            if (clicker instanceof Player) {
                ((Player)clicker).updateInventory();
            }
            return;
        }
    }

    @EventHandler
    public void onInventoryClose(InventoryCloseEvent e) {
        Inventory inv = e.getInventory();
        if (inv == null || !TITLE.equals(inv.getTitle())) {
            return;
        }
        HumanEntity h = e.getPlayer();
        for (int s : new int[]{10, 11, 12}) {
            ItemStack it = inv.getItem(s);
            if (it == null || it.getType() == Material.AIR) continue;
            h.getInventory().addItem(new ItemStack[]{it});
            inv.setItem(s, null);
        }
    }

    private void refreshPreview(Inventory inv) {
        ItemStack a = inv.getItem(10);
        ItemStack b = inv.getItem(11);
        ItemStack c = inv.getItem(12);
        ItemStack preview = SmithingManager.preview(a, b, c);
        inv.setItem(16, preview);
    }

    private static void consumeOne(Inventory inv, int slot) {
        ItemStack it = inv.getItem(slot);
        if (it == null || it.getType() == Material.AIR) {
            return;
        }
        int amt = it.getAmount() - 1;
        if (amt <= 0) {
            inv.setItem(slot, null);
        } else {
            it.setAmount(amt);
            inv.setItem(slot, it);
        }
    }

    static {
        for (int i = 0; i < 27; ++i) {
            FRAME_SLOTS.add(i);
        }
        FRAME_SLOTS.removeAll(INPUT_SLOTS);
        FRAME_SLOTS.remove(14);
        FRAME_SLOTS.remove(16);
    }
}

