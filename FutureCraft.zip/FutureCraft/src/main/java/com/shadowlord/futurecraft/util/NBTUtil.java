package com.shadowlord.futurecraft.util;

import java.lang.reflect.Method;
import java.util.List;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.inventory.ItemStack;

public final class NBTUtil {
    private static Class<?> craftItemStackClass;
    private static Method asNMSCopy;
    private static Method asBukkitCopy;
    private static Class<?> nmsItemStackClass;
    private static Class<?> nbtTagCompoundClass;
    private static Class<?> nbtTagListClass;
    private static Class<?> nbtBaseClass;
    private static Method getTagMethod;
    private static Method setTagMethod;
    private static Method nbtSetString;
    private static Method nbtGetString;
    private static Method nbtHasKey;
    private static Method nbtCompoundSetMethod;
    private static Method nbtCompoundGetMethod;
    private static Method nbtListAddMethod;

    private NBTUtil() {
    }

    public static void setStringTag(ItemStack item, String key, String value) {
        if (item == null || key == null || value == null) {
            return;
        }
        try {
            if (asNMSCopy == null) {
                return;
            }
            Object nmsItem = asNMSCopy.invoke(null, item);
            Object tag = getTagMethod.invoke(nmsItem, new Object[0]);
            if (tag == null) {
                tag = nbtTagCompoundClass.newInstance();
            }
            nbtSetString.invoke(tag, key, value);
            setTagMethod.invoke(nmsItem, tag);
            ItemStack bukkit = (ItemStack)asBukkitCopy.invoke(null, nmsItem);
            if (bukkit != null && bukkit.getItemMeta() != null) {
                item.setItemMeta(bukkit.getItemMeta());
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    public static String getStringTag(ItemStack item, String key) {
        if (item == null || key == null) {
            return null;
        }
        try {
            if (asNMSCopy == null) {
                return null;
            }
            Object nmsItem = asNMSCopy.invoke(null, item);
            Object tag = getTagMethod.invoke(nmsItem, new Object[0]);
            if (tag == null) {
                return null;
            }
            Boolean has = (Boolean)nbtHasKey.invoke(tag, key);
            if (has != null && has.booleanValue()) {
                return (String)nbtGetString.invoke(tag, key);
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        return null;
    }

    public static boolean hasTag(ItemStack item, String key) {
        if (item == null || key == null) {
            return false;
        }
        try {
            if (asNMSCopy == null) {
                return false;
            }
            Object nmsItem = asNMSCopy.invoke(null, item);
            Object tag = getTagMethod.invoke(nmsItem, new Object[0]);
            if (tag == null) {
                return false;
            }
            return (Boolean)nbtHasKey.invoke(tag, key);
        }
        catch (Exception exception) {
            return false;
        }
    }

    public static void addAttributeModifier(ItemStack item, String name, double amount, int operation, String uuid) {
        if (item == null || name == null) {
            return;
        }
        try {
            if (asNMSCopy == null) {
                return;
            }
            Object nmsItem = asNMSCopy.invoke(null, item);
            Object tag = getTagMethod.invoke(nmsItem, new Object[0]);
            if (tag == null) {
                tag = nbtTagCompoundClass.newInstance();
            }
            Object modifier = nbtTagCompoundClass.newInstance();
            nbtSetString.invoke(modifier, "AttributeName", name);
            nbtSetString.invoke(modifier, "Name", name);
            Method setDouble = nbtTagCompoundClass.getMethod("setDouble", String.class, Double.TYPE);
            setDouble.invoke(modifier, "Amount", amount);
            Method setInt = nbtTagCompoundClass.getMethod("setInt", String.class, Integer.TYPE);
            setInt.invoke(modifier, "Operation", operation);
            String id = uuid == null ? UUID.randomUUID().toString() : uuid;
            nbtSetString.invoke(modifier, "UUID", id);
            Object existingList = null;
            if (((Boolean)nbtHasKey.invoke(tag, "AttributeModifiers")).booleanValue()) {
                existingList = nbtCompoundGetMethod.invoke(tag, "AttributeModifiers");
            }
            if (existingList == null) {
                Object list = nbtTagListClass.newInstance();
                nbtListAddMethod.invoke(list, modifier);
                nbtCompoundSetMethod.invoke(tag, "AttributeModifiers", list);
            } else {
                nbtListAddMethod.invoke(existingList, modifier);
                nbtCompoundSetMethod.invoke(tag, "AttributeModifiers", existingList);
            }
            setTagMethod.invoke(nmsItem, tag);
            ItemStack bukkit = (ItemStack)asBukkitCopy.invoke(null, nmsItem);
            if (bukkit != null && bukkit.getItemMeta() != null) {
                item.setItemMeta(bukkit.getItemMeta());
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    public static void addAttributeModifiersFromSpecs(ItemStack item, List<String> specs) {
        if (specs == null || specs.isEmpty()) {
            return;
        }
        for (String s : specs) {
            try {
                String[] p = s.split(":");
                if (p.length < 2) continue;
                String name = p[0];
                double amount = Double.parseDouble(p[1]);
                int op = p.length >= 3 ? Integer.parseInt(p[2]) : 0;
                String id = p.length >= 4 ? p[3] : null;
                NBTUtil.addAttributeModifier(item, name, amount, op, id);
            }
            catch (Exception exception) {}
        }
    }

    static {
        try {
            String cbPackage = Bukkit.getServer().getClass().getPackage().getName();
            String version = cbPackage.substring(cbPackage.lastIndexOf(46) + 1);
            craftItemStackClass = Class.forName("org.bukkit.craftbukkit." + version + ".inventory.CraftItemStack");
            asNMSCopy = craftItemStackClass.getMethod("asNMSCopy", ItemStack.class);
            nmsItemStackClass = Class.forName("net.minecraft.server." + version + ".ItemStack");
            asBukkitCopy = craftItemStackClass.getMethod("asBukkitCopy", nmsItemStackClass);
            nbtTagCompoundClass = Class.forName("net.minecraft.server." + version + ".NBTTagCompound");
            nbtTagListClass = Class.forName("net.minecraft.server." + version + ".NBTTagList");
            nbtBaseClass = Class.forName("net.minecraft.server." + version + ".NBTBase");
            getTagMethod = nmsItemStackClass.getMethod("getTag", new Class[0]);
            setTagMethod = nmsItemStackClass.getMethod("setTag", nbtTagCompoundClass);
            nbtSetString = nbtTagCompoundClass.getMethod("setString", String.class, String.class);
            nbtGetString = nbtTagCompoundClass.getMethod("getString", String.class);
            nbtHasKey = nbtTagCompoundClass.getMethod("hasKey", String.class);
            nbtCompoundSetMethod = nbtTagCompoundClass.getMethod("set", String.class, nbtBaseClass);
            nbtCompoundGetMethod = nbtTagCompoundClass.getMethod("get", String.class);
            nbtListAddMethod = nbtTagListClass.getMethod("add", nbtBaseClass);
        }
        catch (Exception ex) {
            craftItemStackClass = null;
            asNMSCopy = null;
            asBukkitCopy = null;
            nmsItemStackClass = null;
            nbtTagCompoundClass = null;
            nbtTagListClass = null;
            nbtBaseClass = null;
            getTagMethod = null;
            setTagMethod = null;
            nbtSetString = null;
            nbtGetString = null;
            nbtHasKey = null;
            nbtCompoundSetMethod = null;
            nbtCompoundGetMethod = null;
            nbtListAddMethod = null;
        }
    }
}

