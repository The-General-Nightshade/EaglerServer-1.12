package com.shadowlord.futurecraft.bubbleelevators.managers;

import com.shadowlord.futurecraft.bubbleelevators.BubbleElevatorsModule;
import com.shadowlord.futurecraft.bubbleelevators.util.Region;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import org.bukkit.Location;
import org.bukkit.World;

public final class RegionManager {
    private final BubbleElevatorsModule module;
    private final List<Region> regions = new ArrayList<Region>();

    public RegionManager(BubbleElevatorsModule module) {
        this.module = module;
    }

    public boolean isLocationAllowed(Location location) {
        if (location == null || location.getWorld() == null
            || !this.isWorldAllowed(location.getWorld())) {
            return false;
        }
        if (!this.module.getConfig().getBoolean("regions-enabled", false)) {
            return true;
        }
        for (Region region : this.regions) {
            if (region.contains(location)) {
                return true;
            }
        }
        return false;
    }

    public boolean isWorldAllowed(World world) {
        if (world == null) {
            return false;
        }
        List<String> allowedWorlds = this.module.getConfig().getStringList("allowed-worlds");
        return allowedWorlds.isEmpty() || allowedWorlds.contains(world.getName());
    }

    public void addRegion(Region region) {
        if (region != null) {
            this.regions.add(region);
        }
    }

    public void clearRegions() {
        this.regions.clear();
    }

    public List<Region> getRegions() {
        return Collections.unmodifiableList(this.regions);
    }
}
