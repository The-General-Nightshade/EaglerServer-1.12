package com.shadowlord.futurecraft.util;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;

public final class BlockUtil {
    private BlockUtil() {
    }

    public static String locationKey(Location loc) {
        if (loc == null || loc.getWorld() == null) {
            return "";
        }
        return loc.getWorld().getName() + ":" + loc.getBlockX() + ":" + loc.getBlockY() + ":" + loc.getBlockZ();
    }

    public static boolean isReplaceable(Block b) {
        if (b == null) {
            return false;
        }
        Material m = b.getType();
        return m == Material.AIR || m == Material.SNOW || m == Material.LONG_GRASS || m == Material.DEAD_BUSH || m == Material.YELLOW_FLOWER || m == Material.RED_ROSE;
    }

    public static Location findSafePlacement(Location base, int maxUp) {
        if (base == null) {
            return null;
        }
        Block b = base.getBlock();
        for (int i = 0; i <= Math.max(0, maxUp); ++i) {
            Block check = b.getRelative(BlockFace.UP, i);
            if (!BlockUtil.isReplaceable(check)) continue;
            return check.getLocation();
        }
        return base;
    }
}

