package com.shadowlord.futurecraft.macewind.listeners;

import com.shadowlord.futurecraft.macewind.MaceWindModule;
import com.shadowlord.futurecraft.macewind.util.EnchantUtils;
import com.shadowlord.futurecraft.macewind.util.ItemUtils;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

public final class EnchantBookListener implements Listener {
    private final MaceWindModule module;

    public EnchantBookListener(MaceWindModule module) {
        this.module = module;
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        HumanEntity who = event.getWhoClicked();
        ItemStack book = event.getCursor();
        ItemStack clicked = event.getCurrentItem();
        if (!(who instanceof Player) || !EnchantUtils.isEnchantBook(book)
            || !ItemUtils.isMace(clicked)) {
            return;
        }
        Object[] parsed = EnchantUtils.parseEnchantBook(book);
        if (parsed == null) {
            return;
        }
        String enchantName = (String)parsed[0];
        int level = (Integer)parsed[1];
        event.setCancelled(true);
        if (!EnchantUtils.addEnchantment(clicked, enchantName, level)) {
            ((Player)who).sendMessage(
                ChatColor.RED + "[MaceWind] Cannot apply that enchantment or level."
            );
            return;
        }

        if (book.getAmount() > 1) {
            book.setAmount(book.getAmount() - 1);
            event.setCursor(book);
        } else {
            event.setCursor(null);
        }
        ItemStack taggedMace = ItemUtils.ensureMaceTag(clicked);
        Inventory clickedInventory = event.getClickedInventory();
        if (clickedInventory != null) {
            clickedInventory.setItem(event.getSlot(), taggedMace);
        } else {
            ((Player)who).getInventory().setItemInMainHand(taggedMace);
        }

        Player player = (Player)who;
        player.sendMessage(
            ChatColor.GREEN + "[MaceWind] Applied " + ChatColor.AQUA + enchantName + " "
                + EnchantUtils.toRoman(level) + ChatColor.GREEN + " to your Mace."
        );
        try {
            player.playSound(player.getLocation(), Sound.valueOf("BLOCK_ENCHANTMENT_TABLE_USE"), 1.0F, 1.0F);
        } catch (IllegalArgumentException exception) {
            player.playSound(
                player.getLocation(),
                Sound.valueOf("ENTITY_PLAYER_LEVELUP"),
                0.8F,
                1.2F
            );
        }
    }
}
