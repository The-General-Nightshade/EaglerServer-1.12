package com.shadowlord.futurecraft.items;

import com.shadowlord.futurecraft.util.NBTUtil;
import java.util.Arrays;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public final class NetheriteIngotItem {
    private static final String NBT_KEY = "futurecraft:netherite_ingot";
    private static final String DISPLAY = ChatColor.DARK_RED + "Netherite Ingot";

    private NetheriteIngotItem() {
    }

    public static ItemStack createIngot(int amount) {
        ItemStack it = new ItemStack(Material.GOLD_INGOT, Math.max(1, amount));
        ItemMeta meta = it.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(DISPLAY);
            meta.setLore(Arrays.asList(ChatColor.GRAY + "Forged netherite ingot"));
            it.setItemMeta(meta);
        }
        NBTUtil.setStringTag(it, NBT_KEY, "1");
        return it;
    }

    public static ItemStack create() {
        return NetheriteIngotItem.createIngot(1);
    }

    public static boolean isIngot(ItemStack it) {
        return it != null && NBTUtil.hasTag(it, NBT_KEY);
    }
}

