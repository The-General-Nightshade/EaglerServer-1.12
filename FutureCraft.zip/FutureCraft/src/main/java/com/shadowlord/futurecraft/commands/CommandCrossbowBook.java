package com.shadowlord.futurecraft.commands;

import com.shadowlord.futurecraft.crossbows.CrossbowItem;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public final class CommandCrossbowBook implements CommandExecutor, TabCompleter {
    private static final List<String> TYPES = Arrays.asList("quickcharge", "multishot", "piercing");

    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length < 2 || args.length > 3) {
            sender.sendMessage(ChatColor.RED
                + "Usage: /crossbowbook <quickcharge|multishot|piercing> <level> [player]");
            return true;
        }

        String enchantment = CrossbowItem.normalizeEnchantment(args[0]);
        if (enchantment == null) {
            sender.sendMessage(ChatColor.RED + "Type must be Quick Charge, Multishot, or Piercing.");
            return true;
        }

        int level;
        try {
            level = Integer.parseInt(args[1]);
        } catch (NumberFormatException exception) {
            sender.sendMessage(ChatColor.RED + "Level must be a number.");
            return true;
        }
        if (level < 1 || level > CrossbowItem.maxLevel(enchantment)) {
            sender.sendMessage(ChatColor.RED + CrossbowItem.enchantmentName(enchantment)
                + " levels are 1-" + CrossbowItem.maxLevel(enchantment) + ".");
            return true;
        }

        String targetName = args.length == 3
            ? args[2]
            : (sender instanceof Player ? sender.getName() : null);
        if (targetName == null) {
            sender.sendMessage(ChatColor.RED + "Specify a player when using this command from console.");
            return true;
        }
        Player target = Bukkit.getPlayer(targetName);
        if (target == null) {
            sender.sendMessage(ChatColor.RED + "Player not found: " + targetName);
            return true;
        }

        ItemStack book = CrossbowItem.createEnchantmentBook(enchantment, level);
        Map<Integer, ItemStack> leftovers = target.getInventory().addItem(book);
        for (ItemStack leftover : leftovers.values()) {
            target.getWorld().dropItemNaturally(target.getLocation(), leftover);
        }
        target.sendMessage(ChatColor.LIGHT_PURPLE + "You received "
            + CrossbowItem.enchantmentName(enchantment) + " " + level + " book.");
        if (target != sender) {
            sender.sendMessage(ChatColor.GREEN + "Gave "
                + CrossbowItem.enchantmentName(enchantment) + " " + level
                + " book to " + target.getName() + ".");
        }
        return true;
    }

    public List<String> onTabComplete(
        CommandSender sender,
        Command command,
        String alias,
        String[] args
    ) {
        if (args.length == 1) {
            return matching(TYPES, args[0]);
        }
        if (args.length == 2) {
            String enchantment = CrossbowItem.normalizeEnchantment(args[0]);
            if (enchantment == null) {
                return Collections.emptyList();
            }
            List<String> levels = new ArrayList<String>();
            for (int level = 1; level <= CrossbowItem.maxLevel(enchantment); level++) {
                levels.add(Integer.toString(level));
            }
            return matching(levels, args[1]);
        }
        if (args.length == 3) {
            List<String> players = new ArrayList<String>();
            for (Player player : Bukkit.getOnlinePlayers()) {
                players.add(player.getName());
            }
            return matching(players, args[2]);
        }
        return Collections.emptyList();
    }

    private static List<String> matching(List<String> values, String prefix) {
        String lower = prefix == null ? "" : prefix.toLowerCase();
        List<String> matches = new ArrayList<String>();
        for (String value : values) {
            if (value.toLowerCase().startsWith(lower)) {
                matches.add(value);
            }
        }
        return matches;
    }
}
