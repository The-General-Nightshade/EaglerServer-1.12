package com.shadowlord.futurecraft.util;

import org.bukkit.Material;
import org.bukkit.entity.HumanEntity;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

public class InventoryUtil {
    public static void safeDropAll(Inventory inv, HumanEntity who) {
        if (inv == null || who == null) {
            return;
        }
        for (int i = 0; i < inv.getSize(); ++i) {
            ItemStack it = inv.getItem(i);
            if (it == null || it.getType() == Material.AIR) continue;
            who.getWorld().dropItemNaturally(who.getLocation(), it);
            inv.setItem(i, null);
        }
    }
}

