package com.shadowlord.futurecraft.macewind;

import com.shadowlord.futurecraft.FutureCraft;
import com.shadowlord.futurecraft.macewind.commands.MaceWindCommand;
import com.shadowlord.futurecraft.macewind.listeners.EnchantBookListener;
import com.shadowlord.futurecraft.macewind.listeners.FireworkBoostListener;
import com.shadowlord.futurecraft.macewind.listeners.MaceListener;
import com.shadowlord.futurecraft.macewind.listeners.WindChargeListener;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.logging.Logger;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.PluginDescriptionFile;
import org.bukkit.command.PluginCommand;

public final class MaceWindModule {
    private final FutureCraft host;
    private final File configFile;
    private FileConfiguration config;
    private MaceListener maceListener;
    private WindChargeListener windChargeListener;

    public MaceWindModule(FutureCraft host) {
        this.host = host;
        this.configFile = new File(host.getDataFolder(), "macewind.yml");
    }

    public void enable() {
        this.loadOrCreateConfig();
        Plugin standalonePlugin = this.host.getServer().getPluginManager().getPlugin("MaceWind");
        if (standalonePlugin != null && standalonePlugin != this.host
            && standalonePlugin.isEnabled()) {
            this.host.getLogger().warning(
                "The standalone MaceWind plugin is also enabled. Disable it to avoid duplicate "
                    + "mace and wind-charge effects."
            );
        }

        this.maceListener = new MaceListener(this);
        this.windChargeListener = new WindChargeListener(this);
        this.host.getServer().getPluginManager().registerEvents(this.maceListener, this.host);
        this.host.getServer().getPluginManager().registerEvents(this.windChargeListener, this.host);
        this.host.getServer().getPluginManager().registerEvents(
            new FireworkBoostListener(this),
            this.host
        );
        this.host.getServer().getPluginManager().registerEvents(
            new EnchantBookListener(this),
            this.host
        );

        PluginCommand command = this.host.getCommand("macewind");
        if (command == null) {
            throw new IllegalStateException("The /macewind command is missing from plugin.yml");
        }
        MaceWindCommand executor = new MaceWindCommand(this);
        command.setExecutor(executor);
        command.setTabCompleter(executor);
        this.host.getLogger().info("MaceWind enabled.");
    }

    public void shutdown() {
        if (this.maceListener != null) {
            this.maceListener.clear();
        }
        if (this.windChargeListener != null) {
            this.windChargeListener.clear();
        }
    }

    public FutureCraft getHost() {
        return this.host;
    }

    public FileConfiguration getConfig() {
        return this.config;
    }

    public void reloadConfig() {
        this.config = YamlConfiguration.loadConfiguration(this.configFile);
    }

    public void saveConfig() {
        try {
            this.config.save(this.configFile);
        } catch (IOException exception) {
            this.host.getLogger().severe(
                "Could not save MaceWind configuration: " + exception.getMessage()
            );
        }
    }

    public Logger getLogger() {
        return this.host.getLogger();
    }

    public PluginDescriptionFile getDescription() {
        return this.host.getDescription();
    }

    private void loadOrCreateConfig() {
        if (this.configFile.isFile()) {
            this.reloadConfig();
            return;
        }

        File pluginDirectory = this.host.getDataFolder().getParentFile();
        File legacyConfig = pluginDirectory == null
            ? null
            : new File(new File(pluginDirectory, "MaceWind"), "config.yml");
        try {
            if (legacyConfig != null && legacyConfig.isFile()) {
                Files.copy(legacyConfig.toPath(), this.configFile.toPath());
                this.host.getLogger().info(
                    "Copied existing MaceWind settings to macewind.yml."
                );
            } else {
                this.host.saveResource("macewind.yml", false);
            }
        } catch (IOException | IllegalArgumentException exception) {
            throw new IllegalStateException(
                "Could not initialize MaceWind configuration.",
                exception
            );
        }
        this.reloadConfig();
    }
}
