package com.shadowlord.futurecraft.items;

import com.shadowlord.futurecraft.util.NBTUtil;
import java.util.Arrays;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public final class NetheriteScrapItem {
    private static final String NBT_KEY = "futurecraft:neth_scrap";
    private static final String DISPLAY = ChatColor.DARK_PURPLE + "Neth Scrap";

    private NetheriteScrapItem() {
    }

    public static ItemStack createScrap(int amount) {
        ItemStack it = new ItemStack(Material.NETHER_BRICK_ITEM, Math.max(1, amount));
        ItemMeta meta = it.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(DISPLAY);
            meta.setLore(Arrays.asList(ChatColor.GRAY + "Refined ancient material"));
            it.setItemMeta(meta);
        }
        NBTUtil.setStringTag(it, NBT_KEY, "1");
        return it;
    }

    public static boolean isScrap(ItemStack it) {
        return it != null && NBTUtil.hasTag(it, NBT_KEY);
    }
}

