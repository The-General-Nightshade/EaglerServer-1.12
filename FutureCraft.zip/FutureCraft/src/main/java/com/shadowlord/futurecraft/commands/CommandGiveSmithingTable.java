package com.shadowlord.futurecraft.commands;

import com.shadowlord.futurecraft.smithing.SmithingTableItem;
import java.util.ArrayList;
import java.util.List;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public class CommandGiveSmithingTable
implements CommandExecutor,
TabCompleter {
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        Player target;
        if (args.length >= 1) {
            target = Bukkit.getPlayer((String)args[0]);
            if (target == null) {
                sender.sendMessage(ChatColor.RED + "Player not found: " + args[0]);
                return true;
            }
        } else {
            if (!(sender instanceof Player)) {
                sender.sendMessage(ChatColor.RED + "Console must specify a player: /givesmithingtable <player>");
                return true;
            }
            target = (Player)sender;
        }
        target.getInventory().addItem(new ItemStack[]{SmithingTableItem.create()});
        target.sendMessage(ChatColor.GREEN + "You received a Smithing Table!");
        if (!target.equals((Object)sender)) {
            sender.sendMessage(ChatColor.GREEN + "Gave Smithing Table to " + target.getName());
        }
        return true;
    }

    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        ArrayList<String> completions = new ArrayList<String>();
        if (args.length == 1) {
            String prefix = args[0].toLowerCase();
            for (Player p : Bukkit.getOnlinePlayers()) {
                if (!p.getName().toLowerCase().startsWith(prefix)) continue;
                completions.add(p.getName());
            }
        }
        return completions;
    }
}

