package com.shadowlord.futurecraft.macewind.listeners;

import com.shadowlord.futurecraft.macewind.MaceWindModule;
import org.bukkit.Effect;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Firework;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.FireworkMeta;
import org.bukkit.util.Vector;

public final class FireworkBoostListener implements Listener {
    private final MaceWindModule module;

    public FireworkBoostListener(MaceWindModule module) {
        this.module = module;
    }

    @EventHandler
    public void onPlayerUseFirework(PlayerInteractEvent event) {
        if (!this.module.getConfig().getBoolean("firework-boost.enabled", true)) {
            return;
        }
        if (event.getHand() != EquipmentSlot.HAND
            || event.getAction() == null
            || !event.getAction().name().equals("RIGHT_CLICK_AIR")) {
            return;
        }
        Player player = event.getPlayer();
        ItemStack item = player.getInventory().getItemInMainHand();
        if (item == null || item.getType() != Material.FIREWORK) {
            return;
        }

        World world = player.getWorld();
        Location eye = player.getEyeLocation();
        Vector direction = eye.getDirection().normalize();
        try {
            Firework firework = (Firework)world.spawnEntity(
                eye.clone().add(direction.clone().multiply(0.5D)),
                EntityType.FIREWORK
            );
            FireworkMeta meta = firework.getFireworkMeta();
            firework.setFireworkMeta(meta);
            firework.setVelocity(
                direction.clone().multiply(
                    this.module.getConfig().getDouble("firework.launch-speed", 1.4D)
                )
            );
        } catch (RuntimeException exception) {
            this.module.getLogger().warning(
                "Could not launch a MaceWind firework: " + exception.getMessage()
            );
            return;
        }

        boolean wearingElytra = player.getInventory().getChestplate() != null
            && player.getInventory().getChestplate().getType().name().equals("ELYTRA");
        if (player.isGliding() && wearingElytra) {
            double horizontal = this.module.getConfig().getDouble(
                "firework.boost-horizontal", 1.6D
            );
            double vertical = this.module.getConfig().getDouble("firework.boost-vertical", 0.6D);
            double preserveY = this.module.getConfig().getDouble(
                "firework.boost-preserve-y", 0.2D
            );
            Vector boost = player.getLocation().getDirection().normalize().multiply(horizontal);
            double nextY = Math.max(boost.getY(), player.getVelocity().getY() + vertical);
            boost.setY(nextY * preserveY + boost.getY() * (1.0D - preserveY));
            player.setVelocity(boost);
        }

        try {
            Sound sound = Sound.valueOf(
                this.module.getConfig().getString("firework.feedback.sound", "ENTITY_FIREWORK_LAUNCH")
            );
            world.playSound(player.getLocation(), sound, 1.0F, 1.0F);
        } catch (IllegalArgumentException ignored) {
            world.playSound(player.getLocation(), Sound.ENTITY_FIREWORK_LAUNCH, 1.0F, 1.0F);
        }
        if (this.module.getConfig().getBoolean("firework.feedback.effect-visual", true)) {
            world.playEffect(player.getLocation(), Effect.FIREWORKS_SPARK, 0);
        }

        event.setCancelled(true);
        if (player.getGameMode() != org.bukkit.GameMode.CREATIVE) {
            if (item.getAmount() <= 1) {
                player.getInventory().setItemInMainHand(null);
            } else {
                item.setAmount(item.getAmount() - 1);
                player.getInventory().setItemInMainHand(item);
            }
        }
    }
}
