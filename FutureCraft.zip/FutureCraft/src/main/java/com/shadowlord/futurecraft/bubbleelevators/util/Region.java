package com.shadowlord.futurecraft.bubbleelevators.util;

import org.bukkit.Location;
import org.bukkit.World;

public final class Region {
    private final World world;
    private final int minX;
    private final int minY;
    private final int minZ;
    private final int maxX;
    private final int maxY;
    private final int maxZ;

    public Region(Location first, Location second) {
        if (first == null || second == null || first.getWorld() == null
            || !first.getWorld().equals(second.getWorld())) {
            throw new IllegalArgumentException("Region corners must be in the same world.");
        }
        this.world = first.getWorld();
        this.minX = Math.min(first.getBlockX(), second.getBlockX());
        this.minY = Math.min(first.getBlockY(), second.getBlockY());
        this.minZ = Math.min(first.getBlockZ(), second.getBlockZ());
        this.maxX = Math.max(first.getBlockX(), second.getBlockX());
        this.maxY = Math.max(first.getBlockY(), second.getBlockY());
        this.maxZ = Math.max(first.getBlockZ(), second.getBlockZ());
    }

    public boolean contains(Location location) {
        if (location == null || location.getWorld() == null
            || !location.getWorld().equals(this.world)) {
            return false;
        }
        int x = location.getBlockX();
        int y = location.getBlockY();
        int z = location.getBlockZ();
        return x >= this.minX && x <= this.maxX
            && y >= this.minY && y <= this.maxY
            && z >= this.minZ && z <= this.maxZ;
    }
}
