package com.shadowlord.futurecraft.items;

public final class TemplateDefaults {
    private TemplateDefaults() {
    }

    public static String defaultNetheriteMapping() {
        String sword = "DIAMOND_SWORD=generic.attackDamage:2.0,generic.attackSpeed:0.2";
        String pick = "DIAMOND_PICKAXE=generic.attackDamage:1.0";
        String axe = "DIAMOND_AXE=generic.attackDamage:3.0,generic.attackSpeed:0.1";
        String shovel = "DIAMOND_SHOVEL=generic.attackDamage:1.0";
        String hoe = "DIAMOND_HOE=generic.attackDamage:0.5";
        String helmet = "DIAMOND_HELMET=generic.armor:1.0,generic.armorToughness:1.0";
        String chest = "DIAMOND_CHESTPLATE=generic.armor:2.0,generic.armorToughness:1.0";
        String legs = "DIAMOND_LEGGINGS=generic.armor:1.0,generic.armorToughness:1.0";
        String boots = "DIAMOND_BOOTS=generic.armor:1.0";
        String toolFallback = "DIAMOND_TOOL=generic.maxHealth:1.0";
        String armorFallback = "DIAMOND_ARMOR=generic.maxHealth:0.5";
        return String.join((CharSequence)"|", sword, pick, axe, shovel, hoe, helmet, chest, legs, boots, toolFallback, armorFallback);
    }
}

