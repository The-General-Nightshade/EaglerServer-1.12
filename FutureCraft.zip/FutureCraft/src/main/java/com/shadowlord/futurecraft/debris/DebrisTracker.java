package com.shadowlord.futurecraft.debris;

import com.shadowlord.futurecraft.FutureCraft;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public final class DebrisTracker {
    private static final Map<String, Set<String>> processedChunks = new HashMap<String, Set<String>>();
    private static final Map<String, Set<String>> blockLocations = new HashMap<String, Set<String>>();

    private DebrisTracker() {
    }

    public static boolean isChunkProcessed(String worldName, int cx, int cz) {
        Set<String> set = processedChunks.get(worldName);
        return set != null && set.contains(cx + "," + cz);
    }

    public static void markChunkProcessed(String worldName, int cx, int cz) {
        processedChunks.computeIfAbsent(worldName, k -> new HashSet()).add(cx + "," + cz);
    }

    public static void addBlock(String worldName, int x, int y, int z) {
        blockLocations.computeIfAbsent(worldName, k -> new HashSet()).add(x + "," + y + "," + z);
    }

    public static boolean isDebrisBlock(String worldName, int x, int y, int z) {
        Set<String> set = blockLocations.get(worldName);
        return set != null && set.contains(x + "," + y + "," + z);
    }

    public static void removeBlock(String worldName, int x, int y, int z) {
        Set<String> set = blockLocations.get(worldName);
        if (set != null) {
            set.remove(x + "," + y + "," + z);
        }
    }

    public static Set<String> getBlocks(String worldName) {
        Set<String> set = blockLocations.get(worldName);
        return set != null ? new HashSet<String>(set) : Collections.emptySet();
    }

    public static void clearWorld(String worldName) {
        processedChunks.remove(worldName);
        blockLocations.remove(worldName);
    }

    public static void loadWorld(FutureCraft plugin, String worldName) {
        String line;
        BufferedReader r;
        File chunksFile = new File(plugin.getDataFolder(), "debris-chunks-" + worldName + ".txt");
        File blocksFile = new File(plugin.getDataFolder(), "debris-blocks-" + worldName + ".txt");
        HashSet<String> chunks = new HashSet<String>();
        HashSet<String> blocks = new HashSet<String>();
        if (chunksFile.exists()) {
            try {
                r = new BufferedReader(new FileReader(chunksFile));
                try {
                    while ((line = r.readLine()) != null) {
                        if ((line = line.trim()).isEmpty()) continue;
                        chunks.add(line);
                    }
                }
                finally {
                    r.close();
                }
            }
            catch (IOException ex) {
                plugin.getLogger().warning("[FutureCraft] Failed to load debris chunks for " + worldName + ": " + ex.getMessage());
            }
        }
        if (blocksFile.exists()) {
            try {
                r = new BufferedReader(new FileReader(blocksFile));
                try {
                    while ((line = r.readLine()) != null) {
                        if ((line = line.trim()).isEmpty()) continue;
                        blocks.add(line);
                    }
                }
                finally {
                    r.close();
                }
            }
            catch (IOException ex) {
                plugin.getLogger().warning("[FutureCraft] Failed to load debris blocks for " + worldName + ": " + ex.getMessage());
            }
        }
        processedChunks.put(worldName, chunks);
        blockLocations.put(worldName, blocks);
    }

    public static void saveWorld(FutureCraft plugin, String worldName) {
        plugin.getDataFolder().mkdirs();
        File chunksFile = new File(plugin.getDataFolder(), "debris-chunks-" + worldName + ".txt");
        File blocksFile = new File(plugin.getDataFolder(), "debris-blocks-" + worldName + ".txt");
        DebrisTracker.writeSet(chunksFile, processedChunks.get(worldName), plugin);
        DebrisTracker.writeSet(blocksFile, blockLocations.get(worldName), plugin);
    }

    public static void saveAll(FutureCraft plugin) {
        HashSet<String> allWorlds = new HashSet<String>();
        allWorlds.addAll(processedChunks.keySet());
        allWorlds.addAll(blockLocations.keySet());
        for (String world : allWorlds) {
            DebrisTracker.saveWorld(plugin, world);
        }
    }

    public static void deleteFiles(FutureCraft plugin, String worldName) {
        File chunksFile = new File(plugin.getDataFolder(), "debris-chunks-" + worldName + ".txt");
        File blocksFile = new File(plugin.getDataFolder(), "debris-blocks-" + worldName + ".txt");
        if (chunksFile.exists()) {
            chunksFile.delete();
        }
        if (blocksFile.exists()) {
            blocksFile.delete();
        }
    }

    private static void writeSet(File file, Set<String> data, FutureCraft plugin) {
        try (PrintWriter w = new PrintWriter(new FileWriter(file, false));){
            if (data != null) {
                for (String entry : data) {
                    w.println(entry);
                }
            }
        }
        catch (IOException ex) {
            plugin.getLogger().warning("[FutureCraft] Failed to save " + file.getName() + ": " + ex.getMessage());
        }
    }
}

