package com.shadowlord.futurecraft.bubbleelevators.managers;

import com.shadowlord.futurecraft.bubbleelevators.BubbleElevatorsModule;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.entity.EnderPearl;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.util.Vector;

public final class BubbleManager {
    private final BubbleElevatorsModule module;
    private final RegionManager regionManager;
    private final Map<World, Set<Location>> upwardColumns =
        new HashMap<World, Set<Location>>();
    private final Map<World, Set<Location>> downwardColumns =
        new HashMap<World, Set<Location>>();
    private final Map<UUID, Long> pearlLastReset = new HashMap<UUID, Long>();
    private final Set<String> excludedEntityTypes = new HashSet<String>();
    private final Set<String> warnedParticleNames = new HashSet<String>();
    private long lastPearlCleanup;

    public BubbleManager(BubbleElevatorsModule module, RegionManager regionManager) {
        this.module = module;
        this.regionManager = regionManager;
        this.reloadExcludes();
    }

    public void reloadExcludes() {
        this.excludedEntityTypes.clear();
        this.warnedParticleNames.clear();
        List<String> configured = this.module.getConfig().getStringList("entity-exclude-list");
        for (String name : configured) {
            if (name != null && !name.trim().isEmpty()) {
                this.excludedEntityTypes.add(name.trim().toUpperCase());
            }
        }
    }

    public void clear() {
        this.upwardColumns.clear();
        this.downwardColumns.clear();
        this.pearlLastReset.clear();
    }

    public void rebuildColumnsAt(Block base) {
        if (base == null || !this.regionManager.isLocationAllowed(base.getLocation())) {
            return;
        }

        Location location = base.getLocation();
        if (base.getType() == Material.SOUL_SAND) {
            this.buildUpwardColumnFrom(location);
            return;
        }
        if (base.getType() == Material.MAGMA) {
            this.buildDownwardColumnFrom(location);
            return;
        }

        Block below = base.getRelative(BlockFace.DOWN);
        if (below.getType() == Material.SOUL_SAND) {
            this.buildUpwardColumnFrom(below.getLocation());
            return;
        }
        if (below.getType() == Material.MAGMA) {
            this.buildDownwardColumnFrom(below.getLocation());
            return;
        }

        for (BlockFace face : new BlockFace[] {
            BlockFace.UP,
            BlockFace.DOWN,
            BlockFace.NORTH,
            BlockFace.SOUTH,
            BlockFace.EAST,
            BlockFace.WEST
        }) {
            Block neighbor = base.getRelative(face);
            if (neighbor.getType() == Material.SOUL_SAND) {
                this.buildUpwardColumnFrom(neighbor.getLocation());
            } else if (neighbor.getType() == Material.MAGMA) {
                this.buildDownwardColumnFrom(neighbor.getLocation());
            }
        }

        World world = location.getWorld();
        for (int y = location.getBlockY() - 2; y >= 0; y--) {
            Material material = world.getBlockAt(
                location.getBlockX(),
                y,
                location.getBlockZ()
            ).getType();
            if (material == Material.SOUL_SAND) {
                this.buildUpwardColumnFrom(new Location(
                    world,
                    location.getBlockX(),
                    y,
                    location.getBlockZ()
                ));
                return;
            }
            if (material == Material.MAGMA) {
                this.buildDownwardColumnFrom(new Location(
                    world,
                    location.getBlockX(),
                    y,
                    location.getBlockZ()
                ));
                return;
            }
        }
    }

    public void removeColumnsAtXZ(World world, int x, int z) {
        if (world == null) {
            return;
        }
        this.removeColumnAtXZ(this.upwardColumns.get(world), x, z);
        this.removeColumnAtXZ(this.downwardColumns.get(world), x, z);
    }

    public void removeColumnsInChunk(World world, int chunkX, int chunkZ) {
        if (world == null) {
            return;
        }
        this.removeChunkColumns(this.upwardColumns.get(world), chunkX, chunkZ);
        this.removeChunkColumns(this.downwardColumns.get(world), chunkX, chunkZ);
    }

    public void scanChunkForBases(org.bukkit.Chunk chunk) {
        if (chunk == null) {
            return;
        }
        World world = chunk.getWorld();
        if (world == null || !world.isChunkLoaded(chunk.getX(), chunk.getZ())
            || !this.regionManager.isWorldAllowed(world)) {
            return;
        }
        int baseX = chunk.getX() << 4;
        int baseZ = chunk.getZ() << 4;
        int maxY = world.getMaxHeight() - 1;
        for (int x = baseX; x < baseX + 16; x++) {
            for (int z = baseZ; z < baseZ + 16; z++) {
                for (int y = 0; y <= maxY; y++) {
                    Block block = world.getBlockAt(x, y, z);
                    if (block.getType() == Material.SOUL_SAND) {
                        this.buildUpwardColumnFrom(block.getLocation());
                    } else if (block.getType() == Material.MAGMA) {
                        this.buildDownwardColumnFrom(block.getLocation());
                    }
                }
            }
        }
    }

    public void buildUpwardColumnFrom(Location base) {
        this.buildColumnFrom(base, Material.SOUL_SAND, this.upwardColumns);
    }

    public void buildDownwardColumnFrom(Location base) {
        this.buildColumnFrom(base, Material.MAGMA, this.downwardColumns);
    }

    private void buildColumnFrom(
        Location base,
        Material expectedBase,
        Map<World, Set<Location>> columns
    ) {
        if (base == null || base.getWorld() == null
            || !this.regionManager.isLocationAllowed(base)) {
            return;
        }
        World world = base.getWorld();
        int x = base.getBlockX();
        int y = base.getBlockY();
        int z = base.getBlockZ();
        if (!world.isChunkLoaded(x >> 4, z >> 4)
            || world.getBlockAt(x, y, z).getType() != expectedBase) {
            return;
        }

        Set<Location> locations = columns.get(world);
        if (locations == null) {
            locations = new HashSet<Location>();
            columns.put(world, locations);
        }
        this.removeColumnAtXZ(locations, x, z);

        int maxY = world.getMaxHeight() - 1;
        for (int scanY = y + 1; scanY <= maxY; scanY++) {
            Block block = world.getBlockAt(x, scanY, z);
            if (!this.isWaterSource(block)) {
                break;
            }
            locations.add(block.getLocation());
        }
        if (this.module.getConfig().getBoolean("debug", false)) {
            this.module.getLogger().info(
                "Built " + expectedBase.name().toLowerCase()
                    + " bubble column at " + base + " with " + locations.size() + " water blocks."
            );
        }
    }

    private boolean isWaterSource(Block block) {
        if (block == null
            || (block.getType() != Material.WATER && block.getType() != Material.STATIONARY_WATER)) {
            return false;
        }
        return block.getData() == 0;
    }

    public void tick() {
        this.applyUpwardColumns();
        this.applyDownwardColumns();
        this.prunePearlTimestamps();
    }

    private void applyUpwardColumns() {
        double playerVelocity = this.safeDouble("velocities.player-upward", 0.5D, -3.0D, 3.0D);
        double pearlVelocity = this.safeDouble("velocities.pearl-upward", 0.15D, -3.0D, 3.0D);
        double itemVelocity = this.safeDouble("velocities.item-upward", 0.15D, -3.0D, 3.0D);
        double mobMultiplier = this.safeDouble(
            "velocities.mob-upward-multiplier",
            0.5D,
            -3.0D,
            3.0D
        );
        double topBobCap = this.safeDouble("top-bob-cap", 0.2D, -1.0D, 1.0D);
        double response = this.velocityResponse();
        boolean particles = this.module.getConfig().getBoolean("particles.enabled", true);
        String particleName = this.module.getConfig().getString("particles.upward", "WATER_SPLASH");
        int particleCount = this.safeInt("particles.count", 6, 0, 100);
        double particleOffset = this.safeDouble("particles.offset", 0.3D, 0.0D, 2.0D);

        for (Map.Entry<World, Set<Location>> entry : this.upwardColumns.entrySet()) {
            World world = entry.getKey();
            Set<Location> locations = entry.getValue();
            for (Location location : new HashSet<Location>(locations)) {
                if (!this.isTrackedWaterLoaded(world, location, locations)) {
                    continue;
                }
                if (!this.regionManager.isLocationAllowed(location)) {
                    continue;
                }

                Location center = location.clone().add(0.5D, 0.5D, 0.5D);
                Collection<Entity> nearby = world.getNearbyEntities(center, 0.6D, 1.5D, 0.6D);
                this.protectAndRefreshPearls(nearby);

                for (Entity entity : nearby) {
                    if (entity == null || entity.isDead() || this.isExcluded(entity)) {
                        continue;
                    }
                    double entityY = entity.getLocation().getY();
                    double topY = location.getY() + 1.0D;
                    double targetY;
                    if (entity instanceof Player) {
                        targetY = entityY >= topY - 0.15D
                            ? (entityY > topY + 0.1D
                                ? -0.1D
                                : Math.min(playerVelocity, topBobCap))
                            : playerVelocity;
                    } else if (entity instanceof EnderPearl) {
                        targetY = pearlVelocity;
                    } else if (entity instanceof Item) {
                        targetY = itemVelocity;
                    } else {
                        targetY = playerVelocity * mobMultiplier;
                    }
                    this.smoothVerticalVelocity(entity, targetY, response);
                    this.restoreMagmaBreath(entity);

                    if (entity instanceof EnderPearl) {
                        this.pullPearlTowardCenter((EnderPearl)entity, center, response);
                    }
                }

                if (particles && particleCount > 0) {
                    this.spawnParticles(
                        world,
                        particleName,
                        center,
                        particleCount,
                        particleOffset
                    );
                }
            }
        }
    }

    private void applyDownwardColumns() {
        double downVelocity = this.safeDouble("velocities.downward", -0.5D, -3.0D, 3.0D);
        double response = this.velocityResponse();
        boolean particles = this.module.getConfig().getBoolean("particles.enabled", true);
        String particleName = this.module.getConfig().getString("particles.downward", "SMOKE_NORMAL");
        int particleCount = this.safeInt("particles.count", 6, 0, 100);
        double particleOffset = this.safeDouble("particles.offset", 0.3D, 0.0D, 2.0D);

        for (Map.Entry<World, Set<Location>> entry : this.downwardColumns.entrySet()) {
            World world = entry.getKey();
            Set<Location> locations = entry.getValue();
            for (Location location : new HashSet<Location>(locations)) {
                if (!this.isTrackedWaterLoaded(world, location, locations)) {
                    continue;
                }
                if (!this.regionManager.isLocationAllowed(location)) {
                    continue;
                }

                Location center = location.clone().add(0.5D, 0.5D, 0.5D);
                Collection<Entity> nearby = world.getNearbyEntities(center, 0.6D, 1.5D, 0.6D);
                this.protectAndRefreshPearls(nearby);
                for (Entity entity : nearby) {
                    if (entity == null || entity.isDead() || this.isExcluded(entity)) {
                        continue;
                    }
                    this.smoothVerticalVelocity(entity, downVelocity, response);
                    this.restoreMagmaBreath(entity);
                }

                if (particles && particleCount > 0) {
                    this.spawnParticles(
                        world,
                        particleName,
                        center,
                        particleCount,
                        particleOffset
                    );
                }
            }
        }
    }

    private boolean isTrackedWaterLoaded(
        World world,
        Location location,
        Set<Location> locations
    ) {
        int x = location.getBlockX();
        int z = location.getBlockZ();
        if (!world.isChunkLoaded(x >> 4, z >> 4)) {
            locations.remove(location);
            return false;
        }
        if (!this.isWaterSource(location.getBlock())) {
            locations.remove(location);
            return false;
        }
        return true;
    }

    private boolean isExcluded(Entity entity) {
        EntityType type = entity.getType();
        return type != null && this.excludedEntityTypes.contains(type.name().toUpperCase());
    }

    private void smoothVerticalVelocity(Entity entity, double target, double response) {
        Vector velocity = entity.getVelocity();
        double nextY = this.blend(velocity.getY(), target, response);
        if (Double.isFinite(nextY) && Math.abs(nextY - velocity.getY()) > 0.002D) {
            velocity.setY(nextY);
            entity.setVelocity(velocity);
        }
    }

    private void pullPearlTowardCenter(EnderPearl pearl, Location center, double response) {
        Vector velocity = pearl.getVelocity();
        double targetX = (center.getX() - pearl.getLocation().getX()) * 0.2D;
        double targetZ = (center.getZ() - pearl.getLocation().getZ()) * 0.2D;
        double nextX = this.blend(velocity.getX(), targetX, response);
        double nextZ = this.blend(velocity.getZ(), targetZ, response);
        if (Double.isFinite(nextX) && Double.isFinite(nextZ)) {
            velocity.setX(nextX);
            velocity.setZ(nextZ);
            pearl.setVelocity(velocity);
        }
    }

    private void restoreMagmaBreath(Entity entity) {
        if (!(entity instanceof Player)) {
            return;
        }
        Block below = entity.getLocation().getBlock().getRelative(BlockFace.DOWN);
        if (below.getType() == Material.MAGMA
            && this.isWaterSource(below.getRelative(BlockFace.UP))) {
            Player player = (Player)entity;
            player.setRemainingAir(player.getMaximumAir());
        }
    }

    private void protectAndRefreshPearls(Collection<Entity> nearby) {
        if (nearby == null || nearby.isEmpty()) {
            return;
        }
        String metadataKey = this.module.getConfig().getString(
            "pearl-metadata-key",
            "bubbleelevators_stasis"
        );
        String tagName = this.module.getConfig().getString(
            "pearl-tag-name",
            "§bStasisPearl"
        );
        int resetInterval = this.safeInt(
            "pearl-anti-despawn-interval-seconds",
            4,
            1,
            3600
        );
        long now = System.currentTimeMillis();
        for (Entity entity : nearby) {
            if (!(entity instanceof EnderPearl)) {
                continue;
            }
            EnderPearl pearl = (EnderPearl)entity;
            if (!tagName.equals(pearl.getCustomName())) {
                pearl.setCustomName(tagName);
                pearl.setCustomNameVisible(false);
            }
            if (!pearl.hasMetadata(metadataKey)) {
                pearl.setMetadata(
                    metadataKey,
                    new org.bukkit.metadata.FixedMetadataValue(this.module.getHost(), true)
                );
            }

            UUID id = pearl.getUniqueId();
            Long last = this.pearlLastReset.get(id);
            if (last == null || now - last >= resetInterval * 1000L) {
                pearl.setTicksLived(0);
                this.pearlLastReset.put(id, now);
            }
        }
    }

    private void prunePearlTimestamps() {
        long now = System.currentTimeMillis();
        if (now - this.lastPearlCleanup < 60000L) {
            return;
        }
        this.lastPearlCleanup = now;
        Iterator<Map.Entry<UUID, Long>> iterator = this.pearlLastReset.entrySet().iterator();
        while (iterator.hasNext()) {
            if (now - iterator.next().getValue() > 60000L) {
                iterator.remove();
            }
        }
    }

    private void spawnParticles(
        World world,
        String particleName,
        Location center,
        int count,
        double offset
    ) {
        try {
            Particle particle = Particle.valueOf(particleName);
            world.spawnParticle(particle, center, count, offset, offset, offset, 0.01D);
        } catch (IllegalArgumentException exception) {
            if (this.warnedParticleNames.add(particleName)) {
                this.module.getLogger().warning(
                    "Unknown BubbleElevators particle '" + particleName + "'."
                );
            }
        }
    }

    private void removeColumnAtXZ(Set<Location> locations, int x, int z) {
        if (locations != null) {
            locations.removeIf(location ->
                location.getBlockX() == x && location.getBlockZ() == z
            );
        }
    }

    private void removeChunkColumns(Set<Location> locations, int chunkX, int chunkZ) {
        if (locations != null) {
            locations.removeIf(location ->
                (location.getBlockX() >> 4) == chunkX
                    && (location.getBlockZ() >> 4) == chunkZ
            );
        }
    }

    private boolean isElevatorBase(Material material) {
        return material == Material.SOUL_SAND || material == Material.MAGMA;
    }

    private double velocityResponse() {
        return this.safeDouble("velocity-response", 0.65D, 0.05D, 1.0D);
    }

    private double safeDouble(String path, double fallback, double minimum, double maximum) {
        double value = this.module.getConfig().getDouble(path, fallback);
        if (Double.isNaN(value) || Double.isInfinite(value)) {
            value = fallback;
        }
        return Math.max(minimum, Math.min(maximum, value));
    }

    private int safeInt(String path, int fallback, int minimum, int maximum) {
        int value = this.module.getConfig().getInt(path, fallback);
        return Math.max(minimum, Math.min(maximum, value));
    }

    private double blend(double current, double target, double response) {
        return current + (target - current) * response;
    }

    public int getUpwardCount(World world) {
        Set<Location> locations = this.upwardColumns.get(world);
        return locations == null ? 0 : locations.size();
    }

    public int getDownwardCount(World world) {
        Set<Location> locations = this.downwardColumns.get(world);
        return locations == null ? 0 : locations.size();
    }
}
