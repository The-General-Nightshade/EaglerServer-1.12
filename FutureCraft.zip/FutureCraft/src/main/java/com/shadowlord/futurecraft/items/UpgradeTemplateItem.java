package com.shadowlord.futurecraft.items;

import com.shadowlord.futurecraft.util.NBTUtil;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public final class UpgradeTemplateItem {
    private static final String NBT_KEY = "futurecraft:template";
    private static final String MAP_KEY = "futurecraft:template_map";
    private static final String DISPLAY = ChatColor.GOLD + "Universal Smithing Template";

    private UpgradeTemplateItem() {
    }

    public static ItemStack createTemplate(String mapping) {
        ItemStack it = new ItemStack(Material.PAPER, 1);
        ItemMeta meta = it.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(DISPLAY);
            meta.setLore(Arrays.asList(ChatColor.GRAY + "Universal smithing template", ChatColor.GRAY + "Place with a diamond item + neth scrap"));
            it.setItemMeta(meta);
        }
        NBTUtil.setStringTag(it, NBT_KEY, "1");
        if (mapping != null && !mapping.isEmpty()) {
            NBTUtil.setStringTag(it, MAP_KEY, mapping);
        }
        return it;
    }

    public static boolean isTemplate(ItemStack it) {
        return it != null && NBTUtil.hasTag(it, NBT_KEY);
    }

    public static String getMapping(ItemStack it) {
        if (it == null) {
            return null;
        }
        return NBTUtil.getStringTag(it, MAP_KEY);
    }

    public static List<String> parseMappingEntries(ItemStack it) {
        String map = UpgradeTemplateItem.getMapping(it);
        if (map == null || map.isEmpty()) {
            return Collections.emptyList();
        }
        return Arrays.asList(map.split("\\|"));
    }
}

