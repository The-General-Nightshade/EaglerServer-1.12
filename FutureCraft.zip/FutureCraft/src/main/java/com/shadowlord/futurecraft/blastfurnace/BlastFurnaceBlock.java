package com.shadowlord.futurecraft.blastfurnace;

import com.shadowlord.futurecraft.blastfurnace.BlastFurnaceStorage;
import org.bukkit.Location;
import org.bukkit.block.Block;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;

public class BlastFurnaceBlock
implements Listener {
    private final BlastFurnaceStorage storage = new BlastFurnaceStorage();

    public void onPlace(BlockPlaceEvent e) {
        Block b = e.getBlockPlaced();
        if (b == null) {
            return;
        }
        Location loc = b.getLocation();
        this.storage.mark(loc);
    }

    public void onBreak(BlockBreakEvent e) {
        Block b = e.getBlock();
        if (b == null) {
            return;
        }
        Location loc = b.getLocation();
        if (this.storage.isBlastFurnace(loc)) {
            this.storage.unmark(loc);
        }
    }

    public boolean isMarked(Block b) {
        if (b == null) {
            return false;
        }
        return this.storage.isBlastFurnace(b.getLocation());
    }
}

