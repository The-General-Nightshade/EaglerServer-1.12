package com.shadowlord.futurecraft.bubbleelevators;

import com.shadowlord.futurecraft.FutureCraft;
import com.shadowlord.futurecraft.bubbleelevators.commands.BubblesCommand;
import com.shadowlord.futurecraft.bubbleelevators.listeners.EnderPearlProtectionListener;
import com.shadowlord.futurecraft.bubbleelevators.listeners.WorldListener;
import com.shadowlord.futurecraft.bubbleelevators.managers.BubbleManager;
import com.shadowlord.futurecraft.bubbleelevators.managers.RegionManager;
import com.shadowlord.futurecraft.bubbleelevators.tasks.BubbleTickTask;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.ArrayDeque;
import java.util.HashSet;
import java.util.Queue;
import java.util.Set;
import java.util.logging.Logger;
import org.bukkit.Bukkit;
import org.bukkit.Chunk;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.command.PluginCommand;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.event.Listener;
import org.bukkit.plugin.PluginDescriptionFile;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitTask;

public final class BubbleElevatorsModule {
    private final FutureCraft host;
    private final File configFile;
    private final Queue<Chunk> pendingChunkScans = new ArrayDeque<Chunk>();
    private final Set<String> queuedChunkKeys = new HashSet<String>();
    private final Queue<Location> pendingBlockChanges = new ArrayDeque<Location>();
    private final Set<String> queuedBlockColumns = new HashSet<String>();
    private FileConfiguration config;
    private BubbleManager bubbleManager;
    private RegionManager regionManager;
    private BukkitTask tickTask;
    private BukkitTask workTask;
    private BukkitTask initialScanTask;

    public BubbleElevatorsModule(FutureCraft host) {
        this.host = host;
        this.configFile = new File(host.getDataFolder(), "bubbleelevators.yml");
    }

    public void enable() {
        this.loadOrCreateConfig();
        Plugin standalonePlugin = this.host.getServer().getPluginManager()
            .getPlugin("BubbleElevators");
        if (standalonePlugin != null && standalonePlugin != this.host
            && standalonePlugin.isEnabled()) {
            this.host.getLogger().warning(
                "The standalone BubbleElevators plugin is also enabled. Disable it to avoid "
                    + "duplicate elevator effects."
            );
        }
        this.regionManager = new RegionManager(this);
        this.bubbleManager = new BubbleManager(this, this.regionManager);
        this.host.getServer().getPluginManager().registerEvents(
            (Listener)new WorldListener(this),
            this.host
        );
        this.host.getServer().getPluginManager().registerEvents(
            (Listener)new EnderPearlProtectionListener(this),
            this.host
        );

        PluginCommand command = this.host.getCommand("bubbles");
        if (command == null) {
            throw new IllegalStateException("The /bubbles command is missing from plugin.yml");
        }
        command.setExecutor(new BubblesCommand(this));

        int interval = this.clampInt(this.config.getInt("tick-interval", 2), 1, 20);
        this.tickTask = new BubbleTickTask(this, this.bubbleManager)
            .runTaskTimer(this.host, 1L, (long)interval);
        this.workTask = Bukkit.getScheduler().runTaskTimer(
            this.host,
            this::processPendingWork,
            1L,
            1L
        );
        int delay = this.clampInt(this.config.getInt("initial-scan-delay-ticks", 40), 0, 12000);
        this.initialScanTask = Bukkit.getScheduler().runTaskLater(
            this.host,
            this::queueLoadedChunkScans,
            (long)delay
        );
        this.host.getLogger().info(
            "BubbleElevators enabled (motion update every " + interval + " ticks)."
        );
    }

    public void shutdown() {
        if (this.tickTask != null) {
            this.tickTask.cancel();
            this.tickTask = null;
        }
        if (this.workTask != null) {
            this.workTask.cancel();
            this.workTask = null;
        }
        if (this.initialScanTask != null) {
            this.initialScanTask.cancel();
            this.initialScanTask = null;
        }
        this.pendingChunkScans.clear();
        this.queuedChunkKeys.clear();
        this.pendingBlockChanges.clear();
        this.queuedBlockColumns.clear();
        if (this.bubbleManager != null) {
            this.bubbleManager.clear();
        }
    }

    public FutureCraft getHost() {
        return this.host;
    }

    public FileConfiguration getConfig() {
        return this.config;
    }

    public void reloadConfig() {
        this.config = YamlConfiguration.loadConfiguration(this.configFile);
    }

    public void saveConfig() {
        try {
            this.config.save(this.configFile);
        } catch (IOException exception) {
            this.host.getLogger().severe(
                "Could not save BubbleElevators configuration: " + exception.getMessage()
            );
        }
    }

    public Logger getLogger() {
        return this.host.getLogger();
    }

    public PluginDescriptionFile getDescription() {
        return this.host.getDescription();
    }

    public BubbleManager getBubbleManager() {
        return this.bubbleManager;
    }

    public RegionManager getRegionManager() {
        return this.regionManager;
    }

    public void queueChunkScan(Chunk chunk) {
        if (chunk == null || chunk.getWorld() == null) {
            return;
        }
        String key = this.chunkKey(chunk);
        if (this.queuedChunkKeys.add(key)) {
            this.pendingChunkScans.add(chunk);
        }
    }

    public int queueLoadedChunkScans() {
        int queued = 0;
        for (World world : Bukkit.getWorlds()) {
            for (Chunk chunk : world.getLoadedChunks()) {
                int before = this.pendingChunkScans.size();
                this.queueChunkScan(chunk);
                if (this.pendingChunkScans.size() != before) {
                    queued++;
                }
            }
        }
        this.host.getLogger().info(
            "Queued " + queued + " loaded chunks for incremental BubbleElevators scanning."
        );
        return queued;
    }

    public void queueBlockChange(Block block) {
        if (block == null || block.getWorld() == null) {
            return;
        }
        Location location = new Location(
            block.getWorld(),
            block.getX(),
            block.getY(),
            block.getZ()
        );
        if (this.queuedBlockColumns.add(this.blockColumnKey(location))) {
            this.pendingBlockChanges.add(location);
        }
    }

    private void processPendingWork() {
        int blockBudget = this.clampInt(
            this.config.getInt("block-updates-per-tick", 128),
            1,
            4096
        );
        for (int processed = 0;
             processed < blockBudget && !this.pendingBlockChanges.isEmpty();
             processed++) {
            Location location = this.pendingBlockChanges.remove();
            this.queuedBlockColumns.remove(this.blockColumnKey(location));
            World world = location.getWorld();
            if (world != null && world.isChunkLoaded(
                location.getBlockX() >> 4,
                location.getBlockZ() >> 4
            )) {
                this.bubbleManager.rebuildColumnsAt(location.getBlock());
            }
        }

        int chunkBudget = this.clampInt(
            this.config.getInt("initial-scan-max-chunks-per-tick", 2),
            1,
            64
        );
        for (int processed = 0;
             processed < chunkBudget && !this.pendingChunkScans.isEmpty();
             processed++) {
            Chunk chunk = this.pendingChunkScans.remove();
            this.queuedChunkKeys.remove(this.chunkKey(chunk));
            World world = chunk.getWorld();
            if (world != null && world.isChunkLoaded(chunk.getX(), chunk.getZ())) {
                this.bubbleManager.scanChunkForBases(chunk);
            }
        }
    }

    private void loadOrCreateConfig() {
        if (this.configFile.isFile()) {
            this.reloadConfig();
            return;
        }

        File pluginDirectory = this.host.getDataFolder().getParentFile();
        File legacyConfig = pluginDirectory == null
            ? null
            : new File(new File(pluginDirectory, "BubbleElevators"), "config.yml");
        try {
            if (legacyConfig != null && legacyConfig.isFile()) {
                Files.copy(legacyConfig.toPath(), this.configFile.toPath());
                this.host.getLogger().info(
                    "Copied existing BubbleElevators settings to bubbleelevators.yml."
                );
            } else {
                this.host.saveResource("bubbleelevators.yml", false);
            }
        } catch (IOException | IllegalArgumentException exception) {
            throw new IllegalStateException(
                "Could not initialize BubbleElevators configuration.",
                exception
            );
        }
        this.reloadConfig();
    }

    private String chunkKey(Chunk chunk) {
        return chunk.getWorld().getUID().toString()
            + ":" + chunk.getX()
            + ":" + chunk.getZ();
    }

    private String blockColumnKey(Location location) {
        return location.getWorld().getUID().toString()
            + ":" + location.getBlockX()
            + ":" + location.getBlockZ();
    }

    private int clampInt(int value, int minimum, int maximum) {
        return Math.max(minimum, Math.min(maximum, value));
    }
}
