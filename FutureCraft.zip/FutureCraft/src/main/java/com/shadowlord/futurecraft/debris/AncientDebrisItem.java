package com.shadowlord.futurecraft.debris;

import com.shadowlord.futurecraft.debris.DebrisItem;
import org.bukkit.inventory.ItemStack;

public class AncientDebrisItem {
    public static ItemStack create() {
        return DebrisItem.createDebris(1);
    }

    public static boolean isPluginDebris(ItemStack item) {
        return DebrisItem.isDebris(item);
    }
}

