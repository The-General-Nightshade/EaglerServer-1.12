package com.shadowlord.futurecraft.bastion;

import com.shadowlord.futurecraft.FutureCraft;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import org.bukkit.Chunk;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.Chest;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.world.ChunkLoadEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

public final class BastionGenerator
implements Listener {
    private static final double DEFAULT_CHANCE_PER_CHUNK = 0.003D;
    private static final double DEFAULT_REMOVAL_CHANCE = 0.25D;
    private final FutureCraft plugin;
    private final BastionStore store;
    private final Random random = new Random();
    private BukkitTask regenerationTask;

    public BastionGenerator(FutureCraft plugin, BastionStore store) {
        this.plugin = plugin;
        this.store = store;
    }

    @EventHandler
    public void onChunkLoad(ChunkLoadEvent event) {
        Chunk chunk = event.getChunk();
        World world = chunk.getWorld();
        if (world.getEnvironment() != World.Environment.NETHER) {
            return;
        }
        if (!this.plugin.getConfig().getBoolean("bastions.generation.enabled", true)) {
            return;
        }
        this.processChunk(world, chunk.getX(), chunk.getZ());
    }

    public void processChunk(World world, int chunkX, int chunkZ) {
        if (!this.store.isChunkProcessed(world.getName(), chunkX, chunkZ)) {
            this.store.markChunkProcessed(world.getName(), chunkX, chunkZ);
            this.maybeQueuePlacement(world, chunkX, chunkZ);
            this.store.saveAll();
        }
        this.processPending(world);
    }

    private void maybeQueuePlacement(World world, int chunkX, int chunkZ) {
        List<String> templateNames = this.store.getTemplateNames();
        if (templateNames.isEmpty()) {
            return;
        }
        Random chunkRandom = new Random(this.chunkSeed(world, chunkX, chunkZ));
        double chance = this.plugin.getConfig().getDouble(
            "bastions.generation.chance-per-chunk", DEFAULT_CHANCE_PER_CHUNK
        );
        if (chance <= 0.0D || chunkRandom.nextDouble() >= chance) {
            return;
        }
        String templateName = templateNames.get(chunkRandom.nextInt(templateNames.size()));
        BastionTemplate template = this.store.getTemplate(templateName);
        if (template == null) {
            return;
        }
        int x = (chunkX << 4) + chunkRandom.nextInt(16);
        int z = (chunkZ << 4) + chunkRandom.nextInt(16);
        int y = world.getHighestBlockYAt(x, z) + 1;
        int maxY = this.plugin.getConfig().getInt("bastions.generation.max-y", 110);
        if (y < this.plugin.getConfig().getInt("bastions.generation.min-y", 20)
            || y + template.getHeight() > maxY) {
            return;
        }
        long seed = this.chunkSeed(world, chunkX, chunkZ) ^ 0x5DEECE66DL;
        this.store.addPending(new BastionStore.PendingPlacement(world.getName(), templateName, x, y, z, seed));
    }

    private long chunkSeed(World world, int chunkX, int chunkZ) {
        long seed = world.getSeed();
        seed ^= (long)chunkX * 341873128712L;
        seed ^= (long)chunkZ * 132897987541L;
        return seed;
    }

    private void processPending(World world) {
        int placed = 0;
        for (BastionStore.PendingPlacement pending : this.store.getPending()) {
            if (!world.getName().equals(pending.getWorldName())) {
                continue;
            }
            BastionTemplate template = this.store.getTemplate(pending.getTemplateName());
            if (template == null) {
                this.store.removePending(pending);
                continue;
            }
            if (!this.isAreaLoaded(world, pending.getX(), pending.getZ(), template)) {
                continue;
            }
            if (this.store.overlaps(
                world.getName(), pending.getX(), pending.getY(), pending.getZ(),
                template.getWidth(), template.getHeight(), template.getLength()
            )) {
                this.store.removePending(pending);
                continue;
            }
            this.place(world, pending, template);
            this.store.removePending(pending);
            ++placed;
            if (placed >= this.plugin.getConfig().getInt("bastions.generation.max-placements-per-chunk", 1)) {
                break;
            }
        }
        if (placed > 0) {
            this.store.saveAll();
        }
    }

    private boolean isAreaLoaded(World world, int x, int z, BastionTemplate template) {
        int minChunkX = Math.floorDiv(x, 16);
        int maxChunkX = Math.floorDiv(x + template.getWidth() - 1, 16);
        int minChunkZ = Math.floorDiv(z, 16);
        int maxChunkZ = Math.floorDiv(z + template.getLength() - 1, 16);
        for (int chunkX = minChunkX; chunkX <= maxChunkX; ++chunkX) {
            for (int chunkZ = minChunkZ; chunkZ <= maxChunkZ; ++chunkZ) {
                if (!world.isChunkLoaded(chunkX, chunkZ)) {
                    return false;
                }
            }
        }
        return true;
    }

    private void place(World world, BastionStore.PendingPlacement pending, BastionTemplate template) {
        List<BastionGenerated.BlockSnapshot> snapshots = new ArrayList<BastionGenerated.BlockSnapshot>();
        for (BastionTemplate.BlockRecord record : template.getBlocks()) {
            Block block = world.getBlockAt(
                pending.getX() + record.getX(),
                pending.getY() + record.getY(),
                pending.getZ() + record.getZ()
            );
            snapshots.add(BastionGenerated.BlockSnapshot.capture(block, record.getX(), record.getY(), record.getZ()));
        }
        for (BastionTemplate.BlockRecord record : template.getBlocks()) {
            Block block = world.getBlockAt(
                pending.getX() + record.getX(),
                pending.getY() + record.getY(),
                pending.getZ() + record.getZ()
            );
            block.setTypeIdAndData(record.getTypeId(), record.getData(), false);
        }

        Random ruinRandom = new Random(pending.getSeed());
        double removalChance = this.plugin.getConfig().getDouble(
            "bastions.ruin.block-removal-chance", DEFAULT_REMOVAL_CHANCE
        );
        for (BastionTemplate.BlockRecord record : template.getBlocks()) {
            if (record.isAir() || record.isChest() || ruinRandom.nextDouble() >= removalChance) {
                continue;
            }
            Block block = world.getBlockAt(
                pending.getX() + record.getX(),
                pending.getY() + record.getY(),
                pending.getZ() + record.getZ()
            );
            block.setType(Material.AIR);
        }
        this.fillChests(world, pending, template, new Random(pending.getSeed() ^ 0x1234ABCDL));

        String id = world.getName() + ":" + pending.getX() + ":" + pending.getY() + ":" + pending.getZ();
        BastionGenerated generated = new BastionGenerated(
            id,
            world.getName(),
            template.getName(),
            pending.getX(),
            pending.getY(),
            pending.getZ(),
            template.getWidth(),
            template.getHeight(),
            template.getLength(),
            snapshots
        );
        this.store.addGenerated(generated);
    }

    private void fillChests(World world, BastionStore.PendingPlacement pending, BastionTemplate template, Random random) {
        List<BastionStore.LootEntry> loot = this.store.getLootEntries();
        if (loot.isEmpty()) {
            return;
        }
        int rolls = Math.max(1, this.plugin.getConfig().getInt("bastions.loot.rolls-per-chest", 3));
        for (BastionTemplate.BlockRecord record : template.getBlocks()) {
            if (!record.isChest()) {
                continue;
            }
            Block block = world.getBlockAt(
                pending.getX() + record.getX(),
                pending.getY() + record.getY(),
                pending.getZ() + record.getZ()
            );
            if (!(block.getState() instanceof Chest)) {
                continue;
            }
            Chest chest = (Chest)block.getState();
            Inventory inventory = chest.getBlockInventory();
            inventory.clear();
            for (int roll = 0; roll < rolls; ++roll) {
                int slot = random.nextInt(inventory.getSize());
                int attempts = 0;
                while (inventory.getItem(slot) != null && attempts++ < inventory.getSize()) {
                    slot = random.nextInt(inventory.getSize());
                }
                if (inventory.getItem(slot) != null) {
                    continue;
                }
                BastionStore.LootEntry entry = this.chooseLoot(loot, random);
                if (entry != null) {
                    inventory.setItem(slot, entry.getItem());
                }
            }
            chest.update(true, false);
        }
    }

    private BastionStore.LootEntry chooseLoot(List<BastionStore.LootEntry> loot, Random random) {
        double total = 0.0D;
        for (BastionStore.LootEntry entry : loot) {
            total += entry.getWeight();
        }
        if (total <= 0.0D) {
            return null;
        }
        double selected = random.nextDouble() * total;
        for (BastionStore.LootEntry entry : loot) {
            selected -= entry.getWeight();
            if (selected <= 0.0D) {
                return entry;
            }
        }
        return loot.get(loot.size() - 1);
    }

    public void regenerate(final World world) {
        if (this.regenerationTask != null) {
            this.plugin.getServer().getScheduler().cancelTask(this.regenerationTask.getTaskId());
        }
        this.store.clearWorldGeneration(world);
        final Chunk[] loadedChunks = world.getLoadedChunks();
        this.regenerationTask = new BukkitRunnable() {
            private int index;

            public void run() {
                if (this.index >= loadedChunks.length) {
                    BastionGenerator.this.store.saveAll();
                    BastionGenerator.this.regenerationTask = null;
                    this.cancel();
                    return;
                }
                Chunk chunk = loadedChunks[this.index++];
                BastionGenerator.this.processChunk(world, chunk.getX(), chunk.getZ());
            }
        }.runTaskTimer(this.plugin, 1L, 1L);
    }

    public void shutdown() {
        if (this.regenerationTask != null) {
            this.regenerationTask.cancel();
            this.regenerationTask = null;
        }
    }
}