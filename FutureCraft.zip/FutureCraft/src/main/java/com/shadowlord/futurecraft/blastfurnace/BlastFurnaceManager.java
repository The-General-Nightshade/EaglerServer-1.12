package com.shadowlord.futurecraft.blastfurnace;

import com.shadowlord.futurecraft.FutureCraft;
import com.shadowlord.futurecraft.debris.DebrisItem;
import com.shadowlord.futurecraft.util.ItemNBT;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.HumanEntity;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;

public final class BlastFurnaceManager {
    private static final Map<Location, FurnaceState> stateMap = new ConcurrentHashMap<Location, FurnaceState>();
    private static final Map<Location, Inventory> openInventories = new ConcurrentHashMap<Location, Inventory>();
    private static final Map<Inventory, FurnaceState> virtualMap = new ConcurrentHashMap<Inventory, FurnaceState>();
    private static final int PROCESS_TICKS = 100;
    private static final int FUEL_TICKS = 1600;
    private static boolean globalTaskRunning = false;

    private BlastFurnaceManager() {
    }

    public static void openInventory(Location loc, Inventory inv) {
        openInventories.put(loc, inv);
        BlastFurnaceManager.syncToInventory(loc, inv);
    }

    public static void closeInventory(Location loc, Inventory inv) {
        BlastFurnaceManager.syncFromInventory(loc, inv);
        openInventories.remove(loc);
    }

    public static void syncFromInventory(Location loc, Inventory inv) {
        FurnaceState state = stateMap.get(loc);
        if (state == null) {
            state = new FurnaceState();
            stateMap.put(loc, state);
        }
        state.ore = BlastFurnaceManager.cloneOrNull(inv.getItem(2));
        state.fuel = BlastFurnaceManager.cloneOrNull(inv.getItem(20));
        state.output = BlastFurnaceManager.cloneOrNull(inv.getItem(15));
    }

    public static void syncToInventory(Location loc, Inventory inv) {
        FurnaceState state = stateMap.get(loc);
        if (state == null) {
            return;
        }
        inv.setItem(2, BlastFurnaceManager.cloneOrNull(state.ore));
        inv.setItem(20, BlastFurnaceManager.cloneOrNull(state.fuel));
        inv.setItem(15, BlastFurnaceManager.cloneOrNull(state.output));
        int pct = state.progressTicks > 0 ? Math.min(100, state.progressTicks * 100 / 100) : 0;
        BlastFurnaceManager.updateProgressSlot(inv, pct);
    }

    public static void startIfNeeded(Location loc) {
        if (!stateMap.containsKey(loc)) {
            stateMap.put(loc, new FurnaceState());
        }
        BlastFurnaceManager.ensureGlobalTask();
    }

    public static void destroyFurnace(Location loc) {
        stateMap.remove(loc);
        openInventories.remove(loc);
    }

    public static void startVirtual(Inventory inv) {
        if (!virtualMap.containsKey(inv)) {
            FurnaceState state = new FurnaceState();
            state.ore = BlastFurnaceManager.cloneOrNull(inv.getItem(2));
            state.fuel = BlastFurnaceManager.cloneOrNull(inv.getItem(20));
            state.output = BlastFurnaceManager.cloneOrNull(inv.getItem(15));
            virtualMap.put(inv, state);
        }
        BlastFurnaceManager.ensureGlobalTask();
    }

    public static void syncVirtual(Inventory inv) {
        FurnaceState state = virtualMap.get(inv);
        if (state == null) {
            state = new FurnaceState();
            virtualMap.put(inv, state);
        }
        state.ore = BlastFurnaceManager.cloneOrNull(inv.getItem(2));
        state.fuel = BlastFurnaceManager.cloneOrNull(inv.getItem(20));
        state.output = BlastFurnaceManager.cloneOrNull(inv.getItem(15));
        BlastFurnaceManager.ensureGlobalTask();
    }

    public static void stopVirtual(Inventory inv) {
        virtualMap.remove(inv);
    }

    public static boolean attemptCollect(Inventory inv, HumanEntity who) {
        if (inv == null || who == null) {
            return false;
        }
        ItemStack result = inv.getItem(15);
        if (result == null) {
            return false;
        }
        HashMap<Integer, ItemStack> leftover = who.getInventory().addItem(new ItemStack[]{result.clone()});
        if (leftover == null || leftover.isEmpty()) {
            inv.setItem(15, null);
            return true;
        }
        int taken = result.getAmount();
        for (ItemStack rem : leftover.values()) {
            taken -= rem.getAmount();
        }
        if (taken <= 0) {
            return false;
        }
        result = result.clone();
        result.setAmount(result.getAmount() - taken);
        if (result.getAmount() <= 0) {
            inv.setItem(15, null);
        } else {
            inv.setItem(15, result);
        }
        return true;
    }

    public static boolean isFuel(ItemStack item) {
        if (item == null) {
            return false;
        }
        return item.getType() == Material.COAL;
    }

    private static void ensureGlobalTask() {
        if (globalTaskRunning) {
            return;
        }
        globalTaskRunning = true;
        new BukkitRunnable(){

            public void run() {
                FurnaceState state;
                boolean anyWork = false;
                ArrayList<Location> toRemoveLoc = new ArrayList<Location>();
                for (Map.Entry entry : stateMap.entrySet()) {
                    Location loc = (Location)entry.getKey();
                    state = (FurnaceState)entry.getValue();
                    Inventory openInv = (Inventory)openInventories.get(loc);
                    if (openInv != null) {
                        state.ore = BlastFurnaceManager.cloneOrNull(openInv.getItem(2));
                        state.fuel = BlastFurnaceManager.cloneOrNull(openInv.getItem(20));
                        state.output = BlastFurnaceManager.cloneOrNull(openInv.getItem(15));
                    }
                    boolean didWork = BlastFurnaceManager.tickProcess(state);
                    if (openInv != null) {
                        openInv.setItem(2, BlastFurnaceManager.cloneOrNull(state.ore));
                        openInv.setItem(20, BlastFurnaceManager.cloneOrNull(state.fuel));
                        openInv.setItem(15, BlastFurnaceManager.cloneOrNull(state.output));
                        int pct = state.progressTicks > 0 ? Math.min(100, state.progressTicks * 100 / 100) : 0;
                        BlastFurnaceManager.updateProgressSlot(openInv, pct);
                    }
                    if (didWork) {
                        anyWork = true;
                    }
                    if (didWork || state.ore != null || state.fuelTicksRemaining > 0 || state.output != null || state.fuel != null || openInv != null) continue;
                    toRemoveLoc.add(loc);
                }
                for (Location loc : toRemoveLoc) {
                    stateMap.remove(loc);
                }
                for (Map.Entry entry : virtualMap.entrySet()) {
                    Inventory inv = (Inventory)entry.getKey();
                    state = (FurnaceState)entry.getValue();
                    state.ore = BlastFurnaceManager.cloneOrNull(inv.getItem(2));
                    state.fuel = BlastFurnaceManager.cloneOrNull(inv.getItem(20));
                    state.output = BlastFurnaceManager.cloneOrNull(inv.getItem(15));
                    boolean didWork = BlastFurnaceManager.tickProcess(state);
                    inv.setItem(2, BlastFurnaceManager.cloneOrNull(state.ore));
                    inv.setItem(20, BlastFurnaceManager.cloneOrNull(state.fuel));
                    inv.setItem(15, BlastFurnaceManager.cloneOrNull(state.output));
                    int pct = state.progressTicks > 0 ? Math.min(100, state.progressTicks * 100 / 100) : 0;
                    BlastFurnaceManager.updateProgressSlot(inv, pct);
                    if (!didWork) continue;
                    anyWork = true;
                }
                if (stateMap.isEmpty() && virtualMap.isEmpty()) {
                    globalTaskRunning = false;
                    this.cancel();
                }
            }
        }.runTaskTimer((Plugin)FutureCraft.getInstance(), 1L, 1L);
    }

    private static boolean tickProcess(FurnaceState s) {
        ItemStack expected;
        if (s.ore == null) {
            s.progressTicks = 0;
            return false;
        }
        if (s.fuelTicksRemaining <= 0) {
            if (s.fuel != null && BlastFurnaceManager.isFuel(s.fuel)) {
                int amt = s.fuel.getAmount();
                if (amt <= 1) {
                    s.fuel = null;
                } else {
                    s.fuel = s.fuel.clone();
                    s.fuel.setAmount(amt - 1);
                }
                s.fuelTicksRemaining = 1600;
            } else {
                return false;
            }
        }
        if ((expected = BlastFurnaceManager.getSmeltResultFor(s.ore)) == null) {
            s.progressTicks = 0;
            return false;
        }
        if (!(s.output == null || s.output.isSimilar(expected) && s.output.getAmount() < s.output.getMaxStackSize())) {
            return false;
        }
        ++s.progressTicks;
        s.fuelTicksRemaining = Math.max(0, s.fuelTicksRemaining - 1);
        if (s.progressTicks >= 100) {
            if (s.output == null) {
                s.output = expected.clone();
            } else {
                s.output = s.output.clone();
                s.output.setAmount(s.output.getAmount() + expected.getAmount());
            }
            int inAmt = s.ore.getAmount();
            if (inAmt <= 1) {
                s.ore = null;
            } else {
                s.ore = s.ore.clone();
                s.ore.setAmount(inAmt - 1);
            }
            s.progressTicks = 0;
        }
        return true;
    }

    private static ItemStack getSmeltResultFor(ItemStack input) {
        if (input == null) {
            return null;
        }
        if (DebrisItem.isDebris(input)) {
            return BlastFurnaceManager.createNethScrap(1);
        }
        switch (input.getType()) {
            case IRON_ORE: {
                return new ItemStack(Material.IRON_INGOT, 1);
            }
            case GOLD_ORE: {
                return new ItemStack(Material.GOLD_INGOT, 1);
            }
            case COAL_ORE: {
                return new ItemStack(Material.COAL, 1);
            }
            case DIAMOND_ORE: {
                return new ItemStack(Material.DIAMOND, 1);
            }
        }
        return null;
    }

    private static ItemStack createNethScrap(int amount) {
        ItemStack it = new ItemStack(Material.NETHER_BRICK_ITEM, Math.max(1, amount));
        ItemMeta meta = it.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(ChatColor.DARK_PURPLE + "Neth Scrap");
            meta.setLore(Arrays.asList(ChatColor.GRAY + "Refined ancient material"));
            it.setItemMeta(meta);
        }
        ItemNBT.setStringTag(it, "futurecraft:neth_scrap", "1");
        return it;
    }

    private static void updateProgressSlot(Inventory inv, int percent) {
        if (inv == null) {
            return;
        }
        ItemStack pane = new ItemStack(Material.STAINED_GLASS_PANE, 1, (short)14);
        ItemMeta meta = pane.getItemMeta();
        if (meta != null) {
            if (percent <= 0) {
                meta.setDisplayName(ChatColor.RED + "Progress: Idle");
                meta.setLore(Arrays.asList(ChatColor.GRAY + "Place ore and fuel to start"));
            } else {
                meta.setDisplayName(ChatColor.GREEN + "Progress: " + percent + "%");
                meta.setLore(Arrays.asList(ChatColor.GRAY + "Smelting in progress"));
            }
            pane.setItemMeta(meta);
        }
        inv.setItem(13, pane);
    }

    private static ItemStack cloneOrNull(ItemStack item) {
        return item != null && item.getType() != Material.AIR ? item.clone() : null;
    }

    static class FurnaceState {
        ItemStack ore;
        ItemStack fuel;
        ItemStack output;
        int progressTicks = 0;
        int fuelTicksRemaining = 0;

        FurnaceState() {
        }
    }
}

