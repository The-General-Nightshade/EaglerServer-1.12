package com.shadowlord.futurecraft.macewind.util;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public final class EnchantUtils {
    public static final String DENSITY = "Density";
    public static final String BREACH = "Breach";
    public static final String WIND_BURST = "Wind Burst";
    private static final String BOOK_MARKER = ChatColor.DARK_GRAY + "Mace Enchantment";
    private static final String[] ROMAN = {"", "I", "II", "III", "IV", "V"};

    private EnchantUtils() {
    }

    public static String toRoman(int level) {
        if (level < 1) {
            return "";
        }
        return level < ROMAN.length ? ROMAN[level] : Integer.toString(level);
    }

    public static Map<String, Integer> getEnchantments(ItemStack item) {
        Map<String, Integer> result = new LinkedHashMap<String, Integer>();
        if (item == null || !item.hasItemMeta()) {
            return result;
        }
        ItemMeta meta = item.getItemMeta();
        if (meta == null || !meta.hasLore() || meta.getLore() == null) {
            return result;
        }
        for (String line : meta.getLore()) {
            String plain = ChatColor.stripColor(line == null ? "" : line).trim();
            for (String name : allNames()) {
                if (!plain.toLowerCase(Locale.ROOT).startsWith(name.toLowerCase(Locale.ROOT))) {
                    continue;
                }
                String remainder = plain.substring(name.length()).trim();
                int level = remainder.isEmpty() ? 1 : fromRoman(remainder);
                if (level > 0 && level <= getMaxLevel(name)) {
                    result.put(name, level);
                }
                break;
            }
        }
        return result;
    }

    public static int getLevel(ItemStack item, String enchantName) {
        Integer level = getEnchantments(item).get(enchantName);
        return level == null ? 0 : level;
    }

    public static boolean addEnchantment(ItemStack item, String enchantName, int level) {
        if (!ItemUtils.isMace(item)) {
            return false;
        }
        enchantName = normaliseName(enchantName);
        if (enchantName == null || level < 1 || level > getMaxLevel(enchantName)) {
            return false;
        }
        Map<String, Integer> enchants = getEnchantments(item);
        if ((DENSITY.equals(enchantName) && enchants.containsKey(BREACH))
            || (BREACH.equals(enchantName) && enchants.containsKey(DENSITY))) {
            return false;
        }
        enchants.put(enchantName, level);
        writeLore(item, enchants);
        return true;
    }

    public static boolean removeEnchantment(ItemStack item, String enchantName) {
        if (!ItemUtils.isMace(item)) {
            return false;
        }
        enchantName = normaliseName(enchantName);
        if (enchantName == null) {
            return false;
        }
        Map<String, Integer> enchants = getEnchantments(item);
        if (enchants.remove(enchantName) == null) {
            return false;
        }
        writeLore(item, enchants);
        return true;
    }

    public static void clearEnchantments(ItemStack item) {
        if (ItemUtils.isMace(item)) {
            writeLore(item, new LinkedHashMap<String, Integer>());
        }
    }

    public static ItemStack createEnchantBook(String enchantName, int level) {
        enchantName = normaliseName(enchantName);
        if (enchantName == null || level < 1 || level > getMaxLevel(enchantName)) {
            return null;
        }
        ItemStack book = new ItemStack(Material.BOOK, 1);
        ItemMeta meta = book.getItemMeta();
        if (meta == null) {
            return null;
        }
        meta.setDisplayName(
            ChatColor.AQUA + "" + ChatColor.BOLD + enchantName + " " + toRoman(level)
        );
        List<String> lore = new ArrayList<String>();
        lore.add(BOOK_MARKER);
        lore.add("");
        lore.add(ChatColor.GRAY + getDescription(enchantName, level));
        lore.add("");
        lore.add(ChatColor.YELLOW + "Click on a Mace to apply");
        meta.setLore(lore);
        book.setItemMeta(meta);
        return book;
    }

    public static boolean isEnchantBook(ItemStack item) {
        if (item == null || item.getType() != Material.BOOK || !item.hasItemMeta()) {
            return false;
        }
        ItemMeta meta = item.getItemMeta();
        return meta != null && meta.hasLore() && meta.getLore() != null
            && meta.getLore().contains(BOOK_MARKER);
    }

    public static Object[] parseEnchantBook(ItemStack item) {
        if (!isEnchantBook(item)) {
            return null;
        }
        ItemMeta meta = item.getItemMeta();
        if (meta == null || !meta.hasDisplayName()) {
            return null;
        }
        String plain = ChatColor.stripColor(meta.getDisplayName()).trim();
        for (String enchantName : allNames()) {
            if (!plain.toLowerCase(Locale.ROOT).startsWith(enchantName.toLowerCase(Locale.ROOT))) {
                continue;
            }
            String remainder = plain.substring(enchantName.length()).trim();
            int level = remainder.isEmpty() ? 1 : fromRoman(remainder);
            if (level >= 1 && level <= getMaxLevel(enchantName)) {
                return new Object[] {enchantName, level};
            }
        }
        return null;
    }

    public static String normaliseName(String input) {
        if (input == null) {
            return null;
        }
        String normalized = input.trim().toLowerCase(Locale.ROOT).replace('_', ' ');
        if ("density".equals(normalized)) {
            return DENSITY;
        }
        if ("breach".equals(normalized)) {
            return BREACH;
        }
        if ("wind burst".equals(normalized) || "windburst".equals(normalized)) {
            return WIND_BURST;
        }
        return null;
    }

    public static int getMaxLevel(String name) {
        if (DENSITY.equals(name)) {
            return 5;
        }
        if (BREACH.equals(name)) {
            return 4;
        }
        if (WIND_BURST.equals(name)) {
            return 3;
        }
        return 0;
    }

    public static String[] allNames() {
        return new String[] {DENSITY, BREACH, WIND_BURST};
    }

    private static int fromRoman(String value) {
        if (value == null || value.trim().isEmpty()) {
            return 1;
        }
        String upper = value.trim().toUpperCase(Locale.ROOT);
        for (int level = 1; level < ROMAN.length; level++) {
            if (ROMAN[level].equals(upper)) {
                return level;
            }
        }
        try {
            return Integer.parseInt(upper);
        } catch (NumberFormatException exception) {
            return 0;
        }
    }

    private static void writeLore(ItemStack item, Map<String, Integer> enchants) {
        ItemMeta meta = item.getItemMeta();
        if (meta == null) {
            return;
        }
        List<String> lore = new ArrayList<String>();
        if (meta.hasLore() && meta.getLore() != null) {
            for (String line : meta.getLore()) {
                if (!isEnchantLine(line)) {
                    lore.add(line);
                }
            }
        }
        for (Map.Entry<String, Integer> entry : enchants.entrySet()) {
            lore.add(ChatColor.GRAY + entry.getKey() + " " + toRoman(entry.getValue()));
        }
        meta.setLore(lore.isEmpty() ? null : lore);
        item.setItemMeta(meta);
    }

    private static boolean isEnchantLine(String line) {
        String plain = ChatColor.stripColor(line == null ? "" : line).trim()
            .toLowerCase(Locale.ROOT);
        return plain.startsWith("density")
            || plain.startsWith("breach")
            || plain.startsWith("wind burst");
    }

    private static String getDescription(String enchantName, int level) {
        if (DENSITY.equals(enchantName)) {
            return "+" + String.format("%.1f", 0.5D * level)
                + " smash damage per block fallen";
        }
        if (BREACH.equals(enchantName)) {
            return "Bypasses " + 15 * level + "% of target armor";
        }
        if (WIND_BURST.equals(enchantName)) {
            return "Launches you upward on smash hit (Lvl " + level + ")";
        }
        return "";
    }
}
