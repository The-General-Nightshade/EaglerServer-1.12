package com.shadowlord.futurecraft.crossbows;

import com.shadowlord.futurecraft.FutureCraft;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.inventory.ShapedRecipe;

public final class CrossbowRecipe {
    private CrossbowRecipe() {
    }

    public static void register(FutureCraft plugin) {
        if (plugin == null || !plugin.getConfig().getBoolean("crossbows.crafting.enabled", true)) {
            return;
        }
        ShapedRecipe recipe = new ShapedRecipe(CrossbowItem.create());
        recipe.shape("SIS", "THT", " S ");
        recipe.setIngredient('S', Material.STICK);
        recipe.setIngredient('T', Material.STRING);
        recipe.setIngredient('I', Material.IRON_INGOT);
        recipe.setIngredient('H', Material.TRIPWIRE_HOOK);
        Bukkit.addRecipe(recipe);
        plugin.getLogger().info("Crossbow crafting recipe registered.");
    }
}
