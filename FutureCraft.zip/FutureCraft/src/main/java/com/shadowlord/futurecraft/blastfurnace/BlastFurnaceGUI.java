package com.shadowlord.futurecraft.blastfurnace;

import com.shadowlord.futurecraft.FutureCraft;
import com.shadowlord.futurecraft.blastfurnace.BlastFurnaceManager;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class BlastFurnaceGUI
implements Listener {
    private static final String TITLE = ChatColor.DARK_GRAY + "Blast Furnace";
    private static final int SIZE = 27;
    private static final int INDEX_O = 2;
    private static final int INDEX_S = 13;
    private static final int INDEX_I = 15;
    private static final int INDEX_F = 20;
    private static final Set<Integer> FRAME_SLOTS = new HashSet<Integer>();
    private static final Map<Inventory, Location> invLocationMap = new ConcurrentHashMap<Inventory, Location>();

    public BlastFurnaceGUI() {
    }

    public BlastFurnaceGUI(FutureCraft plugin) {
    }

    private static Inventory createGui() {
        Inventory inv = Bukkit.createInventory(null, (int)27, (String)TITLE);
        ItemStack redPane = new ItemStack(Material.STAINED_GLASS_PANE, 1, (short)14);
        ItemMeta pm = redPane.getItemMeta();
        if (pm != null) {
            pm.setDisplayName(ChatColor.RED + " ");
            redPane.setItemMeta(pm);
        }
        for (int i = 0; i < 27; ++i) {
            inv.setItem(i, redPane.clone());
        }
        inv.setItem(2, null);
        inv.setItem(20, null);
        inv.setItem(15, null);
        return inv;
    }

    public static void openGui(Player p) {
        Inventory inv = BlastFurnaceGUI.createGui();
        invLocationMap.put(inv, null);
        BlastFurnaceManager.startVirtual(inv);
        p.openInventory(inv);
    }

    public static void openGui(Player p, Location loc) {
        if (loc == null) {
            BlastFurnaceGUI.openGui(p);
            return;
        }
        Inventory inv = BlastFurnaceGUI.createGui();
        invLocationMap.put(inv, loc);
        BlastFurnaceManager.startIfNeeded(loc);
        BlastFurnaceManager.openInventory(loc, inv);
        p.openInventory(inv);
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent e) {
        Inventory top = e.getInventory();
        if (top == null || !TITLE.equals(top.getTitle())) {
            return;
        }
        int rawSlot = e.getRawSlot();
        HumanEntity clicker = e.getWhoClicked();
        if (rawSlot >= 27) {
            if (e.isShiftClick()) {
                e.setCancelled(true);
                return;
            }
            return;
        }
        if (FRAME_SLOTS.contains(rawSlot)) {
            e.setCancelled(true);
            return;
        }
        if (rawSlot == 13) {
            e.setCancelled(true);
            return;
        }
        e.setCancelled(true);
        if (rawSlot == 15) {
            boolean collected = BlastFurnaceManager.attemptCollect(top, clicker);
            if (collected && clicker instanceof Player) {
                ((Player)clicker).updateInventory();
            }
            this.notifyManager(top);
            return;
        }
        if (rawSlot == 20) {
            this.handleInputSlot(top, 20, e, true);
            this.notifyManager(top);
            return;
        }
        if (rawSlot == 2) {
            this.handleInputSlot(top, 2, e, false);
            this.notifyManager(top);
            return;
        }
    }

    private void handleInputSlot(Inventory inv, int slot, InventoryClickEvent e, boolean fuelOnly) {
        boolean hasCurrent;
        HumanEntity clicker = e.getWhoClicked();
        ItemStack cursor = e.getCursor();
        ItemStack current = inv.getItem(slot);
        boolean hasCursor = cursor != null && cursor.getType() != Material.AIR;
        boolean bl = hasCurrent = current != null && current.getType() != Material.AIR;
        if (hasCursor && !hasCurrent) {
            if (fuelOnly && !BlastFurnaceManager.isFuel(cursor)) {
                return;
            }
            inv.setItem(slot, cursor.clone());
            clicker.setItemOnCursor(null);
        } else if (!hasCursor && hasCurrent) {
            clicker.setItemOnCursor(current.clone());
            inv.setItem(slot, null);
        } else if (hasCursor && hasCurrent) {
            if (fuelOnly && !BlastFurnaceManager.isFuel(cursor)) {
                return;
            }
            ItemStack old = current.clone();
            inv.setItem(slot, cursor.clone());
            clicker.setItemOnCursor(old);
        }
    }

    private void notifyManager(Inventory inv) {
        Location loc = invLocationMap.get(inv);
        if (loc == null) {
            BlastFurnaceManager.syncVirtual(inv);
        } else {
            BlastFurnaceManager.syncFromInventory(loc, inv);
        }
    }

    @EventHandler
    public void onInventoryClose(InventoryCloseEvent e) {
        Inventory inv = e.getInventory();
        if (inv == null || !TITLE.equals(inv.getTitle())) {
            return;
        }
        Location loc = invLocationMap.remove(inv);
        if (loc == null) {
            this.returnItems(inv, e.getPlayer());
            BlastFurnaceManager.stopVirtual(inv);
        } else {
            BlastFurnaceManager.closeInventory(loc, inv);
        }
    }

    private void returnItems(Inventory inv, HumanEntity player) {
        for (int slot : new int[]{2, 20, 15}) {
            ItemStack item = inv.getItem(slot);
            if (item == null || item.getType() == Material.AIR) continue;
            player.getInventory().addItem(new ItemStack[]{item.clone()});
            inv.setItem(slot, null);
        }
    }

    static {
        for (int i = 0; i < 27; ++i) {
            FRAME_SLOTS.add(i);
        }
        FRAME_SLOTS.remove(2);
        FRAME_SLOTS.remove(13);
        FRAME_SLOTS.remove(15);
        FRAME_SLOTS.remove(20);
    }
}

