package com.shadowlord.futurecraft.smithing;

import com.shadowlord.futurecraft.util.ItemNBT;
import java.util.Arrays;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public final class SmithingTableItem {
    private static final String NBT_KEY = "futurecraft:smithing_table";

    private SmithingTableItem() {
    }

    public static ItemStack create() {
        ItemStack item = new ItemStack(Material.WORKBENCH, 1);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(ChatColor.AQUA + "Smithing Table");
            meta.setLore(Arrays.asList(ChatColor.GRAY + "Place and right-click to upgrade gear"));
            item.setItemMeta(meta);
        }
        ItemNBT.setStringTag(item, NBT_KEY, "1");
        return item;
    }

    public static boolean isSmithingTable(ItemStack item) {
        if (item == null || item.getType() != Material.WORKBENCH) {
            return false;
        }
        String tag = ItemNBT.getStringTag(item, NBT_KEY);
        return "1".equals(tag);
    }
}

