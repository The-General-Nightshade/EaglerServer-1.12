package com.shadowlord.futurecraft.util;

import java.util.List;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class ItemBuilder {
    private final ItemStack item;
    private final ItemMeta meta;

    public ItemBuilder(Material mat, int amount) {
        this.item = new ItemStack(mat, amount);
        this.meta = this.item.getItemMeta();
    }

    public ItemBuilder name(String name) {
        this.meta.setDisplayName(name);
        return this;
    }

    public ItemBuilder lore(List<String> lore) {
        this.meta.setLore(lore);
        return this;
    }

    public ItemBuilder unbreakable(boolean unbreakable) {
        try {
            this.meta.setUnbreakable(unbreakable);
        }
        catch (NoSuchMethodError noSuchMethodError) {
            // empty catch block
        }
        return this;
    }

    public ItemStack build() {
        this.item.setItemMeta(this.meta);
        return this.item;
    }

    public static ItemStack clone(ItemStack in) {
        if (in == null) {
            return null;
        }
        return in.clone();
    }
}

