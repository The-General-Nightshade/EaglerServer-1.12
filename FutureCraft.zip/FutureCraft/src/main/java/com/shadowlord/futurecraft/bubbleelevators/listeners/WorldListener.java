package com.shadowlord.futurecraft.bubbleelevators.listeners;

import com.shadowlord.futurecraft.bubbleelevators.BubbleElevatorsModule;
import org.bukkit.Chunk;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockFromToEvent;
import org.bukkit.event.block.BlockPhysicsEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.player.PlayerBucketEmptyEvent;
import org.bukkit.event.world.ChunkLoadEvent;
import org.bukkit.event.world.ChunkUnloadEvent;

public final class WorldListener implements Listener {
    private final BubbleElevatorsModule module;

    public WorldListener(BubbleElevatorsModule module) {
        this.module = module;
    }

    @EventHandler(ignoreCancelled = true)
    public void onBlockPlace(BlockPlaceEvent event) {
        this.handleBlockChange(event.getBlockPlaced());
    }

    @EventHandler(ignoreCancelled = true)
    public void onBlockBreak(BlockBreakEvent event) {
        Block block = event.getBlock();
        if (block.getType() == Material.SOUL_SAND || block.getType() == Material.MAGMA) {
            this.module.getBubbleManager().removeColumnsAtXZ(
                block.getWorld(),
                block.getX(),
                block.getZ()
            );
        }
        this.handleBlockChange(block);
    }

    @EventHandler(ignoreCancelled = true)
    public void onBlockFromTo(BlockFromToEvent event) {
        this.handleBlockChange(event.getBlock());
        this.handleBlockChange(event.getToBlock());
    }

    @EventHandler(ignoreCancelled = true)
    public void onBlockPhysics(BlockPhysicsEvent event) {
        this.handleBlockChange(event.getBlock());
    }

    @EventHandler(ignoreCancelled = true)
    public void onPlayerBucketEmpty(PlayerBucketEmptyEvent event) {
        Block placed = event.getBlockClicked().getRelative(event.getBlockFace());
        this.handleBlockChange(placed);
        for (BlockFace face : new BlockFace[] {
            BlockFace.NORTH,
            BlockFace.SOUTH,
            BlockFace.EAST,
            BlockFace.WEST,
            BlockFace.UP,
            BlockFace.DOWN
        }) {
            this.handleBlockChange(placed.getRelative(face));
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onChunkLoad(ChunkLoadEvent event) {
        this.module.queueChunkScan(event.getChunk());
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onChunkUnload(ChunkUnloadEvent event) {
        Chunk chunk = event.getChunk();
        this.module.getBubbleManager().removeColumnsInChunk(
            chunk.getWorld(),
            chunk.getX(),
            chunk.getZ()
        );
    }

    private void handleBlockChange(Block block) {
        this.module.queueBlockChange(block);
    }
}
