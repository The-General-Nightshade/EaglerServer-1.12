package com.shadowlord.futurecraft.debris;

import com.shadowlord.futurecraft.util.NBTUtil;
import java.util.Arrays;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public final class DebrisItem {
    private static final String NBT_KEY = "futurecraft:debris";
    private static final String DISPLAY = ChatColor.DARK_PURPLE + "Ancient Debris";

    private DebrisItem() {
    }

    public static ItemStack createDebris(int amount) {
        ItemStack it = new ItemStack(Material.OBSIDIAN, Math.max(1, amount));
        ItemMeta meta = it.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(DISPLAY);
            meta.setLore(Arrays.asList(ChatColor.GRAY + "A strange, dense material from deep within the Nether."));
            it.setItemMeta(meta);
        }
        NBTUtil.setStringTag(it, NBT_KEY, "1");
        return it;
    }

    public static boolean isDebris(ItemStack it) {
        if (it == null) {
            return false;
        }
        return NBTUtil.hasTag(it, NBT_KEY) || NBTUtil.hasTag(it, "futurecraft:ancient_debris");
    }
}

