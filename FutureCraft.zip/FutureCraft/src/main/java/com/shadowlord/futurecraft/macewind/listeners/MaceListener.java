package com.shadowlord.futurecraft.macewind.listeners;

import com.shadowlord.futurecraft.macewind.MaceWindModule;
import com.shadowlord.futurecraft.macewind.util.EnchantUtils;
import com.shadowlord.futurecraft.macewind.util.ItemUtils;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import org.bukkit.ChatColor;
import org.bukkit.Effect;
import org.bukkit.Location;
import org.bukkit.Sound;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.plugin.Plugin;
import org.bukkit.util.Vector;

public final class MaceListener implements Listener {
    private static final String SMASH_HIT_META = "MaceWind_SmashHit";
    private final MaceWindModule module;
    private final Map<UUID, Double> fallStartY = new HashMap<UUID, Double>();
    private final Map<UUID, Double> recordedFallDist = new HashMap<UUID, Double>();
    private final Map<UUID, Long> lastHitTs = new HashMap<UUID, Long>();

    public MaceListener(MaceWindModule module) {
        this.module = module;
    }

    public void clear() {
        this.fallStartY.clear();
        this.recordedFallDist.clear();
        this.lastHitTs.clear();
    }

    @EventHandler
    public void onPlayerMove(PlayerMoveEvent event) {
        if (event.getFrom() == null || event.getTo() == null) {
            return;
        }
        Player player = event.getPlayer();
        UUID id = player.getUniqueId();
        if (event.getTo().getY() < event.getFrom().getY()
            && !player.isFlying() && !player.isGliding()) {
            this.fallStartY.putIfAbsent(id, event.getFrom().getY());
        }
        if (player.isOnGround() && this.fallStartY.containsKey(id)) {
            double distance = this.fallStartY.remove(id) - event.getTo().getY();
            this.recordedFallDist.put(id, Math.max(0.0D, distance));
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onFallDamage(EntityDamageEvent event) {
        if (event.getCause() != EntityDamageEvent.DamageCause.FALL
            || !(event.getEntity() instanceof Player)) {
            return;
        }
        Player player = (Player)event.getEntity();
        if (player.hasMetadata(SMASH_HIT_META)) {
            event.setCancelled(true);
            player.removeMetadata(SMASH_HIT_META, this.module.getHost());
            return;
        }
        if (ItemUtils.isMace(player.getInventory().getItemInMainHand())
            && this.recordedFallDist.containsKey(player.getUniqueId())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onEntityDamage(EntityDamageByEntityEvent event) {
        if (!(event.getDamager() instanceof Player)) {
            return;
        }
        Player attacker = (Player)event.getDamager();
        ItemStack weapon = attacker.getInventory().getItemInMainHand();
        if (!ItemUtils.isMace(weapon)) {
            return;
        }

        UUID attackerId = attacker.getUniqueId();
        long now = System.currentTimeMillis();
        long debounce = Math.max(0L, this.module.getConfig().getLong("mace.hit-debounce-ms", 50L));
        Long lastHit = this.lastHitTs.get(attackerId);
        if (lastHit != null && now - lastHit < debounce) {
            return;
        }
        this.lastHitTs.put(attackerId, now);

        double fallDistance = getFallDistance(attacker, attackerId);
        double threshold = Math.max(0.0D, this.module.getConfig().getDouble(
            "mace.fall-threshold", 1.5D
        ));
        double bonus = calculateSmashBonus(weapon, fallDistance, threshold);
        boolean smash = fallDistance > threshold;

        if (smash) {
            attacker.setMetadata(
                SMASH_HIT_META,
                new FixedMetadataValue(this.module.getHost(), Boolean.TRUE)
            );
            this.module.getHost().getServer().getScheduler().runTaskLater(
                this.module.getHost(),
                () -> attacker.removeMetadata(SMASH_HIT_META, this.module.getHost()),
                2L
            );
        }

        double totalDamage = this.module.getConfig().getDouble("mace.base-damage", 7.0D) + bonus;
        int breachLevel = EnchantUtils.getLevel(weapon, EnchantUtils.BREACH);
        if (breachLevel > 0 && event.getEntity() instanceof LivingEntity) {
            double percent = this.module.getConfig().getDouble(
                "mace.enchants.breach-percent-per-level", 15.0D
            );
            try {
                EntityDamageEvent.DamageModifier armor =
                    EntityDamageEvent.DamageModifier.ARMOR;
                if (event.isApplicable(armor)) {
                    double armorDamage = event.getDamage(armor);
                    event.setDamage(
                        armor,
                        armorDamage * (1.0D - Math.min(1.0D, percent * breachLevel / 100.0D))
                    );
                }
            } catch (UnsupportedOperationException ignored) {
                // Bukkit builds that do not expose damage modifiers retain normal armor handling.
            }
        }
        try {
            event.setDamage(EntityDamageEvent.DamageModifier.BASE, totalDamage);
        } catch (UnsupportedOperationException ignored) {
            event.setDamage(totalDamage);
        }

        applyKnockback(attacker, event.getEntity(), bonus);
        int windBurstLevel = EnchantUtils.getLevel(weapon, EnchantUtils.WIND_BURST);
        if (smash && windBurstLevel > 0) {
            double base = this.module.getConfig().getDouble(
                "mace.enchants.wind-burst-base-launch", 0.6D
            );
            double perLevel = this.module.getConfig().getDouble(
                "mace.enchants.wind-burst-per-level", 0.35D
            );
            attacker.setVelocity(new Vector(0.0D, base + perLevel * windBurstLevel, 0.0D));
        }
        playFeedback(event.getEntity().getLocation(), attacker, bonus);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        UUID id = event.getPlayer().getUniqueId();
        this.fallStartY.remove(id);
        this.recordedFallDist.remove(id);
        this.lastHitTs.remove(id);
    }

    private double getFallDistance(Player attacker, UUID id) {
        Double recorded = this.recordedFallDist.remove(id);
        if (recorded != null) {
            return recorded;
        }
        double velocityY = attacker.getVelocity().getY();
        return velocityY < 0.0D ? Math.abs(velocityY) * 2.0D : 0.0D;
    }

    private double calculateSmashBonus(ItemStack mace, double distance, double threshold) {
        if (distance <= threshold) {
            return 0.0D;
        }
        double remaining = distance - threshold;
        double densityExtra = EnchantUtils.getLevel(mace, EnchantUtils.DENSITY)
            * this.module.getConfig().getDouble(
                "mace.enchants.density-per-block-per-level", 0.5D
            );
        double tier1End = Math.max(0.0D, this.module.getConfig().getDouble(
            "mace.tier1-blocks", 3.0D
        ));
        double tier2End = Math.max(tier1End, this.module.getConfig().getDouble(
            "mace.tier2-blocks", 8.0D
        ));
        double tier1 = Math.min(remaining, tier1End);
        double bonus = tier1 * (
            this.module.getConfig().getDouble("mace.tier1-per-block", 4.0D) + densityExtra
        );
        remaining -= tier1;
        if (remaining > 0.0D) {
            double tier2 = Math.min(remaining, tier2End - tier1End);
            bonus += tier2 * (
                this.module.getConfig().getDouble("mace.tier2-per-block", 2.0D) + densityExtra
            );
            remaining -= tier2;
        }
        if (remaining > 0.0D) {
            bonus += remaining * (
                this.module.getConfig().getDouble("mace.tier3-per-block", 1.0D) + densityExtra
            );
        }
        return bonus;
    }

    private void applyKnockback(Player attacker, Entity target, double bonus) {
        Location targetLocation = target.getLocation();
        Vector direction = targetLocation.toVector()
            .subtract(attacker.getLocation().toVector());
        if (direction.lengthSquared() > 0.0D) {
            direction.normalize();
        }
        double horizontal = this.module.getConfig().getDouble(
            "mace.knockback.horizontal-multiplier", 0.5D
        );
        double cap = this.module.getConfig().getDouble(
            "mace.knockback.horizontal-bonus-cap", 1.2D
        );
        double vertical = this.module.getConfig().getDouble(
            "mace.knockback.vertical-base", 0.3D
        ) + Math.min(
            this.module.getConfig().getDouble("mace.knockback.vertical-bonus-cap", 0.5D),
            bonus / 8.0D
        );
        direction.setY(vertical);
        direction.multiply(horizontal + Math.min(cap, bonus / 8.0D));
        target.setVelocity(direction);
    }

    private void playFeedback(Location location, Player attacker, double bonus) {
        if (this.module.getConfig().getBoolean("mace.feedback.enable-effect", true)) {
            try {
                location.getWorld().playEffect(
                    location,
                    Effect.valueOf(this.module.getConfig().getString(
                        "mace.feedback.effect", "STEP_SOUND"
                    )),
                    this.module.getConfig().getInt("mace.feedback.effect-data", 42)
                );
            } catch (IllegalArgumentException ignored) {
                // Invalid effect names should not break the damage handler.
            }
        }
        if (this.module.getConfig().getBoolean("mace.feedback.enable-sound", true)) {
            try {
                Sound sound = Sound.valueOf(this.module.getConfig().getString(
                    "mace.feedback.sound", "ANVIL_LAND"
                ));
                location.getWorld().playSound(location, sound, 0.8F, 1.2F);
            } catch (IllegalArgumentException ignored) {
                location.getWorld().playSound(
                    location,
                    Sound.valueOf("BLOCK_ANVIL_LAND"),
                    0.8F,
                    1.2F
                );
            }
        }
        if (bonus > 0.5D
            && this.module.getConfig().getBoolean("mace.feedback.action-message-enabled", true)) {
            String template = this.module.getConfig().getString(
                "mace.feedback.action-message-template",
                "Crushing Blow! +{bonus} damage"
            );
            attacker.sendMessage(
                ChatColor.GRAY + template.replace("{bonus}", String.format("%.1f", bonus))
            );
        }
    }
}
