package com.shadowlord.futurecraft.smithing;

import com.shadowlord.futurecraft.FutureCraft;
import com.shadowlord.futurecraft.items.TemplateDefaults;
import com.shadowlord.futurecraft.items.UpgradeTemplateItem;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.CraftItemEvent;
import org.bukkit.event.inventory.PrepareItemCraftEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.Recipe;
import org.bukkit.inventory.ShapedRecipe;
import org.bukkit.material.MaterialData;

public final class SmithingRecipe {
    private SmithingRecipe() {
    }

    public static void register(FutureCraft plugin) {
        if (plugin == null) {
            return;
        }
        ItemStack smithingTable = com.shadowlord.futurecraft.smithing.SmithingTableItem.create();
        for (byte woodData = 0; woodData <= 5; ++woodData) {
            ShapedRecipe tableRecipe = new ShapedRecipe(smithingTable);
            tableRecipe.shape(new String[]{"II", "PP", "PP"});
            tableRecipe.setIngredient('I', Material.IRON_INGOT);
            tableRecipe.setIngredient('P', new MaterialData(Material.WOOD, woodData));
            Bukkit.addRecipe((Recipe)tableRecipe);
        }

        ItemStack template = UpgradeTemplateItem.createTemplate(TemplateDefaults.defaultNetheriteMapping());
        template.setAmount(2);
        ShapedRecipe templateRecipe = new ShapedRecipe(template);
        templateRecipe.shape(new String[]{"DND", "DTD", "DDD"});
        templateRecipe.setIngredient('D', Material.DIAMOND);
        templateRecipe.setIngredient('N', Material.NETHERRACK);
        // Paper is used for the recipe matcher; the listener below requires
        // the custom universal template marker before allowing the result.
        templateRecipe.setIngredient('T', Material.PAPER);
        Bukkit.addRecipe((Recipe)templateRecipe);
        Bukkit.getPluginManager().registerEvents(new TemplateDuplicationListener(), plugin);
        plugin.getLogger().info("Registered vanilla smithing table and template duplication recipes.");
    }

    private static final class TemplateDuplicationListener
    implements Listener {
        @EventHandler(priority=EventPriority.HIGH, ignoreCancelled=true)
        public void onPrepare(PrepareItemCraftEvent event) {
            if (!SmithingRecipe.isTemplateResult(event.getRecipe())) {
                return;
            }
            ItemStack[] matrix = event.getInventory().getMatrix();
            if (!SmithingRecipe.hasValidTemplateIngredients(matrix)) {
                event.getInventory().setResult(null);
                return;
            }
            ItemStack template = SmithingRecipe.findTemplate(matrix);
            String mapping = UpgradeTemplateItem.getMapping(template);
            if (mapping == null || mapping.isEmpty()) {
                mapping = TemplateDefaults.defaultNetheriteMapping();
            }
            ItemStack result = UpgradeTemplateItem.createTemplate(mapping);
            result.setAmount(2);
            event.getInventory().setResult(result);
        }

        @EventHandler(priority=EventPriority.HIGH, ignoreCancelled=true)
        public void onCraft(CraftItemEvent event) {
            if (SmithingRecipe.isTemplateResult(event.getRecipe())
                && !SmithingRecipe.hasValidTemplateIngredients(event.getInventory().getMatrix())) {
                event.setCancelled(true);
                event.getInventory().setResult(null);
            }
        }
    }

    private static boolean isTemplateResult(Recipe recipe) {
        return recipe != null
            && recipe.getResult() != null
            && recipe.getResult().getType() == Material.PAPER
            && UpgradeTemplateItem.isTemplate(recipe.getResult());
    }

    private static boolean hasValidTemplateIngredients(ItemStack[] matrix) {
        if (matrix == null || matrix.length != 9) {
            return false;
        }
        int templates = 0;
        int diamonds = 0;
        int netherrack = 0;
        for (ItemStack item : matrix) {
            if (item == null || item.getType() == Material.AIR) {
                return false;
            }
            if (UpgradeTemplateItem.isTemplate(item)) {
                ++templates;
            } else if (item.getType() == Material.DIAMOND) {
                ++diamonds;
            } else if (item.getType() == Material.NETHERRACK) {
                ++netherrack;
            } else {
                return false;
            }
        }
        return templates == 1 && diamonds == 7 && netherrack == 1;
    }

    private static ItemStack findTemplate(ItemStack[] matrix) {
        for (ItemStack item : matrix) {
            if (UpgradeTemplateItem.isTemplate(item)) {
                return item;
            }
        }
        return null;
    }
}

