package com.shadowlord.futurecraft.commands;

import com.shadowlord.futurecraft.items.TemplateDefaults;
import com.shadowlord.futurecraft.items.UpgradeTemplateItem;
import java.util.Collections;
import java.util.List;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public class CommandGiveTemplate
implements CommandExecutor,
TabCompleter {
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        String targetName = args.length >= 1 ? args[0] : (sender instanceof Player ? sender.getName() : null);
        if (targetName == null) {
            sender.sendMessage(ChatColor.RED + "Specify a player.");
            return true;
        }
        Player target = Bukkit.getPlayer((String)targetName);
        if (target == null) {
            sender.sendMessage(ChatColor.RED + "Player not found: " + targetName);
            return true;
        }
        String mapping = TemplateDefaults.defaultNetheriteMapping();
        ItemStack tpl = UpgradeTemplateItem.createTemplate(mapping);
        target.getInventory().addItem(new ItemStack[]{tpl});
        sender.sendMessage(ChatColor.GREEN + "Gave universal smithing template to " + target.getName() + ".");
        return true;
    }

    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            return null;
        }
        return Collections.emptyList();
    }
}

