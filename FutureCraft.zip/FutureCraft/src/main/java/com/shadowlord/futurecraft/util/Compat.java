package com.shadowlord.futurecraft.util;

import org.bukkit.Bukkit;
import org.bukkit.inventory.CraftingInventory;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public final class Compat {
    private Compat() {
    }

    public static String serverVersion() {
        try {
            String pkg = Bukkit.getServer().getClass().getPackage().getName();
            return pkg.substring(pkg.lastIndexOf(46) + 1);
        }
        catch (Exception e) {
            return "";
        }
    }

    public static boolean isVersionPrefix(String prefix) {
        String v = Compat.serverVersion();
        return v != null && v.startsWith(prefix);
    }

    public static void addAttributeOrFallback(ItemMeta meta, String attributeName, Double amount, Class<?> a, Class<?> b) {
        if (meta == null || attributeName == null) {
            return;
        }
    }

    public static ItemStack[] getMatrixSafe(Inventory inv) {
        if (inv == null) {
            return new ItemStack[0];
        }
        try {
            CraftingInventory ci;
            ItemStack[] matrix;
            if (inv instanceof CraftingInventory && (matrix = (ci = (CraftingInventory)inv).getMatrix()) != null) {
                return (ItemStack[])matrix.clone();
            }
        }
        catch (Throwable ci) {
            // empty catch block
        }
        try {
            ItemStack[] arr = new ItemStack[inv.getSize()];
            for (int i = 0; i < inv.getSize(); ++i) {
                ItemStack it = inv.getItem(i);
                arr[i] = it == null ? null : it.clone();
            }
            return arr;
        }
        catch (Throwable ignored) {
            return new ItemStack[0];
        }
    }
}

