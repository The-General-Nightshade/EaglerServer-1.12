package com.shadowlord.futurecraft.crossbows;
import com.shadowlord.futurecraft.FutureCraft;
import com.shadowlord.futurecraft.piglins.PiglinMechanics;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Arrow;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.PigZombie;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.entity.EntityShootBowEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.event.inventory.PrepareAnvilEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.AnvilInventory;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.metadata.MetadataValue;
import org.bukkit.projectiles.ProjectileSource;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

public final class CrossbowMechanics implements Listener {
    private static final String PIERCING_LEVEL = "futurecraft_piercing_level";
    private static final String PIERCING_REMAINING = "futurecraft_piercing_remaining";
    private static final String PIERCING_DIRECTION = "futurecraft_piercing_direction";
    private static final String PIERCING_SPEED = "futurecraft_piercing_speed";
    private static final double BASE_PROJECTILE_DAMAGE = 2.0D;

    private final FutureCraft plugin;
    private final Random random = new Random();
    private final Map<UUID, Long> nextPiglinShotAt = new HashMap<UUID, Long>();
    private final Map<UUID, Integer> arrowCountsBeforeDraw = new HashMap<UUID, Integer>();
    private BukkitTask piglinTask;
    private long serverTicks;

    public CrossbowMechanics(FutureCraft plugin) {
        this.plugin = plugin;
    }

    public void start() {
        this.piglinTask = new BukkitRunnable() {
            public void run() {
                CrossbowMechanics.this.updatePiglinCrossbows();
            }
        }.runTaskTimer(this.plugin, 5L, 5L);
    }

    public void shutdown() {
        if (this.piglinTask != null) {
            this.piglinTask.cancel();
            this.piglinTask = null;
        }
        this.nextPiglinShotAt.clear();
        this.arrowCountsBeforeDraw.clear();
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onCrossbowUse(PlayerInteractEvent event) {
        if (event.getHand() != null && event.getHand() != EquipmentSlot.HAND) {
            return;
        }
        if (event.getAction() != Action.RIGHT_CLICK_AIR
            && event.getAction() != Action.RIGHT_CLICK_BLOCK) {
            return;
        }
        Player player = event.getPlayer();
        ItemStack crossbow = player.getInventory().getItemInMainHand();
        if (!CrossbowItem.isCrossbow(crossbow)) {
            return;
        }
        if (CrossbowItem.getLoadedAt(crossbow) > 0L) {
            event.setCancelled(true);
            this.fireCrossbow(player, crossbow);
        } else {
            this.arrowCountsBeforeDraw.put(player.getUniqueId(), this.countArrows(player));
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onCrossbowDrawRelease(EntityShootBowEvent event) {
        if (!CrossbowItem.isCrossbow(event.getBow())) {
            return;
        }
        event.setCancelled(true);
        if (!(event.getEntity() instanceof Player)) {
            return;
        }

        Player player = (Player)event.getEntity();
        final Integer arrowsBeforeDraw =
            this.arrowCountsBeforeDraw.remove(player.getUniqueId());
        if (arrowsBeforeDraw != null) {
            Bukkit.getScheduler().runTaskLater(this.plugin, new Runnable() {
                public void run() {
                    CrossbowMechanics.this.restoreArrowsIfConsumed(player, arrowsBeforeDraw);
                }
            }, 1L);
        }
        ItemStack crossbow = player.getInventory().getItemInMainHand();
        if (!CrossbowItem.isCrossbow(crossbow)) {
            crossbow = event.getBow().clone();
        }
        int chargeTicks = this.getRequiredChargeTicks(crossbow);
        float chargeFraction = chargeTicks / 20.0F;
        float requiredForce = (chargeFraction * chargeFraction + 2.0F * chargeFraction) / 3.0F;
        if (event.getForce() + 0.0001F < requiredForce) {
            player.sendMessage(ChatColor.YELLOW
                + "Draw the crossbow further before releasing to load it.");
            return;
        }

        // The bow-release event is intentionally cancelled; a later tap fires the stored shot.
        CrossbowItem.setLoadedAt(crossbow, Math.max(1L, System.currentTimeMillis() - 10000L));
        player.getInventory().setItemInMainHand(crossbow);
        player.sendMessage(ChatColor.GRAY + "Crossbow loaded. Tap right-click to fire.");
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPrepareCrossbowAnvil(PrepareAnvilEvent event) {
        ItemStack first = event.getInventory().getItem(0);
        ItemStack second = event.getInventory().getItem(1);
        ItemStack crossbow = CrossbowItem.isCrossbow(first) ? first
            : (CrossbowItem.isCrossbow(second) ? second : null);
        if (crossbow == null) {
            return;
        }
        ItemStack book = crossbow == first ? second : first;
        String enchantment = CrossbowItem.getBookEnchantment(book);
        if (enchantment == null) {
            return;
        }
        int bookLevel = CrossbowItem.getBookLevel(book);
        if (bookLevel < 1 || bookLevel > CrossbowItem.maxLevel(enchantment)
            || !CrossbowItem.isCompatible(enchantment, crossbow)) {
            event.setResult(null);
            return;
        }

        int currentLevel = CrossbowItem.getEnchantLevel(crossbow, enchantment);
        int newLevel = currentLevel == bookLevel
            ? currentLevel + 1 : Math.max(currentLevel, bookLevel);
        if (newLevel > CrossbowItem.maxLevel(enchantment)) {
            event.setResult(null);
            return;
        }
        event.setResult(CrossbowItem.withEnchantment(crossbow, enchantment, newLevel));
        event.getInventory().setRepairCost(0);
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onTakeCrossbowAnvilResult(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player)
            || event.getView().getTopInventory().getType() != InventoryType.ANVIL
            || event.getRawSlot() != 2) {
            return;
        }
        AnvilInventory anvil = (AnvilInventory)event.getView().getTopInventory();
        ItemStack first = anvil.getItem(0);
        ItemStack second = anvil.getItem(1);
        ItemStack crossbow = CrossbowItem.isCrossbow(first) ? first
            : (CrossbowItem.isCrossbow(second) ? second : null);
        if (crossbow == null) {
            return;
        }
        ItemStack book = crossbow == first ? second : first;
        String enchantment = CrossbowItem.getBookEnchantment(book);
        if (enchantment == null) {
            return;
        }
        event.setCancelled(true);

        int bookLevel = CrossbowItem.getBookLevel(book);
        int currentLevel = CrossbowItem.getEnchantLevel(crossbow, enchantment);
        if (bookLevel < 1 || bookLevel > CrossbowItem.maxLevel(enchantment)
            || !CrossbowItem.isCompatible(enchantment, crossbow)) {
            return;
        }
        int newLevel = currentLevel == bookLevel
            ? currentLevel + 1 : Math.max(currentLevel, bookLevel);
        if (newLevel > CrossbowItem.maxLevel(enchantment)) {
            return;
        }

        Player player = (Player)event.getWhoClicked();
        ItemStack result = CrossbowItem.withEnchantment(crossbow, enchantment, newLevel);
        if (event.isShiftClick()) {
            if (!player.getInventory().addItem(result).isEmpty()) {
                player.sendMessage(ChatColor.RED + "Make room in your inventory first.");
                return;
            }
        } else {
            ItemStack cursor = event.getCursor();
            if (cursor != null && cursor.getType() != Material.AIR) {
                player.sendMessage(ChatColor.RED + "Clear your cursor before taking the result.");
                return;
            }
            player.setItemOnCursor(result);
        }
        anvil.setItem(0, null);
        anvil.setItem(1, null);
        anvil.setItem(2, null);
        anvil.setRepairCost(0);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onCrossbowArrowDamage(EntityDamageByEntityEvent event) {
        if (!(event.getDamager() instanceof Arrow)
            || !(event.getEntity() instanceof LivingEntity)) {
            return;
        }
        Arrow arrow = (Arrow)event.getDamager();
        int piercingLevel = this.getMetadataInt(arrow, PIERCING_LEVEL);
        if (piercingLevel < 1) {
            return;
        }

        LivingEntity target = (LivingEntity)event.getEntity();
        AttributeInstance armor = target.getAttribute(Attribute.GENERIC_ARMOR);
        if (armor != null && armor.getValue() > 0.0D) {
            double armorReduction = Math.min(0.8D, armor.getValue() * 0.04D);
            double bypass = Math.min(0.75D, piercingLevel * 0.15D);
            event.setDamage(event.getDamage()
                * (1.0D + armorReduction * bypass / (1.0D - armorReduction)));
        }

        int remaining = this.getMetadataInt(arrow, PIERCING_REMAINING);
        if (remaining > 0) {
            this.continuePiercingArrow(arrow, target, piercingLevel, remaining);
        }
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onPiglinDeath(EntityDeathEvent event) {
        if (event.getEntity() instanceof PigZombie) {
            this.nextPiglinShotAt.remove(event.getEntity().getUniqueId());
        }
    }

    private void fireCrossbow(Player player, ItemStack crossbow) {
        long loadedAt = CrossbowItem.getLoadedAt(crossbow);
        int quickCharge = CrossbowItem.getEnchantLevel(crossbow, CrossbowItem.QUICK_CHARGE);
        int baseLoadTicks = this.plugin.getConfig().getInt("crossbows.mechanics.load-ticks", 25);
        baseLoadTicks = Math.max(1, Math.min(100, baseLoadTicks));
        int loadTicks = Math.max(1, baseLoadTicks - quickCharge * 5);
        long elapsedTicks = Math.max(0L, (System.currentTimeMillis() - loadedAt) / 50L);
        if (elapsedTicks < loadTicks) {
            long remaining = loadTicks - elapsedTicks;
            player.sendMessage(ChatColor.YELLOW + "Crossbow is loading ("
                + ((remaining + 19L) / 20L) + "s).");
            return;
        }

        boolean creative = player.getGameMode() == GameMode.CREATIVE;
        boolean infinity = crossbow.getEnchantmentLevel(Enchantment.ARROW_INFINITE) > 0;
        int arrowSlot = this.findArrowSlot(player);
        if (!creative && !infinity && arrowSlot < 0) {
            player.sendMessage(ChatColor.RED + "You need an arrow to fire this crossbow.");
            return;
        }
        if (!creative && !infinity) {
            this.consumeArrow(player, arrowSlot);
        }

        int multishot = CrossbowItem.getEnchantLevel(crossbow, CrossbowItem.MULTISHOT);
        int piercing = CrossbowItem.getEnchantLevel(crossbow, CrossbowItem.PIERCING);
        int power = crossbow.getEnchantmentLevel(Enchantment.ARROW_DAMAGE);
        int punch = crossbow.getEnchantmentLevel(Enchantment.ARROW_KNOCKBACK);
        boolean flame = crossbow.getEnchantmentLevel(Enchantment.ARROW_FIRE) > 0;
        int arrowCount = multishot > 0 ? 3 : 1;
        for (int i = 0; i < arrowCount; i++) {
            double angle = arrowCount == 1 ? 0.0D : Math.toRadians((i - 1) * 10.0D);
            this.launchArrow(player, angle, power, punch, flame, piercing);
        }

        CrossbowItem.setLoadedAt(crossbow, 0L);
        player.getInventory().setItemInMainHand(crossbow);
        this.damageCrossbow(player, crossbow);
    }

    private int getRequiredChargeTicks(ItemStack crossbow) {
        int baseLoadTicks = this.plugin.getConfig().getInt("crossbows.mechanics.load-ticks", 20);
        baseLoadTicks = Math.max(1, Math.min(20, baseLoadTicks));
        int quickCharge = CrossbowItem.getEnchantLevel(crossbow, CrossbowItem.QUICK_CHARGE);
        return Math.max(1, baseLoadTicks - quickCharge * 5);
    }

    private void launchArrow(
        Player player,
        double yawOffset,
        int power,
        int punch,
        boolean flame,
        int piercing
    ) {
        Vector look = player.getEyeLocation().getDirection();
        double cosine = Math.cos(yawOffset);
        double sine = Math.sin(yawOffset);
        Vector direction = new Vector(
            look.getX() * cosine - look.getZ() * sine,
            look.getY(),
            look.getX() * sine + look.getZ() * cosine
        ).normalize();
        double speed = this.safeDouble("crossbows.mechanics.projectile-speed", 3.0D, 1.0D, 5.0D);
        Arrow arrow = player.launchProjectile(Arrow.class, direction.clone().multiply(speed));
        arrow.spigot().setDamage(BASE_PROJECTILE_DAMAGE + power * 0.5D
            + (power > 0 ? 0.5D : 0.0D));
        if (punch > 0) {
            arrow.setKnockbackStrength(punch);
        }
        if (flame) {
            arrow.setFireTicks(100);
        }
        if (piercing > 0) {
            this.setMetadata(arrow, PIERCING_LEVEL, piercing);
            this.setMetadata(arrow, PIERCING_REMAINING, piercing);
            arrow.setMetadata(PIERCING_DIRECTION,
                new FixedMetadataValue(this.plugin, direction.clone()));
            arrow.setMetadata(PIERCING_SPEED,
                new FixedMetadataValue(this.plugin, speed));
        }
    }

    private void continuePiercingArrow(
        final Arrow arrow,
        LivingEntity target,
        final int enchantmentLevel,
        final int remaining
    ) {
        final ProjectileSource shooter = arrow.getShooter();
        if (shooter == null) {
            return;
        }
        Vector direction = this.getMetadataVector(arrow, PIERCING_DIRECTION);
        if (direction == null || direction.lengthSquared() < 0.001D) {
            direction = arrow.getVelocity().clone().normalize();
        } else {
            direction.normalize();
        }
        if (direction.lengthSquared() < 0.001D) {
            return;
        }
        final Vector shotDirection = direction.clone();
        double storedSpeed = this.getMetadataDouble(arrow, PIERCING_SPEED);
        final float speed = (float)(storedSpeed > 0.0D
            ? storedSpeed : Math.max(1.0D, arrow.getVelocity().length()));
        final double damage = arrow.spigot().getDamage();
        final int knockback = arrow.getKnockbackStrength();
        final int fireTicks = arrow.getFireTicks();
        final int nextRemaining = remaining - 1;
        final Location spawnLocation = target.getEyeLocation().clone().add(
            shotDirection.clone().multiply(Math.max(1.2D, target.getWidth() * 0.5D + 0.8D))
        );
        final World world = target.getWorld();
        Bukkit.getScheduler().runTaskLater(this.plugin, new Runnable() {
            public void run() {
                if (!world.isChunkLoaded(spawnLocation.getBlockX() >> 4,
                    spawnLocation.getBlockZ() >> 4)) {
                    arrow.remove();
                    return;
                }
                Arrow next = world.spawnArrow(spawnLocation, shotDirection, speed, 0.0F);
                next.setShooter(shooter);
                next.spigot().setDamage(damage);
                if (knockback > 0) {
                    next.setKnockbackStrength(knockback);
                }
                if (fireTicks > 0) {
                    next.setFireTicks(fireTicks);
                }
                CrossbowMechanics.this.setMetadata(next, PIERCING_LEVEL, enchantmentLevel);
                CrossbowMechanics.this.setMetadata(next, PIERCING_REMAINING, nextRemaining);
                next.setMetadata(PIERCING_DIRECTION,
                    new FixedMetadataValue(CrossbowMechanics.this.plugin, shotDirection.clone()));
                next.setMetadata(PIERCING_SPEED,
                    new FixedMetadataValue(CrossbowMechanics.this.plugin, (double)speed));
                arrow.remove();
            }
        }, 1L);
    }

    private void damageCrossbow(Player player, ItemStack crossbow) {
        if (player.getGameMode() == GameMode.CREATIVE) {
            return;
        }
        int unbreaking = crossbow.getEnchantmentLevel(Enchantment.DURABILITY);
        if (unbreaking > 0 && this.random.nextInt(unbreaking + 1) != 0) {
            return;
        }
        int durability = crossbow.getDurability() + 1;
        if (durability >= Material.BOW.getMaxDurability()) {
            player.getInventory().setItemInMainHand(new ItemStack(Material.AIR));
        } else {
            crossbow.setDurability((short)durability);
            player.getInventory().setItemInMainHand(crossbow);
        }
    }

    private int findArrowSlot(Player player) {
        ItemStack offhand = player.getInventory().getItemInOffHand();
        if (offhand != null && offhand.getType() == Material.ARROW && offhand.getAmount() > 0) {
            return 40;
        }
        for (int slot = 0; slot < 36; slot++) {
            ItemStack item = player.getInventory().getItem(slot);
            if (item != null && item.getType() == Material.ARROW && item.getAmount() > 0) {
                return slot;
            }
        }
        return -1;
    }

    private int countArrows(Player player) {
        int count = 0;
        for (int slot = 0; slot < 36; slot++) {
            ItemStack item = player.getInventory().getItem(slot);
            if (item != null && item.getType() == Material.ARROW) {
                count += item.getAmount();
            }
        }
        ItemStack offhand = player.getInventory().getItemInOffHand();
        if (offhand != null && offhand.getType() == Material.ARROW) {
            count += offhand.getAmount();
        }
        return count;
    }

    private void restoreArrowsIfConsumed(Player player, int arrowsBeforeDraw) {
        if (!player.isOnline()) {
            return;
        }
        int consumedByVanilla = arrowsBeforeDraw - this.countArrows(player);
        if (consumedByVanilla <= 0) {
            return;
        }
        Map<Integer, ItemStack> leftovers = player.getInventory().addItem(
            new ItemStack(Material.ARROW, consumedByVanilla)
        );
        for (ItemStack leftover : leftovers.values()) {
            player.getWorld().dropItemNaturally(player.getLocation(), leftover);
        }
    }

    private void consumeArrow(Player player, int slot) {
        ItemStack arrow = slot == 40
            ? player.getInventory().getItemInOffHand()
            : player.getInventory().getItem(slot);
        if (arrow == null || arrow.getType() != Material.ARROW) {
            return;
        }
        if (arrow.getAmount() <= 1) {
            arrow = new ItemStack(Material.AIR);
        } else {
            arrow.setAmount(arrow.getAmount() - 1);
        }
        if (slot == 40) {
            player.getInventory().setItemInOffHand(arrow);
        } else {
            player.getInventory().setItem(slot, arrow);
        }
    }

    private void updatePiglinCrossbows() {
        this.serverTicks += 5L;
        double maxRange = this.safeDouble("crossbows.mechanics.piglin-range", 24.0D, 6.0D, 64.0D);
        long fireInterval = Math.max(10L, Math.min(200L,
            this.plugin.getConfig().getLong("crossbows.mechanics.piglin-fire-interval-ticks", 30L)));
        for (World world : this.plugin.getServer().getWorlds()) {
            if (world.getEnvironment() != World.Environment.NETHER) {
                continue;
            }
            for (Entity entity : world.getEntities()) {
                if (!(entity instanceof PigZombie)) {
                    continue;
                }
                PigZombie piglin = (PigZombie)entity;
                if (!PiglinMechanics.isPiglin(piglin) || PiglinMechanics.isBrute(piglin)
                    || !CrossbowItem.isCrossbow(piglin.getEquipment().getItemInHand())
                    || PiglinMechanics.isNearZombiePigman(piglin,
                        this.safeDouble("piglins.flee-from-pigmen.range", 8.0D, 1.0D, 64.0D))) {
                    continue;
                }
                Player target = this.findPiglinCrossbowTarget(piglin, maxRange);
                if (target == null) {
                    continue;
                }
                double distance = piglin.getLocation().distanceSquared(target.getLocation());
                if (distance < 9.0D || distance > maxRange * maxRange
                    || !piglin.hasLineOfSight(target)) {
                    continue;
                }
                Long nextShot = this.nextPiglinShotAt.get(piglin.getUniqueId());
                if (nextShot != null && this.serverTicks < nextShot.longValue()) {
                    continue;
                }
                this.firePiglinCrossbow(piglin, target);
                this.nextPiglinShotAt.put(piglin.getUniqueId(), this.serverTicks + fireInterval);
            }
        }
    }

    private Player findPiglinCrossbowTarget(PigZombie piglin, double maxRange) {
        if (piglin.getTarget() instanceof Player) {
            Player target = (Player)piglin.getTarget();
            if (target.isOnline() && !target.isDead()
                && target.getWorld() == piglin.getWorld()
                && piglin.getLocation().distanceSquared(target.getLocation())
                    <= maxRange * maxRange) {
                return target;
            }
        }

        Player nearest = null;
        double nearestDistance = maxRange * maxRange;
        for (Entity nearby : piglin.getNearbyEntities(maxRange, maxRange, maxRange)) {
            if (!(nearby instanceof Player)) {
                continue;
            }
            Player candidate = (Player)nearby;
            if (candidate.isDead() || !candidate.isOnline()
                || PiglinMechanics.isWearingGold(candidate)) {
                continue;
            }
            double distance = piglin.getLocation().distanceSquared(candidate.getLocation());
            if (distance < nearestDistance) {
                nearestDistance = distance;
                nearest = candidate;
            }
        }
        return nearest;
    }

    private void firePiglinCrossbow(PigZombie piglin, Player target) {
        Vector direction = target.getEyeLocation().toVector()
            .subtract(piglin.getEyeLocation().toVector()).normalize();
        double speed = this.safeDouble("crossbows.mechanics.projectile-speed", 3.0D, 1.0D, 5.0D);
        Arrow arrow = piglin.launchProjectile(Arrow.class, direction.clone().multiply(speed));
        arrow.spigot().setDamage(BASE_PROJECTILE_DAMAGE + 1.0D);
    }

    private int getMetadataInt(Arrow arrow, String key) {
        for (MetadataValue value : arrow.getMetadata(key)) {
            if (value.getOwningPlugin() == this.plugin) {
                return value.asInt();
            }
        }
        return 0;
    }

    private double getMetadataDouble(Arrow arrow, String key) {
        for (MetadataValue value : arrow.getMetadata(key)) {
            if (value.getOwningPlugin() == this.plugin) {
                return value.asDouble();
            }
        }
        return 0.0D;
    }

    private Vector getMetadataVector(Arrow arrow, String key) {
        for (MetadataValue value : arrow.getMetadata(key)) {
            if (value.getOwningPlugin() == this.plugin && value.value() instanceof Vector) {
                return ((Vector)value.value()).clone();
            }
        }
        return null;
    }

    private void setMetadata(Arrow arrow, String key, int value) {
        arrow.setMetadata(key, new FixedMetadataValue(this.plugin, value));
    }

    private double safeDouble(String path, double fallback, double min, double max) {
        double value = this.plugin.getConfig().getDouble(path, fallback);
        if (Double.isNaN(value) || Double.isInfinite(value)) {
            value = fallback;
        }
        return Math.max(min, Math.min(max, value));
    }
}
