package com.shadowlord.futurecraft.macewind.commands;

import com.shadowlord.futurecraft.macewind.MaceWindModule;
import com.shadowlord.futurecraft.macewind.util.EnchantUtils;
import com.shadowlord.futurecraft.macewind.util.ItemUtils;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public final class MaceWindCommand implements CommandExecutor, TabCompleter {
    private final MaceWindModule module;

    public MaceWindCommand(MaceWindModule module) {
        this.module = module;
    }

    @Override
    public boolean onCommand(
        CommandSender sender,
        Command command,
        String label,
        String[] args
    ) {
        if (args.length == 0) {
            sendHelp(sender);
            return true;
        }

        String subcommand = args[0].toLowerCase(Locale.ROOT);
        switch (subcommand) {
            case "help":
                sendHelp(sender);
                return true;
            case "reload":
                if (checkPermission(sender)) {
                    this.module.reloadConfig();
                    sender.sendMessage(ChatColor.GREEN + "[MaceWind] Config reloaded.");
                }
                return true;
            case "givemace":
                return giveMace(sender, args);
            case "givewind":
                return giveWind(sender, args);
            case "givebook":
                return giveBook(sender, args);
            case "enchant":
                return enchant(sender, args);
            case "unenchant":
                return unenchant(sender, args);
            case "enchants":
                return listEnchants(sender);
            default:
                sendHelp(sender);
                return true;
        }
    }

    @Override
    public List<String> onTabComplete(
        CommandSender sender,
        Command command,
        String alias,
        String[] args
    ) {
        List<String> results = new ArrayList<String>();
        if (args.length == 1) {
            addMatches(results, args[0],
                "help", "reload", "givemace", "givewind", "givebook",
                "enchant", "unenchant", "enchants");
        } else if (args.length == 2) {
            String sub = args[0].toLowerCase(Locale.ROOT);
            if ("givebook".equals(sub) || "enchant".equals(sub)
                || "unenchant".equals(sub)) {
                addMatches(results, args[1], EnchantUtils.allNames());
                if ("unenchant".equals(sub) && "all".startsWith(args[1].toLowerCase(Locale.ROOT))) {
                    results.add("all");
                }
            } else if ("givemace".equals(sub) || "givewind".equals(sub)) {
                addOnlinePlayers(results, args[1]);
            }
        } else if (args.length == 3
            && ("enchant".equalsIgnoreCase(args[0]) || "givebook".equalsIgnoreCase(args[0]))) {
            String enchantName = EnchantUtils.normaliseName(args[1]);
            int maximum = enchantName == null ? 5 : EnchantUtils.getMaxLevel(enchantName);
            for (int level = 1; level <= maximum; level++) {
                String value = Integer.toString(level);
                if (value.startsWith(args[2])) {
                    results.add(value);
                }
            }
        } else if (args.length == 4 && "givebook".equalsIgnoreCase(args[0])) {
            addOnlinePlayers(results, args[3]);
        }
        return results;
    }

    private boolean giveMace(CommandSender sender, String[] args) {
        if (!checkPermission(sender)) {
            return true;
        }
        Player target = resolveTarget(sender, args, 1);
        if (target == null) {
            return true;
        }
        ItemStack mace = ItemUtils.makeMace();
        if (mace == null || !ItemUtils.isMace(mace)) {
            sender.sendMessage(ChatColor.RED + "[MaceWind] Could not create a tagged Mace.");
            return true;
        }
        giveItem(target, mace);
        target.sendMessage(ChatColor.GREEN + "[MaceWind] You received a Mace!");
        notifySender(sender, target, "Gave a Mace to " + target.getName() + ".");
        return true;
    }

    private boolean giveWind(CommandSender sender, String[] args) {
        if (!checkPermission(sender)) {
            return true;
        }
        Player target = resolveTarget(sender, args, 1);
        if (target == null) {
            return true;
        }
        int amount = 1;
        if (args.length >= 3) {
            try {
                amount = Math.max(1, Math.min(64, Integer.parseInt(args[2])));
            } catch (NumberFormatException exception) {
                sender.sendMessage(ChatColor.RED + "[MaceWind] Invalid amount.");
                return true;
            }
        }
        ItemStack windCharge = ItemUtils.makeWindCharge();
        if (windCharge == null || !ItemUtils.isWindCharge(windCharge)) {
            sender.sendMessage(ChatColor.RED + "[MaceWind] Could not create a tagged Wind Charge.");
            return true;
        }
        windCharge.setAmount(amount);
        giveItem(target, windCharge);
        target.sendMessage(ChatColor.GREEN + "[MaceWind] You received " + amount + " Wind Charge(s)!");
        notifySender(sender, target, "Gave " + amount + " Wind Charge(s) to " + target.getName() + ".");
        return true;
    }

    private boolean giveBook(CommandSender sender, String[] args) {
        if (!checkPermission(sender)) {
            return true;
        }
        if (args.length < 3) {
            sender.sendMessage(
                ChatColor.RED + "Usage: /macewind givebook <enchant> <level> [player]"
            );
            return true;
        }
        String enchantName = EnchantUtils.normaliseName(args[1]);
        if (enchantName == null) {
            sender.sendMessage(ChatColor.RED + "[MaceWind] Unknown enchantment: " + args[1]);
            return true;
        }
        int level;
        try {
            level = Integer.parseInt(args[2]);
        } catch (NumberFormatException exception) {
            sender.sendMessage(ChatColor.RED + "[MaceWind] Invalid level.");
            return true;
        }
        if (level < 1 || level > EnchantUtils.getMaxLevel(enchantName)) {
            sender.sendMessage(
                ChatColor.RED + "[MaceWind] Maximum level is "
                    + EnchantUtils.toRoman(EnchantUtils.getMaxLevel(enchantName)) + "."
            );
            return true;
        }
        Player target = resolveTarget(sender, args, 3);
        if (target == null) {
            return true;
        }
        ItemStack book = EnchantUtils.createEnchantBook(enchantName, level);
        if (book == null) {
            sender.sendMessage(ChatColor.RED + "[MaceWind] Could not create the enchantment book.");
            return true;
        }
        giveItem(target, book);
        target.sendMessage(
            ChatColor.GREEN + "[MaceWind] You received "
                + ChatColor.AQUA + enchantName + " " + EnchantUtils.toRoman(level)
                + ChatColor.GREEN + "!"
        );
        notifySender(sender, target, "Gave an enchantment book to " + target.getName() + ".");
        return true;
    }

    private boolean enchant(CommandSender sender, String[] args) {
        if (!checkPermission(sender)) {
            return true;
        }
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + "[MaceWind] Players only.");
            return true;
        }
        if (args.length < 3) {
            sender.sendMessage(ChatColor.RED + "Usage: /macewind enchant <enchant> <level>");
            return true;
        }
        Player player = (Player)sender;
        ItemStack held = player.getInventory().getItemInMainHand();
        if (!ItemUtils.isMace(held)) {
            player.sendMessage(ChatColor.RED + "[MaceWind] Hold a tagged Mace.");
            return true;
        }
        String enchantName = EnchantUtils.normaliseName(args[1]);
        if (enchantName == null) {
            player.sendMessage(ChatColor.RED + "[MaceWind] Unknown enchantment.");
            return true;
        }
        int level;
        try {
            level = Integer.parseInt(args[2]);
        } catch (NumberFormatException exception) {
            player.sendMessage(ChatColor.RED + "[MaceWind] Invalid level.");
            return true;
        }
        if (!EnchantUtils.addEnchantment(held, enchantName, level)) {
            player.sendMessage(
                ChatColor.RED + "[MaceWind] Invalid level or conflicting enchantment."
            );
            return true;
        }
        ItemStack tagged = ItemUtils.ensureMaceTag(player.getInventory().getItemInMainHand());
        player.getInventory().setItemInMainHand(tagged);
        player.sendMessage(
            ChatColor.GREEN + "[MaceWind] Applied " + ChatColor.AQUA
                + enchantName + " " + EnchantUtils.toRoman(level) + ChatColor.GREEN + "."
        );
        return true;
    }

    private boolean unenchant(CommandSender sender, String[] args) {
        if (!checkPermission(sender)) {
            return true;
        }
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + "[MaceWind] Players only.");
            return true;
        }
        if (args.length < 2) {
            sender.sendMessage(ChatColor.RED + "Usage: /macewind unenchant <enchant|all>");
            return true;
        }
        Player player = (Player)sender;
        ItemStack held = player.getInventory().getItemInMainHand();
        if (!ItemUtils.isMace(held)) {
            player.sendMessage(ChatColor.RED + "[MaceWind] Hold a tagged Mace.");
            return true;
        }

        if ("all".equalsIgnoreCase(args[1])) {
            EnchantUtils.clearEnchantments(held);
            player.sendMessage(ChatColor.GREEN + "[MaceWind] Removed all mace enchantments.");
        } else {
            String enchantName = EnchantUtils.normaliseName(args[1]);
            if (enchantName == null) {
                player.sendMessage(ChatColor.RED + "[MaceWind] Unknown enchantment.");
                return true;
            }
            if (!EnchantUtils.removeEnchantment(held, enchantName)) {
                player.sendMessage(
                    ChatColor.RED + "[MaceWind] The Mace does not have " + enchantName + "."
                );
                return true;
            }
            player.sendMessage(ChatColor.GREEN + "[MaceWind] Removed " + enchantName + ".");
        }
        ItemStack tagged = ItemUtils.ensureMaceTag(player.getInventory().getItemInMainHand());
        player.getInventory().setItemInMainHand(tagged);
        return true;
    }

    private boolean listEnchants(CommandSender sender) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + "[MaceWind] Players only.");
            return true;
        }
        ItemStack held = ((Player)sender).getInventory().getItemInMainHand();
        if (!ItemUtils.isMace(held)) {
            sender.sendMessage(ChatColor.RED + "[MaceWind] Hold a tagged Mace.");
            return true;
        }
        Map<String, Integer> enchants = EnchantUtils.getEnchantments(held);
        if (enchants.isEmpty()) {
            sender.sendMessage(ChatColor.GRAY + "[MaceWind] This Mace has no enchantments.");
        } else {
            sender.sendMessage(ChatColor.GREEN + "--- Mace Enchantments ---");
            for (Map.Entry<String, Integer> entry : enchants.entrySet()) {
                sender.sendMessage(
                    ChatColor.AQUA + entry.getKey() + " " + EnchantUtils.toRoman(entry.getValue())
                );
            }
        }
        return true;
    }

    private Player resolveTarget(CommandSender sender, String[] args, int index) {
        if (args.length > index) {
            Player target = Bukkit.getPlayerExact(args[index]);
            if (target == null) {
                sender.sendMessage(ChatColor.RED + "[MaceWind] Player not found: " + args[index]);
            }
            return target;
        }
        if (sender instanceof Player) {
            return (Player)sender;
        }
        sender.sendMessage(ChatColor.RED + "[MaceWind] Specify a player from the console.");
        return null;
    }

    private void giveItem(Player target, ItemStack item) {
        Map<Integer, ItemStack> leftovers = target.getInventory().addItem(item);
        for (ItemStack leftover : leftovers.values()) {
            target.getWorld().dropItemNaturally(target.getLocation(), leftover);
        }
    }

    private void notifySender(CommandSender sender, Player target, String message) {
        if (!(sender instanceof Player) || !target.equals(sender)) {
            sender.sendMessage(ChatColor.GREEN + "[MaceWind] " + message);
        }
    }

    private boolean checkPermission(CommandSender sender) {
        if (sender.hasPermission("macewind.admin")) {
            return true;
        }
        sender.sendMessage(ChatColor.RED + "[MaceWind] You don't have permission.");
        return false;
    }

    private void sendHelp(CommandSender sender) {
        sender.sendMessage(ChatColor.GREEN + "--- MaceWind Commands ---");
        sender.sendMessage(ChatColor.AQUA + "/mw givemace [player]");
        sender.sendMessage(ChatColor.AQUA + "/mw givewind [player] [amount]");
        sender.sendMessage(ChatColor.AQUA + "/mw givebook <enchant> <level> [player]");
        sender.sendMessage(ChatColor.AQUA + "/mw enchant <enchant> <level>");
        sender.sendMessage(ChatColor.AQUA + "/mw unenchant <enchant|all>");
        sender.sendMessage(ChatColor.AQUA + "/mw enchants");
        sender.sendMessage(ChatColor.AQUA + "/mw reload");
        sender.sendMessage(
            ChatColor.GRAY + "Enchants: Density I-V, Breach I-IV, Wind Burst I-III"
        );
    }

    private void addMatches(List<String> results, String partial, String... values) {
        String lower = partial.toLowerCase(Locale.ROOT);
        for (String value : values) {
            if (value.toLowerCase(Locale.ROOT).startsWith(lower)) {
                results.add(value);
            }
        }
    }

    private void addOnlinePlayers(List<String> results, String partial) {
        String lower = partial.toLowerCase(Locale.ROOT);
        for (Player player : Bukkit.getOnlinePlayers()) {
            if (player.getName().toLowerCase(Locale.ROOT).startsWith(lower)) {
                results.add(player.getName());
            }
        }
    }
}
