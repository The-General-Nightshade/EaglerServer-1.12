package com.shadowlord.futurecraft.items;

import com.shadowlord.futurecraft.debris.DebrisItem;
import com.shadowlord.futurecraft.util.NBTUtil;
import java.util.Arrays;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public final class AncientDebrisItem {
    private static final String NBT_KEY = "futurecraft:ancient_debris";
    private static final String DISPLAY = ChatColor.DARK_RED + "Ancient Debris";

    private AncientDebrisItem() {
    }

    public static ItemStack createAncientDebris(int amount) {
        ItemStack it = new ItemStack(Material.NETHER_BRICK, Math.max(1, amount));
        ItemMeta meta = it.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(DISPLAY);
            meta.setLore(Arrays.asList(ChatColor.GRAY + "Ancient scrap used in advanced smelting"));
            it.setItemMeta(meta);
        }
        NBTUtil.setStringTag(it, NBT_KEY, "1");
        return it;
    }

    public static boolean isAncientDebris(ItemStack it) {
        if (it == null) {
            return false;
        }
        if (NBTUtil.hasTag(it, NBT_KEY)) {
            return true;
        }
        return DebrisItem.isDebris(it);
    }
}

